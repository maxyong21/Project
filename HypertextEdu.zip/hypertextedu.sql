-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 15, 2024 at 06:09 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hypertextedu`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

DROP TABLE IF EXISTS `administrator`;
CREATE TABLE IF NOT EXISTS `administrator` (
  `Administrator_ID` int NOT NULL AUTO_INCREMENT,
  `Admin_username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Admin_password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Admin_email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Admin_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Admin_contactNumber` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Administrator_ID`),
  UNIQUE KEY `username` (`Admin_username`),
  UNIQUE KEY `email` (`Admin_email`),
  UNIQUE KEY `Administrator_ID` (`Administrator_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`Administrator_ID`, `Admin_username`, `Admin_password`, `Admin_email`, `Admin_name`, `Admin_contactNumber`) VALUES
(1, 'johndoe123', '$2y$10$TOelMb0d7HwcUa493IraFOvr5qT1ev.9t6Po/o7N4OxBbPSAqR7q2', 'john@gmail.com', 'John Doe', '0123456787'),
(2, 'jane123', '$2y$10$mpWA5wK/SGv/SfBKgos7dO/EjZIIl4M.M4E7kzK00jwrUWQ0n3i5i', 'jane123@gmail.com', 'Jane Doe', '0123456789'),
(5, 'aaalex9', '$2y$10$awtCmzqrxM02EP5Ts6U9c.a5vxj4BEtvruw2XS5qC0yA0lrOYPrm6', 'alex9@gmail.com', 'Alex Brown', '0154836528');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
CREATE TABLE IF NOT EXISTS `announcement` (
  `Announce_ID` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Announce_subject` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Announce_message` text COLLATE utf8mb4_general_ci NOT NULL,
  `Announce_date` date NOT NULL,
  `Administrator_ID` int NOT NULL,
  PRIMARY KEY (`Announce_ID`),
  KEY `Administrator_ID` (`Administrator_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`Announce_ID`, `Announce_subject`, `Announce_message`, `Announce_date`, `Administrator_ID`) VALUES
('ANN001', 'Scheduled System Maintenance', 'Please note that the Hypertext EDU platform will undergo scheduled maintenance on Saturday, November 25th, from 12:00 AM to 6:00 AM. During this time, the platform may be temporarily unavailable. We apologize for any inconvenience and appreciate your understanding.', '2024-11-05', 1),
('ANN002', 'HypertextEDU Good Practices', 'Here are a few tips to make the most of the quiz platform:\r\n\r\n- Ensure a stable internet connection before starting a quiz.\r\n- Read each question carefully before answering.\r\n- Review your answers if time permits.\r\n\r\nHappy quizzing, and good luck!', '2024-11-21', 1),
('ANN003', '🎄 Exciting Holiday Themes Coming Soon! 🎅', 'Get ready to elevate your holiday cheer! 🎁 We\'re thrilled to announce a collection of festive themes arriving just in time for the holiday season. 🌟\r\nStay tuned for the official release and prepare to make your holiday season more magical than ever! 🕯️✨', '2024-11-22', 2);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

DROP TABLE IF EXISTS `enrollment`;
CREATE TABLE IF NOT EXISTS `enrollment` (
  `Student_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quiz_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `attempt_date` date NOT NULL,
  `Question_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_ans` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `score` int NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Student_ID`,`Question_ID`),
  KEY `Quiz_ID` (`Quiz_ID`),
  KEY `Student_ID` (`Student_ID`,`Question_ID`),
  KEY `Question_ID` (`Question_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`Student_ID`, `Quiz_ID`, `attempt_date`, `Question_ID`, `Student_ans`, `score`, `status`) VALUES
('S05', 'Q002', '2024-12-12', 'QS006', 'A', 0, ''),
('S05', 'Q002', '2024-12-12', 'QS007', 'B', 10, ''),
('S05', 'Q002', '2024-12-12', 'QS008', 'C', 0, ''),
('S05', 'Q002', '2024-12-12', 'QS009', 'C', 10, ''),
('S05', 'Q002', '2024-12-12', 'QS010', 'B', 10, '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `Feedback_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `feedback_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `feedback_date` date NOT NULL,
  `Question_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Feedback_ID`),
  KEY `Question_ID` (`Question_ID`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Feedback_ID`, `feedback_text`, `feedback_date`, `Question_ID`, `Student_ID`) VALUES
('FDB001', 'we only have 3 list in HTML. Please remember', '2024-12-12', 'QS006', 'S05');

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

DROP TABLE IF EXISTS `instructor`;
CREATE TABLE IF NOT EXISTS `instructor` (
  `Instructor_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instructor_username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instructor_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instructor_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instructor_contact` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `verificationStatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  `Applied_item` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Instructor_ID`),
  UNIQUE KEY `username` (`Instructor_username`),
  UNIQUE KEY `email` (`Instructor_email`),
  UNIQUE KEY `Instructor_ID` (`Instructor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`Instructor_ID`, `Instructor_username`, `Instructor_password`, `Instructor_email`, `Instructor_contact`, `verificationStatus`, `Applied_item`) VALUES
('INS001', 'JimmyWangLoong', '$2y$10$qP.UoEBE4zEnmD2d926E4uFRtty0d6xqs3uMiUQmVuzicWmLU4Dzm', 'jim@gmail.com', '0123457798', 'approved', 'ITM001'),
('INS002', 'jestinnaKuan', '$2y$10$/rO5rno7R3x6uic00/HH9eAB2L9KEodKxkLfw0JXxz..nHoQhFEXy', 'jestinnakuan@gmail.com', '158745511', 'approved', 'ITM002'),
('INS003', 'angellim', '$2y$10$mTAiA0vfSUobWyObvnwdZeaHXT2Ox.MS.vsOaxtuXklKGsLRAEih2', 'angel@gmail.com', '0174629485', 'approved', 'ITM002'),
('INS004', 'sampleacc', '$2y$10$/rO5rno7R3x6uic00/HH9eAB2L9KEodKxkLfw0JXxz..nHoQhFEXy', 'sample@gmail.com', '0158785511', 'approved', 'ITM003'),
('INS005', 'marcolee', '$2y$10$D42Mq4vJxvT.eYNZE/6C/OREgtU1tweyFAjaBUC492nO4yzUc.9Fe', 'marco@gmail.com', '0123667320', 'pending', ''),
('INS006', 'testerGuy', '$2y$10$C8Mln5wI/u0dsaSe.1Nt.Okn9S4YGHJEVrmYMJvDOSKjU6C.aDaI.', 'test@gmail.com', '99999999', 'pending', 'ITM005');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE IF NOT EXISTS `inventory` (
  `Item_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'not applied',
  PRIMARY KEY (`Item_ID`,`Student_ID`),
  KEY `Student_ID` (`Student_ID`),
  KEY `Item_ID` (`Item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`Item_ID`, `Student_ID`, `status`) VALUES
('ITM001', 'S01', 'not applied'),
('ITM002', 'S04', 'not applied'),
('ITM003', 'S01', 'applied'),
('ITM003', 'S04', 'applied'),
('ITM004', 'S04', 'not applied'),
('ITM005', 'S06', 'applied');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `Item_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Item_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Item_date` date NOT NULL,
  `Item_price` int NOT NULL,
  `Item_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Administrator_ID` int NOT NULL,
  PRIMARY KEY (`Item_ID`),
  UNIQUE KEY `Item_ID` (`Item_ID`),
  KEY `Administrator_ID` (`Administrator_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`Item_ID`, `Item_name`, `Item_date`, `Item_price`, `Item_url`, `Administrator_ID`) VALUES
('ITM001', 'Theme1', '2024-11-16', 90, 'https://wallpaper.forfun.com/fetch/cb/cbfbc5ea432002fe4e06fdfad0f4e06c.jpeg', 1),
('ITM002', 'Theme2', '2024-11-14', 120, 'https://wallpaper.forfun.com/fetch/d2/d2b9d5e4c3129d6410c49943882e1553.jpeg', 1),
('ITM003', 'Theme3', '2024-11-14', 65, 'https://wallpaper.forfun.com/fetch/e9/e976e6ca53a4c0a2377845abec70b11b.jpeg', 2),
('ITM004', 'Theme4', '2024-11-14', 85, 'https://wallpaper.forfun.com/fetch/d1/d197f3d63e273b6f5c105412b799eae6.jpeg', 1),
('ITM005', 'Theme5', '2024-11-04', 70, 'https://wallpaper.forfun.com/fetch/2d/2d1c533dca66d342514d42a429517029.jpeg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `Question_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Question_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Question_choice_a` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Question_choice_b` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Question_choice_c` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Question_choice_d` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `correct_answer` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quiz_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Question_ID`),
  KEY `Quiz_ID` (`Quiz_ID`),
  KEY `Quiz_ID_2` (`Quiz_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`Question_ID`, `Question_text`, `Question_choice_a`, `Question_choice_b`, `Question_choice_c`, `Question_choice_d`, `correct_answer`, `Quiz_ID`) VALUES
('QS006', 'How many types of lists are in HTML?', '2', '5', '4', '3', 'D', 'Q002'),
('QS007', 'What is the attribute used to create a bookmark?', 'hr', 'id', 'href', 'book', 'B', 'Q002'),
('QS008', 'Which tag is not used in HTML tables?', '<td>', '<tb>', '<th>', '<tr>', 'B', 'Q002'),
('QS009', 'What is the <br> element used for?', 'Emphasize text in HTML, typically displayed in bold.', 'Insert numeric character references.', 'Insert line breaks, ending one line and starting another.', 'Insert tables.', 'C', 'Q002'),
('QS010', 'Which element is used to specify alternate text for an image?', '<img>', '<alt>', '<src>', '<url>', 'B', 'Q002'),
('QS011', 'What does a CSS rule-set consist of?', 'Selectors and properties', 'Selectors and values', 'Selectors and declarations', 'Properties and declarations', 'C', 'Q003'),
('QS012', 'How do you select an element with the id \"header\" in CSS?', '.header {...}', 'header {...{', '#header {...}', '/header {...}', 'A', 'Q003'),
('QS013', 'What is the correct way to apply a background color of blue to all <p> elements?', 'p: {background-color: blue;}', 'p {background-color: blue;}', 'p.background-color {blue}', 'p <{background-color: blue;}>', 'B', 'Q003'),
('QS014', 'Which property is used to change the font size of text in CSS?', 'font-weight', 'line-height', 'font-size', 'text-size', 'A', 'Q003'),
('QS015', 'What is the correct syntax to include an external CSS file in HTML?', '<style src=\"style.css\">', '<stylesheet>style.css</stylesheet>', '<link rel=\"stylesheet\" href=\"style.css\">', '<css link=\"style.css\">', 'C', 'Q003'),
('QS016', 'How do you group multiple selectors in a CSS rule-set?', 'By separating them with commas', 'By writing them on different lines', 'By enclosing them in square brackets', 'By using \"&\" between them', 'A', 'Q003'),
('QS017', 'What is the correct syntax for a comment in CSS?', '<!-- This is a comment -->', '/* This is a comment */', '// This is a comment', '# This is a comment', 'B', 'Q003'),
('QS018', 'How do you specify a class selector in CSS?', 'Start with \"#\" followed by the class name', 'Start with \".\" followed by the class name', 'Start with \"&\" followed by the class name', 'No special character is needed; just write the class name', 'B', 'Q003'),
('QS019', 'What is the viewport in web design?', 'A fixed-size area for displaying images', ' The user\'s visible area of a web page  ', 'A container for holding grid elements', 'The area reserved for media queries', 'B', 'Q004'),
('QS020', 'Which meta tag is used to set the viewport?', '<meta name=\"device\"> ', '<meta name=\"screen-size\">', '<meta name=\"viewport\">', '<meta name=\"resolution\">', 'C', 'Q004'),
('QS021', 'What is the purpose of media queries in responsive web design?', 'To define the layout using grid views ', 'To include specific CSS styles based on device characteristics  ', 'To add breakpoints to JavaScript functions', 'To enable flexible image scaling', 'B', 'Q004'),
('QS022', 'How many columns are typically used in a responsive grid system?', '6', '8', '12', '16', 'C', 'Q004'),
('QS023', 'Which of the following is not a valid viewport unit?', 'vw', 'vh', 'vm', 'vmax', 'C', 'Q004'),
('QS024', 'What does the flex-wrap property in CSS do?', 'Aligns flex items horizontally   ', 'Determines whether flex items wrap onto multiple lines', 'Specifies the spacing between flex items', 'Sets the direction of the flex container', 'B', 'Q004'),
('QS025', 'Which of the following breakpoints is suitable for tablets?', '360px – 575px  ', '576px – 767px ', '768px – 1024px', '992px – 1200px', 'C', 'Q004'),
('QS026', '\"What is the purpose of functions in PHP?\"', 'To write code in a single block for readability', 'To organize code into reusable blocks ', 'To compile PHP code before execution', 'To avoid using variables entirely', 'B', 'Q005'),
('QS027', 'Which keyword is used to define a function in PHP?', 'define', 'declare', 'function', 'method', 'C', 'Q005'),
('QS028', 'What happens if you call a PHP function without specifying an argument for a parameter with a default value?', ' It throws an error  ', 'The default value is used', 'The function is skipped', 'The function exits', 'B', 'Q005'),
('QS029', 'Which of the following is true about anonymous functions in PHP?', 'They cannot accept parameters ', 'They can be assigned to variables ', 'They must have a return value', 'They cannot be used in loops', 'B', 'Q005'),
('QS030', 'What is the purpose of the global keyword in PHP?   ', 'To declare a global function', 'To create a new variable', 'To access a variable outside a function\'s scope', 'To make all functions available globally', 'C', 'Q005'),
('QS031', 'What is a valid way to pass data into a PHP function?   ', 'By including the data within the function declaration', 'By using parameters in the function definition', 'By declaring global variables before the function is called ', 'By directly assigning data to the function name', 'B', 'Q005'),
('QS032', 'What is the main benefit of using built-in PHP functions?  ', 'They allow PHP to interact with the operating system', 'They reduce the need to write common operations manually', 'They eliminate the need for user-defined functions', 'They ensure the application compiles faster', 'B', 'Q005'),
('QS059', '\"\"Which of the following is true about PHP? \"\"', 'Runs on the user\'s browser', 'Combines scripting with HTML for dynamic content', 'Requires a .php file extension', 'Both B and C', 'D', 'Q009'),
('QS060', 'What is the correct way to start a PHP script? ', '<php>', '<?php ?>', '<? ?>', '<script>', 'B', 'Q009'),
('QS061', 'Which of the following is a valid variable name in PHP?', '$1name', '$Name', '$_Name', 'B and C', 'D', 'Q009'),
('QS062', 'Which superglobal variable is used to collect form data sent with the POST method? ', '$_GET', '$_POST', '$_REQUEST ', '$_SERVER', 'B', 'Q009'),
('QS063', 'If $x = 5 and $y = 2, what is the output of \"echo $x % $y;\"?', '1', '2', '0', '5', 'A', 'Q009'),
('QS064', 'Which operator is used for concatenating strings in PHP?', '+', '.', '&', '*', 'B', 'Q009'),
('QS065', 'What is the difference between single-quoted and double-quoted strings in PHP? ', 'Single quotes are faster and more literal, double quotes allow variable interpolation', 'Double quotes are faster, single quotes allow variable interpolation', 'Both are identical', 'Neither can handle special characters', 'A', 'Q009'),
('QS066', 'What is the correct syntax for an if condition in PHP? ', 'if expression { statement; } ', 'if (expression) { statement; }', 'if { expression statement; }', 'if (expression) statement;', 'B', 'Q009'),
('QS100', '\"sample q 1\"', 'Description list', 'Numbered list', 'Unordered list', 'Ordered list', 'B', 'Q010'),
('QS101', 'sample q 2', '//', '/* */', '#', '<!-- -->', 'D', 'Q010'),
('QS103', 'hello', 'a', 'a', 'a', 'a', 'A', 'Q010'),
('QS104', 'how old am i', '19', '20', '21', '22', 'A', 'Q010'),
('QS105', 'my name', 'ben', 'will', 'jim', 'tan', 'B', 'Q010'),
('QS106', 'movie name', 'onepiece', 'strong', 'weak', 'low', 'A', 'Q010'),
('QS107', 'how to spell why', 'hi', 'why', 'day', 'good', 'B', 'Q012'),
('QS108', '\"hello\"', 'hrllo', 'hilla', 'hello', 'bye', 'C', 'Q012'),
('QS109', '1', '1', '1', '1', '1', 'A', 'Q013'),
('QS110', '2', '2', '2', '2', '2', 'A', 'Q013'),
('QS111', '1', 'd', 'f', 't', 'h', 'A', 'Q014'),
('QS112', 'hi', 'hi', 'hi', 'hi', 'bye', 'D', 'Q015'),
('QS113', 'Loops we dont have in HTML', 'if', 'while', 'for', 'by', 'D', 'Q016'),
('QS114', '\"question 2 answer is a\"', 'hi', 'bye', 'ciao', 'goodbye', 'A', 'Q016'),
('QS115', '\"how to spell test\"', 'estt', 'sett', 'test', 'ttes', 'C', 'Q017'),
('QS116', 'how to spell spell', 'spell', 'sellp', 'pells', 'ellsp', 'A', 'Q017'),
('QS117', 'how to spell CSS', 'Css', 'CSS', 'ssc', 'SSS', 'B', 'Q018'),
('QS118', '1 in english', 'one', 'two', 'three', 'four', 'A', 'Q019');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
CREATE TABLE IF NOT EXISTS `quiz` (
  `Quiz_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quiz_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quiz_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quiz_timer` int NOT NULL,
  `created_date` date NOT NULL,
  `quiz_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Instructor_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `verificationStatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`Quiz_ID`),
  KEY `Instructor_ID` (`Instructor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`Quiz_ID`, `Quiz_title`, `Quiz_description`, `Quiz_timer`, `created_date`, `quiz_code`, `Instructor_ID`, `verificationStatus`) VALUES
('Q002', 'HTML Basics', 'This quiz tests your understanding of basic HTML concepts and elements. It covers the essential components of HTML, including the structure of an HTML document, tags, attributes, and basic elements that form the backbone of web development.', 15, '2024-11-06', '002', 'INS002', 'approved'),
('Q003', 'CSS Syntax', 'This quiz tests your knowledge of CSS syntax, including the structure of CSS rules, selectors, properties, and values. Designed for beginners and intermediate learners, the questions cover essential concepts that form the foundation of CSS styling. Prepare to identify correct syntax, choose appropriate selectors, and debug common errors in CSS code.', 15, '2024-11-07', '003', 'INS002', 'approved'),
('Q004', 'Responsive Web Design Fundamentals', 'This quiz is designed to test your understanding of key concepts related to responsive web design, including viewport, media queries, grid view, flexbox, and responsive design principles. It focuses on ensuring an optimal user experience across various devices.', 10, '2024-11-11', '004', 'INS002', 'approved'),
('Q005', 'PHP Functions Basics', 'This quiz covers the foundational concepts of PHP functions, including their syntax, structure, usage, and importance in web development. Test your understanding of built-in and user-defined functions, parameter handling, return values, and variable scopes in PHP.', 15, '2024-11-15', '005', 'INS002', 'approved'),
('Q009', 'PHP Fundamentals', 'Test your understanding of PHP basics, including syntax, variables, loops, operators, and form handling.', 10, '2024-11-23', '009', 'INS003', 'approved'),
('Q010', 'testing final', 'testing testing testing', 0, '2024-11-29', '010', 'INS002', 'rejected'),
('Q012', 'trying again', 'tryyyyyyyyyy', 0, '2024-11-29', '012', 'INS002', 'rejected'),
('Q013', 'a', 'a', 0, '2024-12-03', '013', 'INS002', 'rejected'),
('Q014', 'aaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaa', 0, '2024-12-03', '014', 'INS002', 'rejected'),
('Q015', 'Topic 1', 'hello', 6, '2024-12-03', '015', 'INS002', 'rejected'),
('Q016', 'HTML chapter 7', 'this is the quiz for HTML chapter 7', 4, '2024-12-08', '016', 'INS002', 'pending'),
('Q017', 'The final final testing', 'this is the final final testing', 5, '2024-12-11', '017', 'INS002', 'pending'),
('Q018', 'testing design', 'testing the css design', 0, '2024-12-11', '018', 'INS002', 'pending'),
('Q019', 'testttttt', 'heyyyy', 0, '2024-12-11', '019', 'INS002', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
CREATE TABLE IF NOT EXISTS `review` (
  `Review_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Review_Title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Review_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Review_date` date NOT NULL,
  `star_rating` tinyint NOT NULL,
  `Student_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Review_ID`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`Review_ID`, `Review_Title`, `Review_message`, `Review_date`, `star_rating`, `Student_ID`) VALUES
('RV001', 'A good website', 'This website helps a lot in my html learning career!', '2024-11-29', 5, 'S05');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `Student_ID` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_contact` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Student_point` int NOT NULL,
  `verificationStatus` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`Student_ID`),
  UNIQUE KEY `username` (`Student_username`),
  UNIQUE KEY `email` (`Student_email`),
  UNIQUE KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Student_ID`, `Student_username`, `Student_password`, `Student_email`, `Student_contact`, `Student_point`, `verificationStatus`) VALUES
('S01', 'mary123', '$2y$10$vB8SGWrbZ2OTROUGzmgHX.eQ6xgQ/dppnrxvEIJ0JtQX5ZkYcswTa', 'mary@gmail.com', '0137468477', 120, 'approved'),
('S03', 'aliceD', '$2y$10$PV11FKa9ZVS53U8gRswGreCGWH.MThxijNoxsoWYLMozPtsgGlMDe', 'alice@gmail.com', '0178556835', 80, 'approved'),
('S04', 'blacksheep', '$2y$10$w.JBfKMk4ZWK8qdV0auJruVX891He3bVEgW3SlxflAX9KJcdJ2EAi', 'blacksheep@gmail.com', '0125897457', 780, 'approved'),
('S05', 'jimgui', '$2y$10$Q0shnUlU2I0ugUmoFH4uw.sbDPs93ZVOo7zr4S8Nr9zaHbggC/eMW', 'jimgui@gmail.com', '0123337320', 60, 'approved'),
('S06', 'boon', '$2y$10$D2m95jdKL3As32oZRwPpIOUh5gftv/qj5tQTh35eI5VJ7.8nCh.Ea', 'boon@mail.com', '0361117789', 30, 'pending');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcement`
--
ALTER TABLE `announcement`
  ADD CONSTRAINT `announcement_ibfk_1` FOREIGN KEY (`Administrator_ID`) REFERENCES `administrator` (`Administrator_ID`) ON DELETE CASCADE;

--
-- Constraints for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `enrollment_ibfk_2` FOREIGN KEY (`Quiz_ID`) REFERENCES `quiz` (`Quiz_ID`) ON DELETE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`Question_ID`) REFERENCES `question` (`Question_ID`) ON DELETE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`Item_ID`) REFERENCES `item` (`Item_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`) ON DELETE CASCADE;

--
-- Constraints for table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`Administrator_ID`) REFERENCES `administrator` (`Administrator_ID`) ON DELETE CASCADE;

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`Quiz_ID`) REFERENCES `quiz` (`Quiz_ID`) ON DELETE CASCADE;

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`Instructor_ID`) REFERENCES `instructor` (`Instructor_ID`) ON DELETE CASCADE;

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
