<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        .logo {
            width: 300px;
            margin-bottom: 20px;
            margin-left: 8px;
        }
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url(background3.jpg) no-repeat;
            background-size: cover;
            background-position: center;
        }
        .wrapper{
            width: 420px;
            height: 85vh;
            background: transparent;
            color: white;
            border-radius: 15px;
            padding: 30px 40px;
            border: 2px solid white;
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }
        .wrapper h1{
            font-size: 40px;
        }
        .input-box{
            width: 100%;
            height: auto;
            margin: 40px 0;
            position: relative;
        }
        .input-box input{
            width: 100%;
            height: 35px;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 50px;
            background: transparent;
            font-size: 20px;
            color: white;
            padding: 20px 45px 20px 15px;
            margin-bottom: 10px;
        }
        .input-box input::placeholder{
            color: white;
        }
        .input-box i{
            position: absolute;
            right: 10px;
            top: 30%;
            transform: translate(-50%);
            font-size: 20px;
        }
        .btn{
            width: 100%;
            height: 45px;
            background: #fff;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            cursor: pointer;
            font-size: 20px;
            color: black;
            font-weight: 600;
        }
        .btn:hover {
            background-color: #cbd5e1;
            color: #1f2937;
        }
        a {
            text-decoration: none;
            color: black;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <form action="login.php" method="POST">
            <img src="logo.jpg" alt="Logo" class="logo">
            <h1>Welcome to Hypertext EDU</h1><br>
            <p>Please select your user role:</p>
            <div class="input-box">
                <button type="button" class="btn"><a href="student/login.php">Student</a></button><br><br>
                <button type="button" class="btn"><a href="instructor/login.php">Instructor</a></button><br><br>
            </div>
            </div>
        </form>
    </div>
</body>
</html>