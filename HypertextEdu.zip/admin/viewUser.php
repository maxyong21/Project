<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php");

$all_students_query = "SELECT Student_id AS id, Student_username, Student_email, Student_contact, verificationStatus FROM student ORDER BY FIELD(verificationStatus, 'pending', 'rejected', 'approved'), Student_ID asc";
$all_instructors_query = "SELECT Instructor_id AS id, Instructor_username, Instructor_email, Instructor_contact, verificationStatus FROM instructor ORDER BY FIELD(verificationStatus, 'pending', 'rejected', 'approved'), Instructor_ID asc";
$all_students_result = mysqli_query($con, $all_students_query);
$all_instructors_result = mysqli_query($con, $all_instructors_query);

$approved_students_query = "SELECT Student_id AS id, Student_username, Student_email, Student_contact, verificationStatus FROM student WHERE verificationStatus = 'approved' ORDER BY Student_ID asc";
$approved_instructors_query = "SELECT Instructor_id AS id, Instructor_username, Instructor_email, Instructor_contact, verificationStatus FROM instructor WHERE verificationStatus = 'approved' ORDER BY Instructor_ID asc";
$approved_students_result = mysqli_query($con, $approved_students_query);
$approved_instructors_result = mysqli_query($con, $approved_instructors_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View User</title>
    <link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
        }

        table {
            width: 95vw;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
            background-color: white;
        }
        th {
            background-color: white;
        }
        .pending {
            text-decoration: none;
            color: #4a4a4a;
        }
        .pending:hover {
            color: #242424;
        }
        .rejected {
            text-decoration: none;
            color: #b01818;
        }
        .rejected:hover {
            color: #951515;
        }
        .approved {
            text-decoration: none;
            color: #06a83c;
        }
        .actions {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            margin-bottom: 5px;
        }
        .view {
            cursor: pointer;
            padding: 5px 15px;
            border: none;
            border-radius: 5px;
        }

        @media (max-width: 480px) {
            table {
            width: 75vw;
            border-collapse: collapse;
            margin: 10px 0;
            flex-wrap: wrap;
            }
            th, td {
            padding: 5px;
            text-align: left;
            border: 1px solid #ddd;
            background-color: white;
            font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Users</h2>
        <h3>Registered Users</h3>
        <h4>Students</h4>
        <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($all_students_result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($all_students_result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']); ?></td>
                        <td><?= htmlspecialchars($row['Student_username']); ?></td>
                        <td><?= htmlspecialchars($row['Student_email']); ?></td>
                        <td><?= htmlspecialchars($row['Student_contact']); ?></td>
                        <td class="<?= 'status-' . strtolower($row['verificationStatus']); ?>">
                            <?php if ($row['verificationStatus'] == 'pending'): ?>
                                <a class="pending" href="verifyUser.php?type=student&id=<?= $row['id']; ?>">
                                    <?= htmlspecialchars($row['verificationStatus']); ?>
                                </a>
                            <?php elseif ($row['verificationStatus'] == 'rejected'): ?>
                                <a class="rejected" href="deleteUser.php?type=student&id=<?= $row['id']; ?>">
                                    <?= htmlspecialchars($row['verificationStatus']); ?>
                                </a>
                            <?php else: ?>
                                <a class="approved" href="approvedUser.php?type=student&id=<?= $row['id']; ?>">
                                    <?= htmlspecialchars($row['verificationStatus']); ?>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No student accounts found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
        <br>
        <h4>Instructors</h4>
        <table>
        <thead>
            <tr>
                <th>Instructor ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($all_instructors_result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($all_instructors_result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']); ?></td>
                        <td><?= htmlspecialchars($row['Instructor_username']); ?></td>
                        <td><?= htmlspecialchars($row['Instructor_email']); ?></td>
                        <td><?= htmlspecialchars($row['Instructor_contact']); ?></td>
                        <td class="<?= 'status-' . strtolower($row['verificationStatus']); ?>">
                        <?php if ($row['verificationStatus'] == 'pending'): ?>
                                <a class="pending" href="verifyUser.php?type=instructor&id=<?= $row['id']; ?>">
                                    <?= htmlspecialchars($row['verificationStatus']); ?>
                                </a>
                            <?php elseif ($row['verificationStatus'] == 'rejected'): ?>
                                <a class="rejected" href="deleteUser.php?type=instructor&id=<?= $row['id']; ?>">
                                    <?= htmlspecialchars($row['verificationStatus']); ?>
                                </a>
                            <?php else: ?>
                                <a class="approved" href="approvedUser.php?type=instructor&id=<?= $row['id']; ?>">
                                    <?= htmlspecialchars($row['verificationStatus']); ?>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No instructor accounts found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
