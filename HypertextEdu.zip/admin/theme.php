<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php")
?>

<?php
include("../conn.php");

// Fetch themes from the database
$sql = "SELECT * FROM item";  // Modify this SQL query based on your actual database schema
$result = mysqli_query($con, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Themes</title>
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
            height: 100vh;
            width: 100vw;
        }

        /* Themes */
        .container {
            display: flex;
            width: 95vw;
            height: auto;
            flex-wrap: wrap;
            justify-content: left;
        }
        .theme-container {
            display: flex;
            align-content: center;
            justify-content: center;
            width: 500px;
            height: 465px;
            border: none;
            border-radius: 8px;
            background-color: white;
            margin: 15px;
            margin-right: 80px;
            padding: 15px 25px;
            flex-direction: column;
        }
        .theme-img {
            display: flex;
            flex: 1;
            justify-content: center;
            align-content: center;
        }
        .theme-img img {
            width: 432px;
            height: 307.2px;
            object-fit: cover;
            margin-top: 10px;
            margin-bottom: 10px;
        }
        .theme-desc {
            flex: 1;
            width: 80%;
            height: auto;
            margin-bottom: 10px;
        }
        .theme-button-container {
            height: auto;
            flex: 1;
            display: flex;
            flex-direction: row;
            width: 20%;
        }
        .theme-button-container a {
            color: white;
            text-decoration: none;
        }
        .theme-button {
            height: 35px;
            width: 50px;
            margin-bottom: 10px;
            margin-right: 15px;
            border: none;
            border-radius: 5px;
            color: white;
            background-color: #e786cd;
            flex: 1;
        }
        .theme-button:hover {
            background-color: #d070a6;
            cursor: pointer;
        }
        .edit-theme-form {
            display: grid;
            place-items: center;
            position: fixed;
            top: 50%;
            left: 50%;
            width: 350px;
            transform: translate(-50%, -50%); /* centers form */
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: auto;
        }
        .theme-upload-container {
            width: 85vw;
            height: auto;
            background-color: white;
            border: none;
            border-radius: 5px;
            display: flex;
            flex-direction: column;
            padding: 10px 25px;
            padding-bottom: 20px;
            margin-left: 15px;
        }
        .theme-upload-name {
            width: 80%;
            height: auto;
            justify-content: space-between;
            margin-top: 10px;
            display: flex;
            padding-left: 10px;
        }
        .theme-upload-name input {
            width: 75%;
            margin-left: auto;
            height: 25px;
        }
        .theme-upload-price {
            width: 80%;
            height: auto;
            justify-content: space-between;
            margin-top: 10px;
            display: flex;
            padding-left: 10px;
        }
        .theme-upload-price input {
            width: 75%;
            margin-left: auto;
            height: 25px;
        }
        .theme-upload-image {
            width: 80%;
            height: auto;
            justify-content: left;
            margin-top: 10px;
            display: flex;
            padding-left: 10px;
        }
        .theme-upload-image input {
            width: 75%;
            margin-left: auto;
            height: 25px;
        }
        .theme-upload-button {
            width: 80%;
            height: auto;
            margin-top: 10px;
            padding-left: 10px;
            margin-bottom: 15px;
        }
        .theme-upload-button button {
            height: 35px;
            width: 75px;
            margin-bottom: 10px;
            margin-right: 15px;
            border: none;
            border-radius: 5px;
            color: white;
            background-color: #e786cd;
            flex: 1;
            margin-top: 30px;
        }
        .theme-upload-button button:hover {
            background-color: #d070a6;
            cursor: pointer;
        }

        @media (max-width: 480px) {
            .theme-upload-container {
            width: 65vw;
            height: auto;
            background-color: white;
            border: none;
            border-radius: 5px;
            display: flex;
            flex-direction: column;
            padding: 10px 25px;
            padding-bottom: 20px;
            margin-left: 15px;
            }
            .theme-upload-container label {
                font-size: 14px;
            }
            .theme-upload-button {
                width: 60%;
                height: 45px;
                margin-top: 10px;
                padding-left: 5px;
                margin-bottom: 15px;
                display: flex;
                flex-direction: row;
            }
            .theme-upload-button button {
                height: 25px;
                width: 50px;
                margin-bottom: 10px;
                margin-right: 15px;
                border: none;
                border-radius: 5px;
                color: white;
                background-color: #e786cd;
                flex: 1;
                margin-top: 30px;
                font-size: 10px;
            }
            .theme-container {
            display: flex;
            align-content: center;
            justify-content: center;
            width: 250;
            height: 275px;
            border: none;
            border-radius: 8px;
            background-color: white;
            margin: 15px;
            margin-right: 80px;
            padding: 15px 25px;
            flex-direction: column;
            }
            .theme-img img {
            width: 199.584px;
            height: 141.9264px;
            object-fit: cover;
            margin-top: 10px;
            margin-bottom: 10px;
            }
            .theme-desc {
                font-size: 14px;
            }
            .theme-button-container button {
                font-size: 10px;
                height: 25px;
            }
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Themes</h2>
        
        <!-- Upload Themes -->
        <div class="container">
            <div class="theme-upload-container">
                <h3>Upload Theme</h3>
                <form action="themeUpload.php" id="themeUpload" name="themeUpload" method="POST">
                    <div class="theme-upload-name">
                        <label for="Item_name">Theme Name: </label>
                        <input type="text" id="Item_name" name="Item_name" required><br><br>
                    </div>
                    <div class="theme-upload-price">
                        <label for="Item_price">Points Required: </label>
                        <input type="int" id="Item_price" name="Item_price" required><br><br>
                    </div>
                    <div class="theme-upload-image">
                        <label for="Item_url">Image URL: </label>
                        <input type="text" id="Item_url" name="Item_url" required><br><br>
                    </div>
                    <div class="theme-upload-button">
                        <button type="submit">Upload</button>
                        <button type="button" onclick="document.getElementById('themeUpload').reset()">Cancel</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Display Existing Themes -->
        <br><br><br><h3>Existing Themes</h3>
        <div class="container">
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="theme-container">';
                echo '<div class="theme-img"><img src="' . htmlspecialchars($row['Item_url']) . '" alt="' . htmlspecialchars($row['Item_name']) . '"></div>';
                echo '<div class="theme-desc">';
                echo '<p>Theme Name: ' . htmlspecialchars($row['Item_name']) . '</p>';
                echo '<p>Points Required: ' . htmlspecialchars($row['Item_price']) . '</p>';
                echo '</div>';
                echo '<div class="theme-button-container">';
                // echo '<button type="button" class="theme-button" onclick="editTheme()">Edit</button>';
                echo '<button type="submit" class="theme-button"><a href="themeDelete.php?action=delete&id=' . $row['Item_ID'] . '">Delete</a></button>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No existing themes.</p>';
        }
        ?>
        </div>
        <!--
        <div class="edit-theme-form" id="editThemeForm" style="display: none;">
            <form id="editFormFields" action="themeUpdate.php" method="POST">
                <input type="text" id="editName" name="editName" placeholder="Name" value="<?php echo htmlspecialchars($row['Item_name']);?>"><br>
                <input type="int" id="editPrice" name="editPrice" placeholder="Points Required" value="<?php echo htmlspecialchars($row['Item_price']);?>"><br>
                <button type="submit">Save Changes</button>
                <button type="button" id="cancelButton" onclick="cancelThemeEdit()">Cancel</button>
            </form>
        </div>
        -->
    </div>

    <script>
        /*
        function editTheme() {
            document.getElementById('editThemeForm').style.display = 'block';
        }

        function cancelThemeEdit() {
            document.getElementById('editThemeForm').style.display = 'none';
            document.getElementById('editThemeForm').reset();
        }
        */
    </script>
</body>
</html>