<?php
// Include the database connection file
include("../conn.php");

// Initialize variables for error messages
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $Admin_name = mysqli_real_escape_string($con, $_POST['Admin_name']);
    $Admin_email = mysqli_real_escape_string($con, $_POST['Admin_email']);
    $Admin_contactNumber = mysqli_real_escape_string($con, $_POST['Admin_contactNumber']);
    $Admin_username = mysqli_real_escape_string($con, $_POST['Admin_username']);
    $Admin_password = mysqli_real_escape_string($con, $_POST['Admin_password']);
    $passwordConf = mysqli_real_escape_string($con, $_POST['passwordConf']);

    // Check that password == passwordConf (server-side)
    if ($Admin_password !== $passwordConf) {
        echo '<script>alert("Passwords do not match. Please try again.");
            window.location.href="registration.php";
        </script>';
    } else {
        // Check if username already exists
        $check_username_query = "SELECT * FROM administrator WHERE Admin_username = '$Admin_username'";
        $username_result = mysqli_query($con, $check_username_query);

        if (mysqli_num_rows($username_result) > 0) {
            echo '<script>alert("This username is taken. Please enter a different username.");
                window.location.href="registration.php";
            </script>';
        } else {
            // Check if email is taken
            $check_email_query = "SELECT * FROM administrator WHERE Admin_email = '$Admin_email'";
            $email_result = mysqli_query($con, $check_email_query);

            if (mysqli_num_rows($email_result) > 0) {
                echo '<script>alert("This email is already registered. Please enter a different email.");
                    window.location.href="registration.php";
                </script>';
            } else {
                // Hash password
                $hashed_password = password_hash($Admin_password, PASSWORD_DEFAULT);

                $insert_query = "INSERT INTO administrator (Admin_name, Admin_email, Admin_contactNumber, Admin_username, Admin_password) values (?, ?, ?, ?, ?)";
                $stmt = $con->prepare($insert_query);
                $stmt->bind_param("sssss", $Admin_name, $Admin_email, $Admin_contactNumber, $Admin_username, $hashed_password);

                if ($stmt->execute()) {
                    echo '<script>alert("Registration successful");
                        window.location.href="login.php";
                    </script>';
                } else {
                    echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
                }

                $stmt->close();
            }
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background-color: #fde0f8;
        }

        /* Navbar */
        .navbar {
            display: flex;
            align-items: center;
            background-color: #e786cd;
            padding: 10px;
            color: white;
            border-radius: 10px;
            height: 41.5px;
        }
        .navbar .logo {
            margin-right: 15px;
        }
        .navbar .logo img {
            height: 40px; /* Adjust height as needed */
            width: auto;
        }

        /* Registration */
        .registration-container {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            width: 60vw;
            height: 65vh;
            margin: 100px auto;
            padding: 35px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: white;
        }
        .registration-container input {
            width: 90%;
            height: 25px;
            padding: 8px;
            margin-top: 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .registration-container input:focus {
            border-color: #e786cd;
            outline: none;
        }
        .registration-container button {
            width: 100px;
            padding: 10px;
            background-color: #e786cd;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .registration-container button:hover {
            background-color: #d070a6;
        }
        .registration-container form {
            display: grid;
            place-items: center;
            width: 250px;
        }
        a {
            color: #e786cd;
            font-size: 14px;
        }
        a:visited {
            color: #b3639d;
        }
        a:hover {
            color: #d070a6;
        }

        .buttons-container {
            display: flex;
            gap: 10px; 
            justify-content: center; 
            width: 100%; 
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 24px;
                margin-bottom: 25px;
            }
            .registration-container {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            width: 65vw;
            height: 70vh;
            margin: 65px auto;
            padding: 35px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: white;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            <img src="../logo.jpg" alt="Logo">
        </div>
    </div>


    <!-- registration form -->
    <div class="registration-container">
        <h1>User Registration</h1>
        <form action="registration.php" id="registrationForm" method="POST" onsubmit="return validatePassword()">
            <input type="text" name="Admin_name" id="Admin_name" placeholder="Full Name" required><br>
            <input type="email" name="Admin_email" id="Admin_email" placeholder="Email Address" required><br>
            <input type="text" name="Admin_contactNumber" id="Admin_contactNumber" placeholder="Contact Number" required><br>
            <input type="text" name="Admin_username" id="Admin_username" placeholder="Username" required><br>
            <input type="password" name="Admin_password" id="Admin_password" placeholder="Password" required><br>
            <input type="password" name="passwordConf" id="passwordConf" placeholder="Confirm Password" required><br><br><br>

            <div class="buttons-container">
                <button type="submit">Register</button>
                <button type="button" onclick="document.getElementById('registrationForm').reset()">Cancel</button>
            </div>
            <br><br>
            <a href="login.php">Login</a>
        </form>
    </div>

    <script>
        /* Check that password == passwordConf (user-side) */
        function validatePassword() {
            var password = document.getElementById("Admin_password").value;
            var passwordConf = document.getElementById('passwordConf').value;
            if (password != passwordConf) {
                alert("Passwords do not match. Please try again.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
