<?php
include("../conn.php");

// delete existing announcement
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Announce_ID = mysqli_real_escape_string($con, $_POST['Announce_ID']);
    $sql = "DELETE FROM announcement WHERE Announce_ID = '$Announce_ID'";

    if (mysqli_query($con, $sql)) {
        echo '<script>alert("Announcement successfully deleted");
            window.location.href="announcement.php";
        </script>';
    }
}
?>