<?php
include("../conn.php");
include("admin.php");

$Quiz_ID = isset($_GET['id']) ? $_GET['id'] : 0;
$question = "SELECT question.*, quiz.Quiz_ID, quiz.Quiz_title, quiz.Quiz_timer, quiz.verificationStatus
FROM question
JOIN quiz ON question.Quiz_ID = quiz.Quiz_ID
WHERE quiz.Quiz_ID = '$Quiz_ID'
ORDER BY quiz.created_date DESC";


$qs_result = mysqli_query($con, $question);
if (mysqli_num_rows($qs_result) > 0) {
    $row = mysqli_fetch_assoc($qs_result);
} else {
    echo '<script>alert("Quiz not found.");
        window.history.back();
    </script>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Quiz</title>
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
            display: flex;
            flex-direction: column;
            width: 95vw;
        }

        /* Quiz Content */
        .quiz-container {
            flex: 2;
            width: 95vw;
            height: 500px;
            padding: 15px;
            border-radius: 5px;     
        }
        .quiz-title {
            margin-bottom: 10px;
        }
        .quiz-question {
            margin-bottom: 25px;
            margin-top: 30px;
            width: 80vw;
            height: auto;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            padding: 15px 25px;
            padding-top: 10px;
            border-radius: 8px;
        }
        .quiz-options {
            margin-top: 5px;
            height: auto;
        }
        .quiz-options input {
            margin-bottom: 15px;
        }
        .back-button {
            background-color: #e786cd;
            color: white;
            height: 35px;
            width: 75px;
            border: none;
            border-radius: 5px;
            margin-left: 20px;
            margin-top: 35px;
        }
        .back-button:hover {
            background-color: #d070a6;
            cursor: pointer;
        }
        em {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="quiz-container">
            <?php
            if (htmlspecialchars($row['Quiz_timer']) != 0) {
                $Quiz_timer = '' . htmlspecialchars($row['Quiz_timer']) . ' minutes';
            } else {
                $Quiz_timer = "not set";
            }
            echo '<h2 class="quiz-title">' . htmlspecialchars($row['Quiz_title']) . '</h2>';
            echo '<p><em>Status: ' . htmlspecialchars($row['verificationStatus']) . '</em> | <em> Timer: ' . $Quiz_timer . '</em></p>';
            ?>
            
            <form action="quizAnswers.php" id="quizAnswers" method="POSt">
                <?php
                // Reset result pointer to fetch all questions
                mysqli_data_seek($qs_result, 0);
                while ($question = mysqli_fetch_assoc($qs_result)) {
                    echo '<div class="quiz-question">';
                    echo '<p>' . htmlspecialchars($question['Question_text']) . '</p>';
                    echo '<div class="quiz-options">';
                    echo '<p>A. ' . htmlspecialchars($question['Question_choice_a']) . '</p>';
                    echo '<p>B. ' . htmlspecialchars($question['Question_choice_b']) . '</p>';
                    echo '<p>C. ' . htmlspecialchars($question['Question_choice_c']) . '</p>';
                    echo '<p>D. ' . htmlspecialchars($question['Question_choice_d']) . '</p>';
                    echo '</div>';
                    echo '<p><strong>Answer: ' . htmlspecialchars($question['correct_answer']) . '</strong></p>';
                    echo '</div>';
                }
                ?>
            </form>
            <button type="button" class="back-button" onclick="window.history.back()">Back</button>
        </div>
    </div>

    <script>
        function toggleResetQuiz() {
            document.getElementById('quizAnswers').reset();
        }
    </script>
</body>
</html>