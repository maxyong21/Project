<!--

-->

<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php")
?>

<?php
include("../conn.php");

// Check if a rejection request has been submitted
if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];

    if ($action == 'reject') {
        $update_query = "UPDATE quiz SET verificationStatus = 'rejected' WHERE Quiz_ID = ?";
        $stmt = $con->prepare($update_query);
        $stmt->bind_param("s", $id);
        if ($stmt->execute()) {
            echo '<script>alert("Quiz has been rejected.");
                window.location.href="homepage.php";
            </script>';
        } else {
            echo '<script>alert("Error updating quiz status.");
                window.location.href="homepage.php"
            </script>';
        }
        $stmt->close();
    }
}

// Fetch quizzes from the database
$allQuizzes = "SELECT quiz.*, instructor.Instructor_username
FROM quiz
JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID  
ORDER BY FIELD(quiz.verificationStatus, 'pending', 'approved', 'archived', 'rejected'), quiz.created_date DESC";
$allResult = mysqli_query($con, $allQuizzes);

$approvedQuizzes = "SELECT quiz.*, instructor.Instructor_username
FROM quiz
JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID
WHERE quiz.verificationStatus = 'approved'
ORDER BY quiz.created_date DESC";  
$approvedResult = mysqli_query($con, $approvedQuizzes);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hypertext EDU</title>
    <link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
        }
        
        .quiz-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            width: 80%;
            height: auto;
            z-index: 1;
        }
        .quiz-image {
            width: 125px;
            height: 125px;
            background-color: #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
            margin-right: 15px;
            text-align: center;
            z-index: 2;
        }
        .quiz-image p {
            padding: 5px;
        }
        .quiz-details {
            flex: 1;
            z-index: 2;
            padding: 10px;
            margin-right: 15px;
            line-height: 25px;
        }
        .quiz-actions {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-top: 10px;
            gap: 5px;
            z-index: 2;
        }
        .quiz-actions button {
            background-color: #e786cd;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 80px;
            margin-right: 10px;
        }
        button:hover {
            color: #d070a6;
        }
        em {
            font-size: 14px;
        }
        .quiz-image {
            width: 60px;
            height: 60px;
            margin-right: 25px;
            margin-left: 10px;
            background-color: #3b82f6;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            border-radius: 8px;
        }
        .quiz-details strong {
            font-size: 19px;
        }

        @media (max-width: 480px) {
            .quiz-actions {
            display: flex;
            flex-direction: column;
            margin-top: 10px;
            gap: 5px;
            z-index: 2;
            align-items: center;
            justify-content: center;
            }
            .quiz-actions button {
            background-color: #e786cd;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 60px;
            margin-right: 10px;
            font-size: 12px;
            text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Homepage</h2>
        <h3>Published Quizzes</h3>

        <!-- Loop through quiz data from database -->
        <?php 
        if (mysqli_num_rows($allResult) > 0) { 
            while ($row = mysqli_fetch_assoc($allResult)) {
                echo '<div class="quiz-container">';

                // Display quiz details
                echo '<div class="quiz-details">';
                echo '<p><strong>' . htmlspecialchars($row['Quiz_title']) . '</strong></p>';                
                echo '<p>' . htmlspecialchars($row['Quiz_description']) . '</p>';
                echo '<p><em>Posted by: ' . htmlspecialchars($row['Instructor_username']) . '</em> | <em>Posted on: ' . htmlspecialchars($row['created_date']) . '</em> | <em>Status: ' . htmlspecialchars($row['verificationStatus']) . '</em></p>';
                echo '</div>';

                // Display quiz actions
                echo '<div class="quiz-actions">';
                echo '<a href="viewQuiz.php?action=view&id=' . $row['Quiz_ID'] . '"><button class="view">View</button></a>'; // set location to quiz questions
                echo '</div>';

                echo '</div>';
            }
        } else {
            echo '<p>No pending quizzes found.</p>';
        }
        ?>
    </div>

    
    <div class="main-content">
        <h3>Approved Quizzes</h3>

        <!-- Loop through quiz data from database -->
        <?php 
        if (mysqli_num_rows($approvedResult) > 0) { 
            while ($row = mysqli_fetch_assoc($approvedResult)) {
                echo '<div class="quiz-container">';

                // Display quiz details
                echo '<div class="quiz-details">';
                echo '<p><strong>' . htmlspecialchars($row['Quiz_title']) . '</strong></p>';                
                echo '<p>' . htmlspecialchars($row['Quiz_description']) . '</p>';
                echo '<p><em>Posted by: ' . htmlspecialchars($row['Instructor_username']) . '</em> | <em>Posted on: ' . htmlspecialchars($row['created_date']) . '</em> | <em>Status: ' . htmlspecialchars($row['verificationStatus']) . '</em></p>';
                echo '</div>';

                // Display quiz actions
                echo '<div class="quiz-actions">';
                echo '<a href="viewQuiz.php?action=view&id=' . $row['Quiz_ID'] . '"><button class="view">View</button></a>'; 
                echo '<a href="homepage.php?action=reject&id=' . $row['Quiz_ID'] . '"><button class="reject">Reject</button></a>'; 
                echo '</div>';

                echo '</div>';
            }
        } else {
            echo '<p>No approved quizzes found.</p>';
        }
        ?>
    </div>
</body>
</html>
