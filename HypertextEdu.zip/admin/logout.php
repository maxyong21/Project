<?php
session_start();

// Unset all session variables
session_unset();

// Destroy the session
session_destroy();

echo '<script type="text/javascript">
    alert("You have successfully logged out.");
    window.location.href="login.php"; 
</script>'; // Redirect the user to the login page
exit;
?>