<?php
include("../conn.php");

$id = $_GET['id'];
$delete_query = "DELETE FROM item WHERE Item_ID = $id";
if (mysqli_query($con, $delete_query)) {
    echo '<script>alert("Theme successfully deleted");
            window.location.href = "theme.php";  
          </script>';
} else {
    echo '<script>alert("Error deleting theme: ' . mysqli_error($con) . '");
            window.location.href = "theme.php"; 
          </script>';
}
?>