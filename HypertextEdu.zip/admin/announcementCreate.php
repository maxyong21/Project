<?php
include("../conn.php");

session_start();
$Admin_ID = $_SESSION['Administrator_ID'];
// handle announcement form input
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Announce_subject = mysqli_real_escape_string($con, $_POST['announcementSubject']);
    $Announce_message = mysqli_real_escape_string($con, $_POST['announcementContent']);

    $result = mysqli_query($con, "SELECT MAX(Announce_ID) AS max_id FROM announcement");
    $row = mysqli_fetch_assoc($result);
    $max_id = $row['max_id'];
    if ($max_id) {
        $num_part = intval(substr($max_id, 3));
        $next_id = "ANN" . str_pad($num_part + 1, 3, '0', STR_PAD_LEFT);
    } else {
        $next_id = 'ANN001';
    }

    $sql = "INSERT INTO announcement (Announce_ID, Announce_subject, Announce_message, Announce_date, Administrator_ID) VALUES ('$next_id', '$Announce_subject', '$Announce_message', NOW(), $Admin_ID)";

    if (mysqli_query($con, $sql)) {
        echo '<script>alert("Announcement successfully created");
            window.location.href="announcement.php";
        </script>';
    } else {
        echo "Error: " . $sql . '<br>' . mysqli_error($con);
    }
}
?>