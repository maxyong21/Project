<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php");
?>

<?php
include("../conn.php");

// Check if a deletion request has been submitted
if (isset($_GET['action'], $_GET['type'], $_GET['id'])) {
    $action = $_GET['action'];
    $type = $_GET['type']; // 'student' or 'instructor'
    $id = $_GET['id'];

    if ($action == 'delete') {
        if ($type == 'student') {
            $delete_query = "DELETE FROM student WHERE Student_ID = ?";
        } elseif ($type == 'instructor') {
            $delete_query = "DELETE FROM instructor WHERE Instructor_ID = ?";
        }

        if (isset($delete_query)) {
            $stmt = $con->prepare($delete_query);
            $stmt->bind_param("s", $id);
            if ($stmt->execute()) {
                echo '<script>alert("User account has been deleted.");
                    window.location.href="viewUser.php";
                </script>';
            } else {
                echo '<script>alert("Error deleting user account.");
                    window.location.href="viewUser.php"
                </script>';
            }
            $stmt->close();
        }
    } else {
        if ($type == 'student') {
            $update_query = "UPDATE student SET verificationStatus = 'approved' WHERE Student_ID = ?";
        } elseif ($type == 'instructor') {
            $update_query = "UPDATE instructor SET verificationStatus = 'approved' WHERE Instructor_ID = ?";
        }

        if (isset($update_query)) {
            $stmt = $con->prepare($update_query);
            $stmt->bind_param("s", $id);
            if ($stmt->execute()) {
                echo '<script>alert("User account has been approved.");
                    window.location.href="viewUser.php";
                </script>';
            } else {
                echo '<script>alert("Error approving user account.");
                    window.location.href="viewUser.php"
                </script>';
            }
            $stmt->close();
        }
    }
}


$students_query = "SELECT Student_id AS id, Student_username, Student_email, Student_contact, verificationStatus, 'student' AS type FROM student WHERE verificationStatus = 'rejected' ORDER BY Student_ID ASC";
$instructors_query = "SELECT Instructor_id AS id, Instructor_username, Instructor_email, Instructor_contact, verificationStatus, 'instructor' AS type FROM instructor WHERE verificationStatus = 'rejected' ORDER BY Instructor_ID ASC";

$students_result = mysqli_query($con, $students_query);
$instructors_result = mysqli_query($con, $instructors_query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete User</title>
    <link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
        }

        .user-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: flex-start;
            margin: 20px;
        }

        .user-card {
            min-width: 200px;
            width: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            padding-top: 5px;
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }
        .actions {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }
        .delete {
            cursor: pointer;
            padding: 5px 15px;
            border: none;
            border-radius: 5px;
        }
        a {
            color: #e786cd;
            font-size: 14px;
        }
        a:hover {
            color: #d070a6;
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Users</h2>
        <h3>User Deletion</h3>
        <h4>Students</h4>
        <div class="user-container">
            <?php
            // Display rejected students
            while ($row = mysqli_fetch_assoc($students_result)) {
                echo "<div class='user-card'>
                    <p><strong>Student ID: </strong> {$row['id']}</p>
                    <p><strong>Username: </strong> {$row['Student_username']}</p>
                    <p><strong>Email: </strong> {$row['Student_email']}</p>
                    <p><strong>Contact No.: </strong> {$row['Student_contact']}</p>
                    <p><strong>Status: </strong> {$row['verificationStatus']}</p>

                    <div class='actions'>
                        <a href='deleteUser.php?action=approve&type=student&id={$row['id']}'>Approve</a>
                        <a href='deleteUser.php?action=delete&type=student&id={$row['id']}'>Delete</a>
                    </div>
                </div>";
            }

            if (mysqli_num_rows($students_result) == 0) {
                echo "<p>No rejected student accounts found.</p>";
            }
            ?>
        </div><br>
        <h4>Instructors</h4>
        <div class="user-container">
        <?php
            // Display rejected instructors
            while ($row = mysqli_fetch_assoc($instructors_result)) {
                echo "<div class='user-card'>
                    <p><strong>Instructor ID: </strong> {$row['id']}</p>
                    <p><strong>Username: </strong> {$row['Instructor_username']}</p>
                    <p><strong>Email: </strong> {$row['Instructor_email']}</p>
                    <p><strong>Contact No.: </strong> {$row['Instructor_contact']}</p>
                    <p><strong>Status: </strong> {$row['verificationStatus']}</p>

                    <div class='actions'>
                        <a href='deleteUser.php?action=approve&type=instructor&id={$row['id']}'>Approve</a>
                        <a href='deleteUser.php?action=delete&type=instructor&id={$row['id']}'>>Delete</a>
                    </div>
                </div>";
            }

            if (mysqli_num_rows($instructors_result) == 0) {
                echo "<p>No rejected instructor accounts found.</p>";
            }
            ?>
        </div>  
    </div>
</body>
</html>
