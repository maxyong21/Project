<?php
// Include your database connection file
include("../conn.php");

session_start();
$Administrator_ID = $_SESSION['Administrator_ID'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $Item_name = mysqli_real_escape_string($con, $_POST['Item_name']);
    $Item_price = mysqli_real_escape_string($con, $_POST['Item_price']);
    $Item_url = mysqli_real_escape_string($con, $_POST['Item_url']);
    $result = mysqli_query($con, "SELECT MAX(Item_ID) AS max_id FROM item");
        $row = mysqli_fetch_assoc($result);
        $max_id = $row['max_id'];
        if ($max_id) {
            $num_part = intval(substr($max_id, 3));
            $next_id = "ITM" . str_pad((int)$max_id + 1, 3, '0', STR_PAD_LEFT);
        } else {
            $next_id = 'ITM001';
        }

    $sql = "INSERT INTO item (Item_ID, Item_name, Item_date, Item_price, Item_url, Administrator_ID) 
    VALUES ('$next_id', '$Item_name', NOW(), '$Item_price', '$Item_url', '$Administrator_ID')";

    // Execute the query
    if (mysqli_query($con, $sql)) {
        echo '<script>alert("Theme successfully uploaded");
            window.location.href = "theme.php";  
        </script>';
    } else {
        echo '<script>alert("Error uploading theme: ' . mysqli_error($con) . '");
            window.location.href = "theme.php";  // Redirect to the themes page
        </script>';
    }
}
?>