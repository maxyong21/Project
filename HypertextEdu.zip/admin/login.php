<!--
username: johndoe123
password: admin1

username: jane123
password: admin2
-->

<?php
// Start the session
session_start();

// Include the database connection file
include("../conn.php");

// Initialize variables for error messages
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username and password from POST request
    $Admin_username = trim(mysqli_real_escape_string($con, $_POST['Admin_username']));
    $Admin_password = trim(mysqli_real_escape_string($con, $_POST['Admin_password']));

    // Query to check the existence of the user
    $sql = "SELECT * FROM administrator WHERE Admin_username = '$Admin_username'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) == 1) {
        // Fetch the user's data
        $row = mysqli_fetch_assoc($result);
        $hashed_password = $row['Admin_password'];  

        // Verify the provided password against the database password (password_verify doesn't work as $Admin_password not hashed)
        if (password_verify($Admin_password, $hashed_password)) {
            // Set session variables for the logged-in user
            $_SESSION['Administrator_ID'] = $row['Administrator_ID'];
            $_SESSION['Admin_username'] = $row['Admin_username'];

            // Redirect to the admin homepage or dashboard
            header("Location: homepage.php");
            exit();
        } else {
            $error = "Invalid password. Please try again.";
        }
    } else {
        $error = "Invalid username. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background-color: #fde0f8;
        }

        /* Navbar */
        .navbar {
            display: flex;
            align-items: center;
            background-color: #e786cd;
            padding: 10px;
            color: white;
            border-radius: 10px;
            height: 56px;
        }
        .navbar .logo {
            margin-left: 10px;
        }
        .navbar .logo img {
            height: 40px; /* Adjust height as needed */
            width: auto;
        }

        /* Login */
        .login-container {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            width: 65vw;
            height: 35vh;
            margin: 100px auto;
            padding: 35px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: white;
        }
        .login-container input {
            width: 90%;
            height: 25px;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .login-container input:focus {
            border-color: #e786cd;
            outline: none;
        }
        .login-container button {
            width: 100px;
            padding: 10px;
            background-color: #e786cd;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-container button:hover {
            background-color: #d070a6;
        }
        .login-container form {
            display: grid;
            place-items: center;
            width: 250px;
        }
        a {
            color: #e786cd;
            font-size: 14px;
        }
        a:visited {
            color: #b3639d;
        }
        a:hover {
            color: #d070a6;
        }

        .buttons-container {
            display: flex;
            gap: 10px; 
            justify-content: center; 
            width: 100%; 
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 24px;
                margin-bottom: 25px;
            }
            .login-container {
                display: flex;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                width: 65vw;
                height: 35vh;
                margin: 65px auto;
                padding: 35px;
                border: 1px solid #ccc;
                border-radius: 10px;
                background-color: white;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            <img src="../logo.jpg" alt="Logo">
        </div>
    </div>

    <!-- login form -->
    <div class="login-container">
        <h1>Admin Login</h1>
        <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form action="login.php" id="loginForm" method="POST">
            <input type="text" id="Admin_username" name="Admin_username" placeholder="Username" required><br>
            <input type="password" id="Admin_password" name="Admin_password" placeholder="Password" required><br><br>

            <div class="buttons-container">
                <button type="submit">Login</button>
                <button type="button" onclick="document.getElementById('loginForm').reset()">Cancel</button>
            </div>
            <br><br>
            <a href="registration.php">Register</a>
        </form>
    </div>
</body>
</html>
