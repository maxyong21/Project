<?php
// Include your database connection file
include("../conn.php");

// Retrieve user's ID and profile info
session_start();
$Administrator_ID = $_SESSION['Administrator_ID'];

$sql = "SELECT * FROM administrator WHERE Administrator_ID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $Administrator_ID);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Check if data retrieved
if (!$admin) {
    echo "Error: Admin data not found.";
    exit;
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
/* General Styles */
html, body {
    font-family: 'Times New Roman', Times, serif;
    margin: 0;
    padding: 0;
    background-color: #fde0f8;
    min-height: 100vh;
    min-width: 100vw;
    display: flex;
    flex-direction: column;
}

/* Navbar */
.navbar {
    display: flex;
    align-items: center;
    background-color: #e786cd;
    padding: 10px 20px;
    color: white;
    min-height: 60px;
    width: 100%;
    flex-wrap: wrap;
}
.navbar .logo {
    margin-right: 15px;
}
.navbar .logo img {
    height: 40px;
    width: auto;
}
.navbar .user-icon {
    align: right;
}
.navbar button, .navbar .user-icon {
    font-family: "Itim", serif;
    padding: 10px;
    color: rgb(0, 0, 0);
    cursor: pointer;
    border: none;
    background-color: #ffffff;
    border-radius: 10px;
}
.navbar button:hover, .navbar .user-icon:hover {
    background-color: #555;
}
.navbar .nav-buttons {
    flex: 1;
    display: flex;
    justify-content: center;
    margin: 10px;
}
.navbar .nav-buttons button {
    margin: 0 5px;
}

/* Manage Account Dropdown */
.account-dropdown {
    position: absolute;
    top: 65px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    width: 150px;
}
.account-dropdown a {
    display: block;
    padding: 10px 20px;
    color: #333;
    text-decoration: none;
    text-align: center;
}
.account-dropdown a:hover {
    background-color: #eee;
}
.manage-account-container {
    position: relative;
    display: inline-block;
}

/* Manage Quiz Dropdown */
.quiz-dropdown {
    position: absolute;
    top: 65px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    width: 150px;
}
.quiz-dropdown a {
    display: block;
    padding: 10px 20px;
    color: #333;
    text-decoration: none;
    text-align: center;
}
.quiz-dropdown a:hover {
    background-color: #eee;
}
.manage-quiz-container {
    position: relative;
    display: inline-block;
}

/* Manage Upload Dropdown */
.upload-dropdown {
    position: absolute;
    top: 65px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    width: 150px;
}
.upload-dropdown a {
    display: block;
    padding: 10px 20px;
    color: #333;
    text-decoration: none;
    text-align: center;
}
.upload-dropdown a:hover {
    background-color: #eee;
}
.manage-upload-container {
    position: relative;
    display: inline-block;
}

/* Profile Dropdown */
.profile-dropdown {
    position: absolute;
    top: 70px;
    right: 0%;
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    width: 100px;
}
.profile-dropdown a {
    display: block;
    padding: 10px 20px;
    color: #333;
    text-decoration: none;
    text-align: center;        
}
.profile-dropdown a:hover {
    background-color: #eee;
}
.manage-profile-container {
    position: relative;
    display: inline-block;
    margin-right: 5%;
}

/* Profile Section */
.profile-container {
    position: fixed;
    width: 300px; /* Adjust as needed */
    height: 100vh;
    margin: 0;
    right: 0;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1000; 
}
.profile-details {
    text-align: left;
    z-index: 1000;
}

.edit-button {
    background-color: transparent;
    border: none;
    cursor: pointer;
    font-size: 12px;
    margin-top: 0px;
    float: right;
}
.edit-button:hover {
    opacity: 0.8;
}
.edit-form {
    display: grid;
    place-items: center;
    position: fixed;
    top: 50%;
    left: 50%;
    width: 350px;
    transform: translate(-50%, -50%); /* centers form */
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin: auto;
}
.edit-form input {
    width: 200px;
    padding: 10px;
    margin: 10px 0px 10px 0px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
    box-sizing: border-box;
}
.edit-form input:focus {
    border-color: #e786cd;
    outline: none;
}
.edit-form button {
    width: 100px;
    padding: 10px;
    margin-top: 5px;
    background-color: #e786cd;
    border: none;
    color: #fff;
    font-size: 12px;
    cursor: pointer;
    border-radius: 5px;
}
.edit-form button:hover {
    color: #d070a6;
}

.close-button {
    background-color: white;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 5px 5px;
    cursor: pointer;
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 14px;
}
.close-button:hover {
    opacity: 0.8;
}
@media (max-width: 768px) {
    html, body {
        width: 100vw;
        height: 100vh;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
    }
    .navbar {
        flex-direction: row; /* Stack navbar items */
        align-items: center;
        min-height: 85px;
        left: 10%;
        width: 100%;
    }

    .navbar .user-icon {
        margin-right: 5%;
    }

    .nav-buttons {
        flex-direction: row;
        gap: 5px;
    }

    .nav-buttons button {
        width: 100px;
        text-align: center;
        height: 60px;
    }

    .dropdown {
        position: relative; /* Stack dropdowns within parent */
        top: auto;
        left: auto;
        width: 100%; /* Full width dropdown */
    }

    .manage-profile-container {
        margin-right: 5%;
    }

    .profile-container {
        width: 45%; 
        top: 7.35%;
        right: 5%;
    }

    .edit-form {
        width: 50%; /* Fit smaller screens */
        z-index: 1000;
    }
        }

@media (max-width: 480px) {
    html, body {
        width: 100vw;
        height: 100vh;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
    }
    .navbar {
        flex-direction: row; /* Stack navbar items */
        align-items: center;
        min-height: 80px;
        left: 10%;
        width: 100%;
    }

    .nav-buttons {
        flex-direction: row;
        gap: 8px;
        flex-wrap: wrap;
        
    }

    .nav-buttons button {
        width: 40px;
        text-align: center;
        height: 60px;
        font-size: 7px;
        height: 25px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .navbar .logo {
        margin-right: 5px;
    }
    .navbar .logo img {
        height: 30px;
        width: auto;
    }   

    .navbar .manage-profile-container {
        height: 30px;
        width: 35px;
        font-size: 10px;
        text-align: center;
        margin-right: 9%;
    }

    .dropdown {
        position: relative; /* Stack dropdowns within parent */
        top: auto;
        left: auto;
        height: 100%; /* Full width dropdown */
    }

    .profile-container {
        width: 40%; /* Full width for profile */
        top: 9.45%;
        right: 8.5%;
    }

    .edit-form {
        width: 50%; /* Fit smaller screens */
        z-index: 1000;
    }
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            <img src="../logo.jpg" alt="Logo">
        </div>

        <div class="nav-buttons">
            <button onclick="window.location.href='homepage.php';">HOME</button>
            <button onclick="window.location.href='websiteReview.php';">WEBSITE REVIEW</button>
            <div class="manage-account-container">
                <button onclick="toggleAccountDropdown()">MANAGE ACCOUNT</button>
                <!-- Manage Account Dropdown -->
                <div class="account-dropdown" id="accountDropdown">
                    <a href="viewUser.php">View User</a>
                    <a href="verifyUser.php">Verify User</a>
                    <a href="deleteUser.php">Delete User</a>
                </div>
            </div>
            <div class="manage-quiz-container">
                <button onclick="toggleQuizDropdown()">MANAGE QUIZ</button>
                <!-- Manage Quiz Dropdown -->
                <div class="quiz-dropdown" id="quizDropdown">
                    <a href="verifyQuiz.php">Verify Quiz</a>
                    <a href="archiveQuiz.php">Archive Quiz</a>
                    <a href="deleteQuiz.php">Delete Quiz</a>
                </div>
            </div>
            <div class="manage-upload-container">
                <button onclick="toggleUploadDropdown()">UPLOAD</button>
                <!-- Manage Upload Dropdown -->
                 <div class="upload-dropdown" id="uploadDropdown">
                    <a href="announcement.php">Announcement</a>
                    <a href="theme.php">Theme</a>
                </div>
            </div>
        </div>
        <div class="manage-profile-container">
            <div class="user-icon" onclick="toggleProfileDropdown()">👤</div>
                <!-- Profile Dropdown -->
                <div class="profile-dropdown" id="profileDropdown">
                    <a href="#" id="profileMenu">Profile</a>
                    <a href="logout.php">Log Out</a>
                </div>
            </div>
        </div>

        <!-- Profile Section (initially hidden) -->
        <div id="profileSection" class="profile-container" style="display: none;">
            <button class="close-button" onclick="closeProfileSection()">✖️</button>    
            <div class="profile-details">
                <p>Username: <span id="Admin_username"><?php echo htmlspecialchars($admin['Admin_username'])?></span></p>
                <p>Admin ID: <span id="Administrator_ID"><?php echo htmlspecialchars($admin['Administrator_ID'])?></span></p>
                <hr>
                <h4>PERSONAL INFORMATION <button class="edit-button" onclick="editInfo()">✏️</button></h4>
                <p>Name: <span id="Admin_name"><?php echo htmlspecialchars($admin['Admin_name'])?></span></p>
                <p>Email: <span id="Admin_email"><?php echo htmlspecialchars($admin['Admin_email'])?></span></p>
                <p>Contact Number: <span id="Admin_contactNumber"><?php echo htmlspecialchars($admin['Admin_contactNumber'])?></span></p>
            </div>
        </div>
        <div class="edit-form" id="editForm" style="display: none;">
            <form id="editFormFields" action="updateProfile.php" method="POST">
                <input type="text" id="editName" name="editName" placeholder="Name" value="<?php echo htmlspecialchars($admin['Admin_name']);?>"><br>
                <input type="email" id="editEmail" name="editEmail" placeholder="Email" value="<?php echo htmlspecialchars($admin['Admin_email']);?>"><br>
                <input type="text" id="editContact" name="editContact" placeholder="Contact Number" value="<?php echo htmlspecialchars($admin['Admin_contactNumber']);?>"><br>
                <button type="submit">Save Changes</button>
                <button type="button" id="cancelButton" onclick="cancelEdit()">Cancel</button>
            </form>
        </div>
    </div>

    
    <script>
        function toggleAccountDropdown() {
            const accountDropdown = document.getElementById('accountDropdown');
            const quizDropdown = document.getElementById('quizDropdown');
            const uploadDropdown = document.getElementById('uploadDropdown');
            const profileDropdown = document.getElementById('profileDropdown');
            const profileSection = document.getElementById('profileSection');
            if (quizDropdown.style.display === 'block' || uploadDropdown.style.display === 'block' || profileDropdown.style.display === 'block' || profileSection.style.display === 'block') {
                quizDropdown.style.display = 'none';
                uploadDropdown.style.display = 'none';
                profileDropdown.style.display = 'none';
                profileSection.style.display = 'none';
            }
            accountDropdown.style.display = accountDropdown.style.display === 'block' ? 'none' : 'block';
        }

        function toggleQuizDropdown() {
            const quizDropdown = document.getElementById('quizDropdown');
            const accountDropdown = document.getElementById('accountDropdown');
            const uploadDropdown = document.getElementById('uploadDropdown');
            const profileDropdown = document.getElementById('profileDropdown');
            const profileSection = document.getElementById('profileSection');
            if (accountDropdown.style.display === 'block' || uploadDropdown.style.display === 'block' || profileDropdown.style.display === 'block' || profileSection.style.display === 'block') {
                accountDropdown.style.display = 'none';
                uploadDropdown.style.display = 'none';
                profileDropdown.style.display = 'none';
                profileSection.style.display = 'none';
            }
            quizDropdown.style.display = quizDropdown.style.display === 'block' ? 'none' : 'block';
        }

        function toggleUploadDropdown() {
            const uploadDropdown = document.getElementById('uploadDropdown');
            const quizDropdown = document.getElementById('quizDropdown');
            const accountDropdown = document.getElementById('accountDropdown');
            const profileDropdown = document.getElementById('profileDropdown');
            const profileSection = document.getElementById('profileSection');
            if (quizDropdown.style.display === 'block' || accountDropdown.style.display === 'block' || profileDropdown.style.display === 'block' || profileSection.style.display === 'block') {
                quizDropdown.style.display = 'none';
                accountDropdown.style.display = 'none';
                profileDropdown.style.display = 'none';
                profileSection.style.display = 'none';
            }
            uploadDropdown.style.display = uploadDropdown.style.display === 'block' ? 'none' : 'block';
        }

        function toggleProfileDropdown() {
            const dropdown = document.getElementById('profileDropdown');
            const quizDropdown = document.getElementById('quizDropdown');
            const accountDropdown = document.getElementById('accountDropdown');
            const uploadDropdown = document.getElementById('uploadDropdown');
            if (quizDropdown.style.display === 'block' || accountDropdown.style.display === 'block' || uploadDropdown.style.display === 'block') {
                quizDropdown.style.display = 'none';
                accountDropdown.style.display = 'none';
                uploadDropdown.style.display = 'none';
            }
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // open user profile section
        function showProfileSection() {
            const profileSection = document.getElementById('profileSection');
            const profileDropdown = document.getElementById('profileDropdown');

            if (profileDropdown.style.display === 'block') {
                profileDropdown.style.display = 'none';
            }
            
            profileSection.style.display = profileSection.style.display === 'none' ? 'block' : 'none';
        }
        document.getElementById('profileMenu').addEventListener('click', showProfileSection);
    
        // close user profile section
        function closeProfileSection() {
            document.getElementById('profileSection').style.display = 'none';
        }

        // open edit form
        function editInfo() {
            document.getElementById('profileSection').style.display = 'none';
            document.getElementById('editForm').style.display = 'block';
        }

        // close edit form
        function cancelEdit() {
            document.getElementById('editForm').style.display = 'none';
            document.getElementById('editForm').reset();
        }

    </script>
</body>
</html>