<?php
// Include database connection
include("../conn.php");

// Start the session to get the admin ID
session_start();
$admin_id = $_SESSION['Administrator_ID'];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form input values and sanitize them
    $name = mysqli_real_escape_string($con, $_POST['editName']);
    $email = mysqli_real_escape_string($con, $_POST['editEmail']);
    $contact = mysqli_real_escape_string($con, $_POST['editContact']);

    // Check if new email already registered
    $email_check_sql = "SELECT COUNT(*) FROM administrator WHERE Admin_email = ? AND Administrator_ID != ?";
    $stmt = $con->prepare($email_check_sql);
    $stmt->bind_param("si", $email, $admin_id);
    $stmt->execute();
    $stmt->bind_result($email_exists);
    $stmt->fetch();
    $stmt->close();

    // Check if new contact number already registered
    $contact_check_sql = "SELECT COUNT(*) FROM administrator WHERE Admin_contactNumber = ? AND Administrator_ID != ?";
    $stmt = $con->prepare($contact_check_sql);
    $stmt->bind_param("si", $contact, $admin_id);
    $stmt->execute();
    $stmt->bind_result($contact_exists);
    $stmt->fetch();
    $stmt->close();

    if ($email_exists > 0) {
        echo '<script>alert("Error: Email already registered.")</script>';
        echo '<script>window.history.back()</script>';
    } elseif ($contact_exists > 0) {
        echo '<script>alert("Error: Contact number already registered.")</script>';
        echo '<script>window.history.back()</script>';
    } else {
        // Update query to modify admin details
        $update_sql = "UPDATE administrator SET Admin_name = ?, Admin_email = ?, Admin_contactNumber = ? WHERE Administrator_ID = ?";
        $stmt = $con->prepare($update_sql);
        $stmt->bind_param("sssi", $name, $email, $contact, $admin_id);

        // Execute the update and provide feedback
        if ($stmt->execute()) {
            echo "Profile updated successfully.";
            // Optionally redirect to the profile or dashboard page
            header("Location: homepage.php");
            exit();
        } else {
            echo "Error updating profile: " . $stmt->error;
        }
        // Close the statement
        $stmt->close();
    }
    $con->close();
}
?>
