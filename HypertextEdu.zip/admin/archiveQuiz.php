<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php")
?>

<?php
// Include your database connection file
include("../conn.php");

// Fetch quizzes from the database
$sql = "SELECT quiz.*, instructor.Instructor_username
FROM quiz
JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID 
WHERE quiz.verificationStatus = 'archived'
ORDER BY quiz.created_date DESC";  
$result = mysqli_query($con, $sql);

?>

<?php
include("../conn.php");

// Check if an approval or deletion request has been submitted
if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];

    if ($action == 'approve') {
        $update_query = "UPDATE quiz SET verificationStatus = 'approved' WHERE Quiz_ID = ?";
        $stmt = $con->prepare($update_query);
        $stmt->bind_param("s", $id);
    } elseif (action == 'delete') {
        $delete_query = "DELETE FROM quiz WHERE Quiz_ID = ?";
        $stmt = $con->prepare($delete_query);
        $stmt->bind_param("s", $id);
    } elseif ($action == 'view') {
    } else {
        echo '<script>alert("Invalid action specified.");
            window.location.href="archiveQuiz.php";
        </script>';
        exit;
    }

    if ($stmt->execute()) {
        echo '<script>alert("Quiz has been ' . ($action == 'approve' ? 'approved' : 'deleted') . '.");
            window.location.href="archiveQuiz.php";
        </script>';
    } else {
        echo '<script>alert("Error updating quiz status.");
            window.location.href="archiveQuiz.php"
        </script>';
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archive Quiz</title>
    <link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
        }

        .quiz-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            width: 75%;
            height: auto;
        }
        .quiz-details {
            flex: 1;
            margin-right: 20px;
            margin-left: 20px;
        }
        .quiz-actions {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            padding: 5px;
            gap: 5px;
        }
        .quiz-actions button {
            background-color: #e786cd;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 80px;
        }
        button:hover {
            color: #d070a6;
        }
        em {
            font-size: 14px;
        }

        @media (max-width: 480px) {
            .quiz-actions button {
            background-color: #e786cd;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 55px;
            height: 25px;
            font-size: 9px;
            }
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Quizzes</h2>
        <h3>Archived Quizzes</h3>
        
        <!-- Loop through quiz data from database -->
        <?php 
        if (mysqli_num_rows($result) > 0) { 
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="quiz-container">';


                // Display quiz details
                echo '<div class="quiz-details">';
                echo '<p><strong>' . htmlspecialchars($row['Quiz_title']) . '</strong></p>';                
                echo '<p>' . htmlspecialchars($row['Quiz_description']) . '</p>';
                echo '<p><em>Posted by: ' . htmlspecialchars($row['Instructor_username']) . '</em> | <em>Posted on: ' . htmlspecialchars($row['created_date']) . '</em></p>';
                echo '</div>';

                // Display quiz actions
                echo '<div class="quiz-actions">';
                echo '<a href="viewQuiz.php?action=view&id=' . $row['Quiz_ID'] . '"><button class="view">View</button></a>'; 
                echo '<a href="archiveQuiz.php?action=approve&id=' . $row['Quiz_ID'] . '"><button class="approve">Approve</button></a>';
                echo '<a href="archiveQuiz.php?action=delete&id=' . $row['Quiz_ID'] . '"><button class="reject">Delete</button></a>';
                echo '</div>';

                echo '</div>';
            }
        } else {
            echo '<p>No archived quizzes found.</p>';
        }
        ?>
    </div>
</body>
</html>
