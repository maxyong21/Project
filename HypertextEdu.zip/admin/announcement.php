<!-- 
admin id in announcement table
-->

<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php")
?>

<?php
include("../conn.php");

// Fetch announcements from the database
$sql = "SELECT announcement.*, administrator.Admin_username
FROM announcement
JOIN administrator on administrator.Administrator_ID = announcement.Administrator_ID
ORDER BY announcement.Announce_date DESC";  // Modify this SQL query based on your actual database schema
$result = mysqli_query($con, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Annnouncements</title>
        <style>
        /* Main Content */
        .main-content {
            padding: 20px;
        }

        .announcement-form {
            margin-top: 10px;
            padding-left: 15px;
            padding-right: 15px;
            padding-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: white;
        }
        .announcement-form input {
            height: 10px;            
        }
        .announcement-form textarea {
            margin-bottom: 30px;
        }
        .announcement-form input, .announcement-form textarea {
            width: 92%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            float: right;
        }
        .announcement-form button {
            background-color: #e786cd;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .announcement-form button:hover {
            color: #d070a6;
        }

        .announcement-item {
            background-color: white;
            padding-left: 30px;
            padding-right: 30px;
            padding-bottom: 30px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 15px 0;
            line-height: 25px;
            height: auto;
        }

        .existing-announcements button {
            background-color: #e786cd;
            color: white;
            padding: 7px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            float: right;
        }
        em {
            font-size: 14px;
        }
        .announcement-item h4 {
            font-size: 18px;
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Announcements</h2>

        <!-- Create Announcement Form -->
        <div class="announcement-form">
            <h3>Create Announcement</h3>
            <form id="announcementForm" action="announcementCreate.php" method="POST">
                <label for="announcementSubject">Subject:</label>
                <input type="text" id="announcementSubject" name="announcementSubject" required><br><br>
                <label for="announcementContent">Content:</label>
                <textarea id="announcementContent" name="announcementContent" rows=8 required></textarea><br><br>
                <button type="submit">Create Announcement</button>
                <button type="button" onclick="document.getElementById('announcementForm').reset()">Cancel</button>
            </form>
        </div>

        <!-- Display existing announcements -->
        <div class="existing-announcements">
            <br><br><h3>Existing Announcements</h3>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="announcement-item">';
                    echo '<h4>' . htmlspecialchars($row['Announce_subject']) . '</h4>';
                    echo '<p>' . nl2br(htmlspecialchars($row['Announce_message'])) . '</p><br>';
                    echo '<em>Posted by: ' . htmlspecialchars($row['Admin_username']) . ' </em> | <em>Posted on: ' . htmlspecialchars($row['Announce_date']) . '</em>';
                    
                    // delete announcement
                    echo '<form action="announcementDelete.php" method="POST" style="display:inline;">';
                    echo '<input type="hidden" name="Announce_ID" value="' . htmlspecialchars($row['Announce_ID']) . '">';
                    echo '<button type="submit" onclick="return confirm(\'Confirm deletion?\')">Delete</button>';
                    echo '</form>';

                    echo '</div><hr>';
                }
            } else {
                echo '<p>No existing announcements.</p>';
            }
            ?>
    </div>
</body>
</html>
