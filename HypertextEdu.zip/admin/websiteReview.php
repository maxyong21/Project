<?php
// Include your database connection file
include("../conn.php");

// Include admin.php
include("admin.php")
?>

<?php
include("../conn.php");

// Fetch reviews from the database
$review_query = "SELECT review.*, student.Student_username, student.verificationStatus
FROM review
JOIN student ON review.Student_ID = student.Student_ID
WHERE student.verificationStatus = 'approved'
ORDER BY review.Review_date DESC";  
$review_result = mysqli_query($con, $review_query);
if (!$review_result) {
    echo "Error fetching reviews data: " . mysqli_error($con);
}

$unapproved_review_query = "SELECT review.*, student.Student_username, student.verificationStatus
FROM review
JOIN student ON review.Student_ID = student.Student_ID
WHERE student.verificationStatus = 'rejected'";  
$unapproved_review_result = mysqli_query($con, $unapproved_review_query);

?>

<?php
include("../conn.php");

// Check if a deletion request has been submitted
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $delete_query = "DELETE FROM review WHERE Review_ID = ?";
    $stmt = $con->prepare($delete_query);
    $stmt->bind_param("s", $id);
    if ($stmt->execute()) {
        echo '<script>alert("Review has been deleted.");
            window.location.href="websiteReview.php";
        </script>';
    } else {
        echo '<script>alert("Error deleting review.");
            window.location.href="websiteReview.php"
        </script>';
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Review</title>
    <link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
        }

        .reviews-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            padding-top: 5px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            width: 75%;
            height: auto;
        }
        .reviews-details {
            flex: 1;
            padding-right: 10px;
        }
        .reviews-actions {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-top: 10px;
            gap: 5px;
        }
        .reviews-actions button {
            background-color: #e786cd;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            color: #d070a6;
        }
        em {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h2>Website Review</h2>
        <h3>Reviews</h3>

        <!-- Loop through reviews data from database -->
        <?php 
        if (mysqli_num_rows($review_result) > 0) { 
            while ($row = mysqli_fetch_assoc($review_result)) {
                echo '<div class="reviews-container">';

                // Display review details
                echo '<div class="reviews-details">';
                echo '<h3>' . htmlspecialchars($row['Student_username']) . '</h3>';                
                echo '<p>' . htmlspecialchars($row['Review_Title']) . '</p>';
                echo '<p>' . htmlspecialchars($row['Review_message']) . '</p>';
                echo '<p><em>Rating: ' . htmlspecialchars($row['star_rating']) . '/5</em> | <em>Posted on: ' . htmlspecialchars($row['Review_date']) . '</em></p>';
                echo '</div>';

                // Display review actions
                echo '<div class="reviews-actions">';
                echo '<a href="websiteReview.php?action=delete&id=' . $row['Review_ID'] . '"><button class="delete">Delete</button></a>';
                echo '</div>';

                echo '</div>';
            }
        } else {
            echo '<p><strong>No reviews found.</strong></p>';
        }

        echo '<br><br><br><h3>Reviews from Rejected Accounts</h3>';
        if (mysqli_num_rows($unapproved_review_result) > 0) { 
            while ($row = mysqli_fetch_assoc($review_result)) {
                echo '<div class="reviews-container">';

                // Display review details
                echo '<div class="reviews-details">';
                echo '<h3>' . htmlspecialchars($row['Student_username']) . '</h3>';                
                echo '<p>' . htmlspecialchars($row['Review_Title']) . '</p>';
                echo '<p>' . htmlspecialchars($row['Review_message']) . '</p>';
                echo '<p><em>Rating: ' . htmlspecialchars($row['star_rating']) . '/5</em> | <em>Posted on: ' . htmlspecialchars($row['Review_date']) . '</em></p>';
                echo '</div>';

                // Display review actions
                echo '<div class="reviews-actions">';
                echo '<a href="websiteReview.php?action=delete&id=' . $row['Review_ID'] . '"><button class="delete">Delete</button></a>';
                echo '</div>';

                echo '</div>';
            }
        } else {
            echo '<p><strong>No hidden reviews found.</strong></p>';
        }
        ?>
    </div>
</body>
</html>

