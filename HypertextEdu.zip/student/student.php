<?php
include("../conn.php");

session_start();
$Student_ID = $_SESSION['Student_ID'];

$student_info = "SELECT * FROM student WHERE Student_ID = ?";
$stmt = $con->prepare($student_info);
$stmt->bind_param("s", $Student_ID);
$stmt->execute();
$student_info_result = $stmt->get_result();
$student = $student_info_result->fetch_assoc();

if (!$student) {
    echo "Error: Student data not found.";
    exit;
}

$stmt->close();

if (!isset($_SESSION['Student_ID'])) {
    echo "Error: Student ID not set in session.";
    exit;
}

$quiz = "SELECT * FROM quiz";
$quiz_result = mysqli_query($con, $quiz);

$background_sql = "SELECT item.Item_url, inventory.status
FROM inventory
JOIN item ON inventory.Item_ID = item.Item_ID
WHERE inventory.Student_ID = '{$_SESSION['Student_ID']}' AND inventory.status = 'applied'";
$background_result = mysqli_query($con, $background_sql);
$background_image_url = '';
$is_applied = false;

if ($background_result && mysqli_num_rows($background_result) > 0) {
    $row = mysqli_fetch_assoc($background_result);
    $background_image_url = htmlspecialchars($row['Item_url']);
    $is_applied = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
/* General Styles */
body {
    /* Set the background image dynamically if theme applied */
    <?php if ($is_applied): ?>
        background-image: url('<?php echo $background_image_url; ?>');
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-position: center;
    <?php else: ?>
        background-color: #f9fafb;
    <?php endif; ?>
    font-family: 'Arial', sans-serif;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin: 0;
    height: 100%;
    width: 100%;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #1f2937;
    padding: 10px 20px;
    color: white;
    width: 100%;
    min-height: 60px;
    height: auto;
    flex-direction: row;
    align-items: center;
    flex-wrap: wrap;
}
.navbar .logo {
    margin-left: 15px;
}
.navbar .logo img {
    height: 40px; /* Adjust height as needed */
    width: auto;
}
.navbar button, .navbar .user-icon, .navbar .search-icon {
    font-family: "Itim", serif;
    padding: 10px;
    color: rgb(0, 0, 0);
    cursor: pointer;
    border: none;
    background-color: #ffffff;
    border-radius: 10px;
    transition: background-color 0.2s, color 0.2s;
}
.navbar button:hover, .navbar .user-icon:hover, .navbar .search-icon:hover {
    background-color: #cbd5e1;
    color: #1f2937;
}
.navbar .nav-buttons {
    flex: 1;
    display: flex;
    justify-content: center;
    margin: 10px;
    width: 100%;
    position: absolute;
    z-index: 1000;
}

.navbar .square-buttons {
    flex: 1;
    display: flex;
    width: 50px;
    margin-left: auto;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

.navbar .nav-buttons button {
    margin: 0 5px;
}
.navbar .user-icon, .navbar .search-icon {
    margin-right: 8px;
    flex: 1;
}

@media (max-width: 768px) {
    .navbar .logo {
        margin-bottom: 15px;
    }

    .profile-container {
        width: 45%; 
        top: 7.35%;
        right: 5%;
    }

    .edit-form {
        max-width: 350px;
    }

    .search-dropdown {
        width: 80%;
    }
}

@media (max-width: 480px) {
    html, body {
        padding: 0;
        margin-right: -10%;
        box-sizing: border-box;
        width: 100%;
        height: 100vh;
    }

    .navbar {
        flex-direction: column;
        align-items: flex-start;
        width: 120vw;
        height: auto;
        min-height: 85px;
        padding-left: 100px;
    }
    .nav-buttons {
        width: 60%;
        flex-direction: row;
        display: flex;
        padding-bottom: 15px;
        padding-left: 8%;
    }
    .nav-icons {
        display: flex;
        flex-direction: row;
    }
    .navbar .user-icon, .navbar .search-icon {
        width: 15px;
        height: 15px;
        font-size: 12px;
        margin-bottom: 1px;
    }
    .nav-buttons button {
        width: 20%;
        text-align: center;
        font-size: 8px;
        height: 30px;
        padding-left: 3px;
        padding-right: 3px;
    }
    .nav-buttons:hover {
        width: 25%;
    }
    .nav-buttons p{
        display: none;
    }
    .nav-icons .manage-profile-container {
        margin-left: 2px;
    }

}

/* Profile Dropdown */
.profile-dropdown {
    position: absolute;
    top: 70px;
    right: 0%;
    background-color: #fff;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    width: 100px;
    z-index: 1000;
}
.profile-dropdown a {
    display: block;
    padding: 10px 20px;
    color: #333;
    text-decoration: none;
    text-align: center;
    transition: background-color 0.2s;        
}
.profile-dropdown a:hover {
    background-color: #eee;
}
.manage-profile-container {
    position: absolute;
    right: 20px;
    display: flex;
}

/* Profile Section */
.profile-container {
    position: fixed;
    top: 80px;
    right: 0;
    width: 300px; /* Adjust as needed */
    height: 100vh;
    margin: 0;
    padding: 20px;
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 15px;
    z-index: 1; 
}
.profile-details {
    text-align: left;
    z-index: 1000;
    display: block;
    color: black;
}

.edit-button {
    background-color: transparent;
    border: none;
    cursor: pointer;
    font-size: 12px;
    margin-top: 0px;
    float: right;
}
.edit-button:hover {
    opacity: 0.8;
}
.edit-form {
    display: grid;
    place-items: center;
    position: fixed !important;
    top: 50%;
    left: 50%;
    width: 350px;
    transform: translate(-50%, -50%); /* centers form */
    background-color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin: auto;
    z-index: 1000 !important;
}
.edit-form input {
    width: 200px;
    padding: 10px;
    margin: 10px 0px 10px 0px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
    box-sizing: border-box;
}
.edit-form input:focus {
    border-color: #3b82f6;
    outline: none;
}
.edit-form button {
    width: 100px;
    padding: 10px;
    margin-top: 5px;
    background-color: #3b82f6;
    border: none;
    color: #fff;
    font-size: 14px;
    cursor: pointer;
    border-radius: 5px;
}
.edit-form button:hover {
    color: #2f6bcc;
}

.close-button {
    background-color: white;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 5px 5px;
    cursor: pointer;
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 14px;
}
.close-button:hover {
    opacity: 0.8;
}

/* Search Icon */
.search-icon {
    font-size: 16px;
}
.search-bar-container {
    position: absolute;
    right: 75px;
    display: flex;
}

/* Search Bar Dropdown */
.search-dropdown {
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: row;
    top: 70px;
    right: 0px;
    background-color: transparent;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
    display: none;
    width: 290px;
    height: 40px;
    z-index: 1000;
}
.search-dropdown input {
    flex: 1;
    width: 125px;
    height: 30px;
    padding: 5px;
    padding-left: 8px;
    border-radius: 5px;
    border: none;
    margin-left: 8px;
    outline: none;
}
.search-dropdown input:focus {
    border-color: #3b82f6;
    outline: none;
}
.search-dropdown .search-button {
    height: 30px;
    width: 40px;
    border-radius: 5px;
    flex: 1;
    padding: 2px;
    border: 0;
    background-color: #3b82f6;
    color: #fff;
    font-size: 14px;
    margin-right: 2px;
    cursor: pointer;
}
.search-dropdown .cancel-search {
    height: 30px;
    width: 70px;
    border-radius: 5px;
    padding: 2px;
    border: 0;
    background-color: #3b82f6;
    color: #fff;
    font-size: 14px;
    cursor: pointer;
}
.search-dropdown button:hover {
    background-color: #2f6bcc;
    color: white;
}
</style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
            <div class="logo">
                <img src="../logo.jpg" alt="Logo">
            </div>

            <div class="nav-buttons">
                <button onclick="window.location.href='homepage_loggedin.php';">HOME</button>
                <button onclick="window.location.href='themeShop.php';">THEME SHOP</button>
                <button onclick="window.location.href='websiteReview.php';">REVIEWS</button>
            </div>
        
            <div class="square-buttons">
                <div class="search-bar-container">
                    <div class="search-icon" onclick="toggleSearchDropdown()">🔎</div>
                    <!-- Search Bar Dropdown -->
                    <div class="search-dropdown" id="searchBar" style="display:none;">
                        <input type="text" id="quizCodeInput" name="quizCodeInput" placeholder="Enter Quiz Code">
                        <button type="button" id="searchButton" class="search-button" onclick="joinQuiz()">Go</button>
                        <button type="button" id="cancelSearch" class="cancel-search">Cancel</button>
                    </div>
                </div>
                <div class="manage-profile-container">
                    <div class="user-icon" onclick="toggleProfileDropdown()">👤</div>
                    <!-- Profile Dropdown -->
                    <div class="profile-dropdown" id="profileDropdown" style="display:none;">
                        <a href="#" id="profileMenu">Profile</a>
                        <a href="logout.php">Log Out</a>
                    </div>
                </div>
            </div>
        </div>

        
        <!-- Profile Section (initially hidden) -->
        <div id="profileSection" class="profile-container" style="display: none;">
        <button class="close-button" onclick="closeProfileSection()">✖️</button>
        <div id="profileDetails" class="profile-details" style="display: none;">
            <p>Username: <span id="Student_username"><?php echo htmlspecialchars($student['Student_username'])?></span></p>
            <p>Student ID: <span id="Student_ID"><?php echo htmlspecialchars($student['Student_ID'])?></span></p>
            <p>Total Points: <span id="Student_point"><?php echo htmlspecialchars($student['Student_point'])?></span></p>
            <hr>
            <h4>PERSONAL INFORMATION <button class="edit-button" onclick="editInfo()">✏️</button></h4>
            <p>Email: <span id="Student_email"><?php echo htmlspecialchars($student['Student_email'])?></span></p>
            <p>Contact Number: <span id="Student_contact"><?php echo htmlspecialchars($student['Student_contact'])?></span></p>
        </div>
        </div>
        <div class=edit-form id="editForm" style="display: none;">
        <form id="editFormFields" action="updateProfile.php" method="POST">
            <input type="email" id="editEmail" name="editEmail" value="<?php echo htmlspecialchars($student['Student_email']);?>"><br>
            <input type="text" id="editContact" name="editContact" value="<?php echo htmlspecialchars($student['Student_contact']);?>"><br>
            <button type="submit">Save Changes</button>
            <button type="button" id="cancelButton" onclick="cancelEdit()">Cancel</button>
        </form>
        </div>
    </div>

    <script>
        function toggleProfileDropdown() {
            const profileDropdown = document.getElementById('profileDropdown');
            const searchDropdown = document.getElementById('searchBar');
            profileDropdown.style.display = profileDropdown.style.display === 'block' ? 'none' : 'block';

            if (searchDropdown.style.display === 'block') {
                searchDropdown.style.display = 'none';
            }
        }

        function showProfileSection() {
            const profileSection = document.getElementById('profileSection');
            const profileDetails = document.getElementById('profileDetails');
            const profileDropdown = document.getElementById('profileDropdown');

            if (profileDropdown.style.display === 'block') {
                profileDropdown.style.display = 'none';
            }
            profileSection.style.display = profileSection.style.display === 'none' ? 'block' : 'none';
            if (profileSection.style.display === 'block') {
                profileDetails.style.display = 'block'; // Ensure profile details are shown
            }
        }

        document.getElementById('profileMenu').addEventListener('click', showProfileSection);

        function toggleSearchDropdown() {
            const searchDropdown = document.getElementById('searchBar');
            const profileSection = document.getElementById('profileSection');
            const profileDropdown = document.getElementById('profileDropdown');
            searchDropdown.style.display = searchDropdown.style.display === 'none' ? 'block' : 'none';

            if (profileSection.style.display === 'block') {
                profileSection.style.display = 'none';
            }
            if (profileDropdown.style.display === 'block') {
                profileDropdown.style.display = 'none';
            }
        }

        function closeProfileSection() {
        document.getElementById('profileSection').style.display = 'none';
        }

        function editInfo() {
        document.getElementById('profileSection').style.display = 'none';
        document.getElementById('editForm').style.display = 'block';
        }

        function cancelEdit() {
        document.getElementById('editForm').style.display = 'none';
        document.getElementById('editForm').reset();
        }

        function joinQuiz() {
            const quizCode = document.getElementById('quizCodeInput').value.trim();

            if (quizCode !== '') {
                window.location.href = `quizPreview.php?quiz_code=${encodeURIComponent(quizCode)}`;
            } else {
                alert('Please enter a valid quiz code.');
            }
        }
    </script>

</body>
</html>
