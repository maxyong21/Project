<?php
include("../conn.php");
 
session_start();
 
$id = $_GET['id'];
$action = $_GET['action'];
$student_id = $_SESSION['Student_ID'];
 
if ($action === 'apply') {
    $update_existing_query = "UPDATE inventory SET status = 'not applied' WHERE Student_ID = '$student_id' AND status = 'applied'";
    mysqli_query($con, $update_existing_query);
    $update_query = "UPDATE inventory SET status = 'applied' WHERE Item_ID = '$id' AND Student_ID = '$student_id'";
} else {
    $update_query = "UPDATE inventory SET status='not applied' WHERE Item_ID = '$id'";
}
 
if (mysqli_query($con, $update_query)) {
    $message = ($action === 'apply') ? "Theme successfully applied." : "Theme successfully removed.";
    echo '<script>alert("' . $message . '");
            window.location.href = "themeShop.php";  
          </script>';
} else {
    echo '<script>alert("Error applying theme: ' . mysqli_error($con) . '");
            window.location.href = "themeShop.php";
          </script>';
}
?>