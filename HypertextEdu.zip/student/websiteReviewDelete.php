<?php
include("../conn.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $delete_query = "DELETE FROM review WHERE Review_ID = ?";
    $stmt = mysqli_prepare($con, $delete_query);
    mysqli_stmt_bind_param($stmt, "s", $id);
    $execute_result = mysqli_stmt_execute($stmt);

    if ($execute_result) {
        echo '<script>alert("Review successfully deleted.");
            window.location.href="websiteReview.php";
        </script>';
    } else {
        echo '<script>
            alert("Error deleting review: ' . mysqli_error($con) . '");
            window.location.href="websiteReview.php";
        </script>';
    }
    mysqli_stmt_close($stmt);
}
?>