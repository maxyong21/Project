<?php
include("../conn.php");

include("student.php");
?>

<?php
include("../conn.php");

$Quiz_ID = isset($_GET['id']) ? $_GET['id'] : 0;
$quiz_code = isset($_GET['quiz_code']) ? $_GET['quiz_code'] : '';

if ($quiz_code) {
    $quiz = "SELECT quiz.*, instructor.Instructor_username
    FROM quiz
    JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID
    WHERE quiz_code = '$quiz_code'
    AND quiz.verificationStatus = 'approved'
    AND instructor.verificationStatus = 'approved'";
} elseif ($Quiz_ID) {
    $quiz = "SELECT quiz.*, instructor.Instructor_username
    FROM quiz
    JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID
    WHERE Quiz_ID = '$Quiz_ID'
    AND quiz.verificationStatus = 'approved'
    AND instructor.verificationStatus = 'approved'";
} else {
    echo "No quiz available.";
    exit;
}

$quiz_result = mysqli_query($con, $quiz);
if (mysqli_num_rows($quiz_result) > 0) {
    $row = mysqli_fetch_assoc($quiz_result);
} else {
    echo '<script>alert("Quiz not found.");
        window.location.href="homepage_loggedin.php";
    </script>';
    exit;
}

if (htmlspecialchars($row['Quiz_timer']) != 0) {
    $Quiz_timer = '' . htmlspecialchars($row['Quiz_timer']) . ' minutes';
} else {
    $Quiz_timer = 'not set';
}

$timer_query = "SELECT Quiz_timer FROM quiz WHERE Quiz_ID = '$Quiz_ID'";
$timer_result = mysqli_query($con, $timer_query);
$timer_time = mysqli_fetch_assoc($timer_result);

$student_id = $_SESSION['Student_ID'];
$attempted_query = "SELECT enrollment.Quiz_ID, enrollment.Student_ID, quiz.quiz_code FROM enrollment 
JOIN quiz ON quiz.Quiz_ID = enrollment.Quiz_ID
WHERE (enrollment.Quiz_ID = '$Quiz_ID' OR quiz.quiz_code = '$quiz_code')
AND enrollment.Student_ID = '$student_id'";

$attempted_result = mysqli_query($con, $attempted_query);
if (mysqli_num_rows($attempted_result) > 0) {
    $attempted_data = mysqli_fetch_assoc($attempted_result);
    echo '<script>alert("You have already attempted this quiz.");
    window.location.href="quizResults.php?Quiz_ID=' . htmlspecialchars($attempted_data['Quiz_ID']) . '&Student_ID=' . htmlspecialchars($attempted_data['Student_ID']) . '";    </script>';
}

// Count no. of questions in quiz
$q_count_query = "SELECT COUNT(*) as q_count FROM question WHERE Quiz_ID = '{$row['Quiz_ID']}'";
$q_count_result = mysqli_query($con, $q_count_query);
$q_count_data = mysqli_fetch_assoc($q_count_result);
$q_count = $q_count_data['q_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Preview</title>
    <style>
        /* Main Content */
	    .main-content {
            display: flex;
	        padding: 20px;
            gap: 25px;
            margin-top: 20px;
            width: 80vw;
            margin-left: -10%;
	    }
        h2, h3, p {
            padding-left: 20px;
        }
        em {
            font-size: 12px;
        }

        /* Quiz Preview */
        .quiz-preview-container {
            flex: 2;
            width: 75vw;
            height: 500px;
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            margin-top: 15px;
        }
        .quiz-intro {
            margin-bottom: 15px;
        }
        .quiz-preview {
            width: 60vw;
            height: 50px;
            display: flex;
            background-color: white;
            padding: 10px;
            flex-wrap: nowrap;
            gap: 5px;
        }
        .quiz-preview-image {
            width: 120px;
            height: 120px;
            margin-right: 20px;
            margin-left: 10px;
            background-color: #3b82f6;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            border-radius: 8px;
        }
        .quiz-preview-description {
            flex-grow: 1;
            background-color: white;
            padding: 0;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
            line-height: 1.5;
            height: auto;
            width: 175px;
        }
        .quiz-preview-description p {
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        .quiz-preview-buttons {
            display: flex;
            align-content: center;
            justify-content: space-between;
            margin: 10px;
            margin-top: 300px;
        }
        .quiz-preview-buttons button {
            border: 0;
            border-radius: 8px;
            width: 200px;
            height: 40px;
            color: white;
        }
        .challenge-button {
            background-color: #3b82f6;
            left: 0%;
            
        }
        .challenge-button:hover {
            background-color: #2563eb;
        }
        .attempt-button {
            background-color: #10b981;
            right: 0%;
        }
        .attempt-button:hover {
            background-color: #059669;
        }
        .challenge-dropup {
            position: relative;
            display: inline-block;
        }
        .challenge-dropup-content {
            display: flex;
            justify-content: center;
            align-items: center;
            position: absolute;
            bottom: 50px;
            background-color: white;
            border: 1px solid #3b82f6;
            font-size: 14px;
            border-radius: 8px;
            z-index: 1;
            text-align: center;
            color: black;
        }
        .challenge-dropup-content p {
            padding-right: 10px;
            padding-left: 10px;
        }

        /* Quiz Settings */
        .quiz-settings-container {
            flex: 2;
            width: 18vw;
            height: 500px;
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            margin-top: 15px;
        }
        .settings-intro {
            margin-bottom: 15px;
        }
        .settings-menu {
            width: 16vw;
            height: auto;
            display: flex;
            background-color: white;
            padding: 10px;
            flex-direction: column;
        }
        .settings-option {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            padding: 10px 0;
        }
        .settings-option span {
            font-size: 16px;
            flex-grow: 1;
        }
        .settings-option button {
            margin-left: auto;
            padding: 5px 10px;
        }
        .toggle-button {
            padding: 5px 10px;
            border-radius: 20px;
            background-color: #e2e8f0;
            color: #333;
            cursor: pointer;
            font-size: 0.9em;
            border: none;
            transition: background 0.3s;
            width: 50px;
        }
        .toggle-button.on {
            background-color: #3b82f6;
            color: #fff;
            border: none;
        }

        .main-content {
            display: flex;
            padding: 20px;
            gap: 25px;
            margin-top: 20px;
            width: 80vw;
            margin-left: -10%;
        }

        .quiz-preview-container, 
        .quiz-settings-container {
            flex: 2;
            width: 75vw;
            height: 500px;
            background-color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            margin-top: 15px;
        }

        /* Mobile-Specific Styles for 400x864 */
        @media (max-width: 480px) {
            body {
                display: flex;
                align-items: center;
            }
            .main-content {
                display: flex;
                justify-items: center;
                flex-direction: column;
            }
            .quiz-preview {
                height: auto;
                width: 90%;
                padding: 0px;
            }
            .quiz-preview-container {
                width: 75vw;
                height: auto;
                margin: 0;
                padding: 20px;
            }
            .quiz-preview-buttons {
                margin-top: 65px;
            }
            .quiz-preview-buttons button {
                width: 125px;
            }
            .quiz-preview-image {
                width: 85px;
                height: 75px;
                font-size: 14px;
                margin-top: 25px;
            }
            .quiz-settings-container {
                width: 75vw;
                height: auto;
                margin: 0;
                padding: 20px;
                display: flex;
                flex-direction: row;
                align-items: center;
                justify-items: center;
            }
            .settings-menu {
                width: 75%;
            }
            .settings-menu button {
                height: 40px;
                width: 75px;
                margin-left: 10px;
            }
        }





    </style>
    <script>
        function toggleSetting(button) {
            button.classList.toggle('on');
            button.textContent = button.classList.contains('on') ? 'ON' : 'OFF';
        
            const timerInput = document.getElementById('timerSet');
            timerInput.value = button.classList.contains('on') ? 'ON' : 'OFF';
        }
    </script>
</head>
<body>
<div class="main-content">
    <?php if (mysqli_num_rows($attempted_result) == 0) : ?>
        <div class="quiz-preview-container">
            <h2 class="quiz-intro">Quiz Preview</h2>
            <div class="quiz-preview">
                <div class="quiz-preview-image">📘</div>
                <div class="quiz-preview-description">
                    <?php
                    echo '<h3>' . htmlspecialchars($row['Quiz_title']) . '</h3>';
                    echo '<p>' . htmlspecialchars($row['Quiz_description']) . '</p>';
                    echo '<em style="padding-left: 20px;">Posted by: ' . htmlspecialchars($row['Instructor_username']) . '</em> | <em>Posted on: ' . htmlspecialchars($row['created_date']) . '</em><br>';
                    echo '<em style="padding-left: 20px;">Number of Questions: ' . $q_count . '</em><br>';
                    echo '<em style="padding-left: 20px;">Timer: ' . $Quiz_timer . '</em>';
                    ?>
                </div>
            </div>
            <div class="quiz-preview-buttons">
                <div class="challenge-dropup">
                    <button type="button" class="challenge-button" onclick="toggleChallengeDropup()">Challenge Friends</button>
                    <div class="challenge-dropup-content" id="challengeDropupContent" style="display: none;">
                        <?php echo '<p>Quiz Code: ' . htmlspecialchars($row['quiz_code']) . '</p>';?>
                    </div>
                </div>
                <button type="button" class="attempt-button"><a href="quizQuestions.php?id=<?php echo $row['Quiz_ID']; ?>&timer=" id="attemptLink" style="color: white; text-decoration: none;">Attempt Quiz</a></button>   
            </div>
        </div>

        <?php if (($timer_value = $timer_time ?? 0) === 0 || $Quiz_timer == 'not set') : ?>
            <div class="quiz-settings-container">
            <h2 class="settings-intro">Quiz Settings</h2>
            <div class="settings-menu">
                <div class="settings-option">
                    <span>Timer<span>
                    <button class="toggle-button off">OFF</button>
                </div>
            </div>
            <input type="hidden" id="timerSet" value="OFF">
        </div>
        <?php else : ?>
            <div class="quiz-settings-container">
            <h2 class="settings-intro">Quiz Settings</h2>
            <div class="settings-menu">
                <div class="settings-option">
                    <span>Timer<span>
                    <button class="toggle-button on" onclick="toggleSetting(this)">ON</button>
                </div>
            </div>
            <input type="hidden" id="timerSet" value="ON">
        </div>
        <?php endif; ?>
    </div>
    <?php else : ?>
        
    <?php endif; ?>

    <script>
        function toggleChallengeDropup() {
            const challengeDropupContent = document.getElementById('challengeDropupContent');
            if (challengeDropupContent.style.display === 'block') {
                challengeDropupContent.style.display = 'none';
            } else {
                challengeDropupContent.style.display = 'block';
            }
        }
        document.querySelector('.attempt-button').addEventListener('click', function() {
            const timerInput = document.getElementById('timerSet').value;
            const attemptLink = document.getElementById('attemptLink');
            attemptLink.href += timerInput;
        });

    </script>
</body>
</html>