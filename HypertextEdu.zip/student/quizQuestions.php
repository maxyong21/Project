<?php
include("../conn.php");

include("student.php");
?>

<?php
include("../conn.php");

$Quiz_ID = isset($_GET['id']) ? $_GET['id'] : (isset($_POST['Quiz_ID']) ? $_POST['Quiz_ID'] : 0);
$quiz_query = "SELECT * FROM quiz WHERE Quiz_ID = '$Quiz_ID' AND verificationStatus = 'approved'";
$quiz_result = mysqli_query($con, $quiz_query);

if (mysqli_num_rows($quiz_result) == 0) {
    echo '<script>alert("Quiz not found."); 
        window.location.href="homepage_loggedin.php";
    </script>';
    exit;
}

$timer_status = isset($_GET['timer']) ? $_GET['timer'] : 'OFF';
if ($timer_status == 'ON') {
    $timer_query = "SELECT Quiz_timer FROM quiz WHERE Quiz_ID = '$Quiz_ID'";
    $timer_result = mysqli_query($con, $timer_query);
    $timer_time = mysqli_fetch_assoc($timer_result);
} else {
    $timer_time = '-';
}

// Fetch quiz title and question after validation
$quiz_data = mysqli_fetch_assoc($quiz_result);
$title = $quiz_data['Quiz_title'];

$student_point_query = "SELECT Student_point from student WHERE Student_ID = '$Student_ID'";
$student_point_result = mysqli_query($con, $student_point_query);
$student_point = mysqli_fetch_assoc($student_point_result);

$Student_ID = $_SESSION['Student_ID'];
$Student_ID = strval($Student_ID);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $total_score = 0;
    $total_score = intval($total_score);
    $question_query = "SELECT * FROM question WHERE Quiz_ID = '$Quiz_ID'";
    $question_result = mysqli_query($con, $question_query);

    if (mysqli_num_rows($question_result) > 0) {
        while ($question = mysqli_fetch_assoc($question_result)) {
            $QuestionID = $question['Question_ID'];
            $Student_ans = isset($_POST["question_$QuestionID"]) ? $_POST["question_$QuestionID"] : '';
            $Correct_answer = $question['correct_answer'];
            $score = ($Student_ans === $Correct_answer) ? 10 : 0;
            $attempt_date = 'NOW()';

            // Insert the student's answer into the enrollment table
            $insert_answer = "INSERT INTO enrollment (Student_ID, Quiz_ID, Question_ID, Student_ans, score, attempt_date)
                            VALUES ('$Student_ID', '$Quiz_ID', '$QuestionID', '$Student_ans', '$score', $attempt_date)";

            mysqli_query($con, $insert_answer);
            $total_score += intval($score);
            
        }

        $total_score = intval($total_score);
        $final_score = intval($student_point['Student_point'] + $total_score);

        $update_points_query = "UPDATE student SET Student_point = ? WHERE Student_ID = ?";
        $stmt = mysqli_prepare($con, $update_points_query);
        mysqli_stmt_bind_param($stmt, "is", $final_score, $Student_ID); 
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        echo "<script>;
            window.location.href = 'quizResults.php?Quiz_ID=$Quiz_ID&Student_ID=$Student_ID';
         </script>";
        exit;

    } else {
        echo '<script>alert("Quiz questions not found."); 
            window.location.href="homepage_loggedin.php";
        </script>';
        exit;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title;?></title>
    <style>
        /* Main Content */
        .main-content {
            padding: 20px;
            display: flex;
            flex-direction: column;
            width: 95vw;
        }

        /* Quiz Content */
        .quiz-container {
            flex: 2;
            width: 95vw;
            height: 500px;
            padding: 15px;
            border-radius: 5px;     
        }
        .quiz-title {
            margin-bottom: 40px;
        }
        .quiz-question {
            margin-bottom: 45px;
            width: 80vw;
            height: auto;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            padding: 15px 20px;
            padding-top: 5px;
            border-radius: 8px;
        }
        .quiz-options {
            margin-top: 5px;
            height: auto;
        }
        .quiz-options input {
            margin-bottom: 15px;
        }
        .quiz-actions {
            margin-top: 125px;
            width: 300px;
            display: flex;
            justify-content: space-between;
        }
        .quiz-actions button {
            width: 100px;
            height: 35px;
            color: white;
            border: none;
            border-radius: 8px;
            margin-left: 20px;
        }
        .reset-quiz {
            background-color: #3b82f6;            
        }
        .reset-quiz:hover {
            background-color: #2563eb;
            cursor: pointer;
        }
        .submit-quiz {
            background-color: #10b981;
        }
        .submit-quiz:hover {
            background-color: #059669;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="quiz-container">
            <?php echo '<h2 class="quiz-title">' . htmlspecialchars($title) . '</h2>';?>
            <div id="timer" style="font-size: 18px; font-weight: bold; margin-bottom: 20px; color: black;"></div>
            <form action="quizQuestions.php" id="quizAnswers" method="POST">
                <input type="hidden" name="Student_ID" value="<?php echo $_SESSION['Student_ID']; ?>">
                <input type="hidden" name="Quiz_ID" value="<?php echo $Quiz_ID; ?>">

                <?php
                // Fetch questions again to display on the form
                $question_query = "SELECT * FROM question WHERE Quiz_ID = '$Quiz_ID'";
                $question_result = mysqli_query($con, $question_query);

                while ($question = mysqli_fetch_assoc($question_result)) {
                    echo '<div class="quiz-question">';
                    echo '<p>' . htmlspecialchars($question['Question_text']) . '</p>';
                    echo '<div class="quiz-options">';
                    echo '<input type="radio" id="q' . $question['Question_ID'] . 'A" name="question_' . $question['Question_ID'] . '" value="A"><label for="A"> A. ' . htmlspecialchars($question['Question_choice_a']) . '</label><br>';
                    echo '<input type="radio" id="q' . $question['Question_ID'] . 'B" name="question_' . $question['Question_ID'] . '" value="B"><label for="B"> B. ' . htmlspecialchars($question['Question_choice_b']) . '</label><br>';
                    echo '<input type="radio" id="q' . $question['Question_ID'] . 'C" name="question_' . $question['Question_ID'] . '" value="C"><label for="C"> C. ' . htmlspecialchars($question['Question_choice_c']) . '</label><br>';
                    echo '<input type="radio" id="q' . $question['Question_ID'] . 'D" name="question_' . $question['Question_ID'] . '" value="D"><label for="D"> D. ' . htmlspecialchars($question['Question_choice_d']) . '</label><br>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>

                <div class="quiz-actions">
                    <button type="submit" class="submit-quiz" id="submitQuiz">Submit</button>
                    <button type="button" class="reset-quiz" id="resetQuiz" onclick="toggleResetQuiz()">Reset</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleResetQuiz() {
            document.getElementById('quizAnswers').reset();
        }

        <?php if ($timer_status == 'ON' && $timer_time != '-') : ?>
        const timerDuration = <?php echo intval($timer_time['Quiz_timer']); ?> * 60; // time in seconds
        
        // Function to start the countdown timer
        function startTimer(duration, display) {
            let timer = duration, minutes, seconds;
            const interval = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = `Time Remaining: ${minutes}:${seconds}`;

                if (--timer < 0) {
                    clearInterval(interval);
                    alert("Time is up - Submitting your quiz.");
                    document.getElementById('quizAnswers').submit(); // Auto-submit the form
                }
            }, 1000);
        }
        // Start the timer when the page loads
        window.onload = function () {
            const timerElement = document.getElementById('timer');
        startTimer(timerDuration, timerElement);
        };
        <?php else : ?>
            document.getElementById('timer').style.display = 'none';
        <?php endif;?>
    </script>
</body>
</html>