<?php 
include("../conn.php");
include("student.php");

if (isset($_GET['id'])) {
    $item_id = $_GET['id'];
    $item_sql = "SELECT * FROM item WHERE Item_ID = '$item_id'";
    $item_result = mysqli_query($con, $item_sql);

    if (mysqli_num_rows($item_result) > 0) {
        $item_row = mysqli_fetch_assoc($item_result);
        $item_price = $item_row['Item_price'];
    } else {
        echo "Item not found.";
        exit();
    }

    $points_sql = "SELECT Student_point FROM student WHERE Student_ID = '{$_SESSION['Student_ID']}'";
    $points_result = mysqli_query($con, $points_sql);
    $points_row = mysqli_fetch_assoc($points_result);
    $current_points = $points_row['Student_point'];

    if ($current_points >= $item_price) {
        $new_points = $current_points - $item_price;
        $update_points_sql = "UPDATE student SET Student_point = '$new_points' WHERE Student_ID = '{$_SESSION['Student_ID']}'";
        mysqli_query($con, $update_points_sql);
        $purchase_sql = "INSERT INTO inventory (Student_ID, Item_ID) VALUES ('{$_SESSION['Student_ID']}', '$item_id')";
        mysqli_query($con, $purchase_sql);
        echo '<script>alert("Theme successfully purchased.");
            window.location.href="themeShop.php";
        </script>';
        exit;
    } else {
        echo'<script>alert("Insufficient points.");
            window.location.href="themeShop.php";
        </script>';
    }
}
?>