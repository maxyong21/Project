<?php
include("../conn.php");

session_start();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Check if the POST variables are set
    if (isset($_POST['Review_Title']) && isset($_POST['Review_message'])) {
        $Review_Title = $_POST['Review_Title'];
        $Review_message = $_POST['Review_message'];
    
        // Set the star rating and student ID from the session
        $star_rating = $_POST['star_rating'];
        $star_rating = intval($star_rating);
        
        $Student_ID = $_SESSION['Student_ID'];

        // Check if any required fields are empty
        if (empty($Review_Title)) {
            echo '<script>alert("Ensure the title field is not empty.");
                window.location.href="websiteReview.php";
            </script>';
            exit;
        } elseif (empty($Review_message)) {
            echo '<script>alert("Ensure the message field is not empty.");
                window.location.href="websiteReview.php";
            </script>';
            exit;
        } elseif ($star_rating == 0) {
            echo '<script>alert("Ensure the rating field is not empty.");
                window.location.href="websiteReview.php";
            </script>';
            exit;
        } else {}

        $result = mysqli_query($con, "SELECT MAX(Review_ID) AS max_id FROM review");
        $row = mysqli_fetch_assoc($result);
        $max_id = $row['max_id'];
        if ($max_id) {
            $num_part = intval(substr($max_id, 2));
            $next_id = "RV" . str_pad($num_part + 1, 3, '0', STR_PAD_LEFT);
        } else {
            $next_id = 'RV001';
        }

        $query = "INSERT INTO review (Review_ID, Review_Title, Review_message, star_rating, Student_ID, Review_date)
        VALUES (?, ?, ?,  ?, ?, NOW())";

        if ($stmt = mysqli_prepare($con, $query)) {
            mysqli_stmt_bind_param($stmt, "sssis", $next_id, $Review_Title, $Review_message, $star_rating, $Student_ID);

            if (mysqli_stmt_execute($stmt)) {
                echo '<script>alert("Review successfully submitted."); 
                    window.location.href="websiteReview.php";
                </script>';
            } else {
                echo '<script>alert("Error: Please try again."); 
                    window.location.href="websiteReview.php";
                </script>';
            }
        } else {
            echo '<script>alert("Error preparing query.");
                window.location.href="websiteReview.php";
            </script>';
        }
    }
}
?>