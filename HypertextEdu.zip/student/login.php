<?php
// Start the session
session_start();

// Include the database connection file
include("../conn.php");

// Initialize variables for error messages
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username and password from POST request
    $Student_username = trim(mysqli_real_escape_string($con, $_POST['Student_username']));
    $Student_password = trim(mysqli_real_escape_string($con, $_POST['Student_password']));

    // Query to check the existence of the user
    $sql = "SELECT * FROM student WHERE Student_username = '$Student_username'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) == 1) {
        // Fetch the user's data
        $row = mysqli_fetch_assoc($result);
        $hashed_password = $row['Student_password'];  

        // Verify the provided password against the database password (password_verify doesn't work as $Student_password not hashed)
        if (password_verify($Student_password, $hashed_password)) {
            // Set session variables for the logged-in user
            $_SESSION['Student_ID'] = $row['Student_ID'];
            $_SESSION['Student_username'] = $row['Student_username'];

            // Redirect to the admin homepage or dashboard
            header("Location: homepage_loggedin.php");
            exit();
        } else {
            $error = "Invalid password. Please try again.";
        }
    } else {
        $error = "Invalid username. Please try again.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        .logo {
            width: 300px;
            margin-bottom: 20px;
            margin-left: 8px;
        }
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url(../background3.jpg) no-repeat;
            background-size: cover;
            background-position: center;
        }
        .wrapper{
            width: 420px;
            background: transparent;
            color: white;
            border-radius: 15px;
            padding: 30px 40px;
            border: 2px solid white;
            backdrop-filter: blur(20px);
            display: flex;
            align-content: center;
            justify-content: center;
            height: 64vh;
        }
        .wrapper h1{
            font-size: 40px;
            text-align: center;
        }
        .input-box{
            width: 100%;
            height: 200px;
            margin: 40px 0;
            position: relative;
        }
        .input-box input{
            width: 100%;
            height: 35px;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 50px;
            background: transparent;
            font-size: 20px;
            color: white;
            padding: 20px 45px 20px 15px;
            margin-bottom: 10px;
        }
        .input-box input::placeholder{
            color: white;
        }
        .input-box i{
            position: absolute;
            right: 10px;
            top: 30%;
            transform: translate(-50%);
            font-size: 20px;
        }
        .btn{
            width: 100%;
            height: 45px;
            background: #fff;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            cursor: pointer;
            font-size: 20px;
            color: black;
            font-weight: 600;
        }
        .guest-btn {
            width: 100%;
            height: 45px;
            background: white;
            border: none;
            border-radius: 45px;
            outline: none;
            cursor: pointer;
            font-size: 20px;
            color: black;
            font-weight: 600;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
        }
        .register-link{
            font-size: 15px;
            text-align: center;
            margin: 20px 0 15px;

        }
        .register-link p, .register-link a{
            color: #fff;
            text-decoration: none;
        }
        .register-link a:hover{
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .wrapper{
            width: 85vw;
            background: transparent;
            color: white;
            border-radius: 15px;
            padding: 30px 40px;
            border: 2px solid white;
            backdrop-filter: blur(20px);
            display: flex;
            align-content: center;
            justify-content: center;
            height: 70vh;
        }
        .wrapper h1{
            font-size: 32px;
            text-align: center;
        }
        .input-box{
            width: 80%;
            height: 200px;
            margin: 40px 0;
            position: absolute;
            align-items: center;
            display: flex;
            flex-direction: column;

        }
        .input-box input{
            width: 100%;
            height: 35px;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 50px;
            background: transparent;
            font-size: 20px;
            color: white;
            padding: 20px 45px 20px 15px;
            margin-bottom: 10px;
        }
        .logo {
            width: 65vw;
            height: auto;
        }
        .btn {
            width: 65%;
            font-size: 14px;
            padding-top: 15px;
            padding-bottom: 15px;
            margin-bottom: -15px;
        }
        .input-box a {
        }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <form action="login.php" method="POST">
            <img src="../logo.jpg" alt="Logo" class="logo">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" placeholder="Username" id="Student_username" name="Student_username" required>
                <input type="password" placeholder="Password" id="Student_password" name="Student_password" required><br><br><br>

                <button type="Submit" class="btn">Login</button><br><br>
                <button type="button" class="btn" onclick="window.location.href='../opening.php'">Back</button><br><br>
                <div class="register-link">
                    <p>Don't have an account?</p>
                    <a href="registration.php">Register</a>
                </div>    
            </div>
        </form>
    </div>
</body>
</html>