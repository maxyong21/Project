<!-- -->
<?php
include("../conn.php");

include("student.php");
?>


<?php
include("../conn.php");
$student_id = $_SESSION['Student_ID'];

$quiz = "SELECT quiz.*, instructor.Instructor_username, instructor.verificationStatus
FROM quiz
JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID
LEFT JOIN enrollment ON quiz.Quiz_ID = enrollment.Quiz_ID
AND enrollment.Student_ID = '$student_id'
WHERE quiz.verificationStatus = 'approved' 
AND enrollment.Student_ID IS NULL
AND instructor.verificationStatus = 'approved'";
$quiz_result = mysqli_query($con, $quiz);

$finished_quiz = "SELECT DISTINCT quiz.*, instructor.Instructor_username
FROM quiz
JOIN instructor ON quiz.Instructor_ID = instructor.Instructor_ID
LEFT JOIN enrollment ON quiz.Quiz_ID = enrollment.Quiz_ID
WHERE quiz.verificationStatus = 'approved' 
AND enrollment.Student_ID = '$student_id'
AND enrollment.Quiz_ID IS NOT NULL
AND instructor.verificationStatus = 'approved'";
$finished_result = mysqli_query($con, $finished_quiz);

$announce = "SELECT announcement.*, administrator.Admin_username 
FROM announcement
JOIN administrator ON announcement.Administrator_ID = administrator.Administrator_ID
ORDER BY Announce_date DESC";
$announce_result = mysqli_query($con, $announce);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hypertext EDU</title>
    <style>
        /* Main Content */
	    .main-content {
	        padding: 20px;
            display: flex;
            flex-direction: column;
	    }
        .container {
            width: 100%;
            padding-right: 25px;
            padding-left: 25px;
            height: auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .code-input-container {
            width: 75vw;
            height: 75px;
            background-color: #ffffff;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        }
        .code-input-container input {
            height: 35px;
            width: 70vw;
            padding: 5px 10px;
            margin-left: 15px;
            border: 1px solid #e2e8f0;
            border-radius: 5px;
        }
        .code-input-container input:focus {
            border-color: #3b82f6;
            outline: none;
        }
        .code-input-container button {
            height: 30px;
            width: 5vw;
            padding: 5px;
            margin-left: 15px;
            margin-right: 15px;
            border: 0;
            color: white;
            background-color: #3b82f6;
            border-radius: 8px;
        }
        .code-input-container button:hover {
            background-color: #2f6bcc;
            cursor: pointer;
        }
        .quiz-container .code-input-container:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }
        .quiz-container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            width: 75vw;
            height: auto;
            z-index: 1;
            border-radius: 5px;
            flex-wrap: wrap;
        }
        .quiz-image {
            width: 60px;
            height: 60px;
            margin-right: 25px;
            margin-left: 10px;
            background-color: #3b82f6;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            border-radius: 8px;
        }
        .quiz-details {
            flex: 1;
            z-index: 2;
            padding: 20px;
        }
        .quiz-actions {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            margin-top: 10px;
            margin-right: 10px;
            gap: 5px;
            z-index: 2;
        }
        .quiz-actions button {
            background-color: #10b981;
            color: white;
            padding: 10px 15px;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
            width: 80px;
        }
        .quiz-actions button:hover {
            background-color: #059669;
        }
        em {
            font-size: 14px;
        }
        .announcement-item {
            background-color: white;
            padding-left: 25px;
            padding-right: 25px;
            padding-bottom: 20px;
            padding-top: 15px;
            border: 0;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-bottom: 20px;
            height: auto;
            width: 75vw;
            line-height: 25px;
        }
        h2 {
            padding-left: 35px;
        }

        @media (max-width: 480px) {
            body {
                display: flex;
                align-items: center;
            }
            .main-content {
                display: flex;
                align-items: center;
            }
            h2 {
                padding: 0;
            }
        }
        </style>

</head>
<body>
	<!-- Main Content -->
	<div class="main-content">
	    <!-- Join with Code Section -->
		<h2>Join with Quiz Code</h2>
        <div class="container">
	    <div class="join-with-code">
		    <div class="code-input-container">
		        <input type="text" id="quizCode" name="quizCode" placeholder="Enter Quiz Code">
		        <button type="button" onclick="joinWithCode()">Join</button>
		    </div>
        </div>
	    </div>

        <br><br><br><h2>Announcements</h2>
        <div class="container">
        <?php
            if (mysqli_num_rows($announce_result) > 0) {
                while ($row = mysqli_fetch_assoc($announce_result)) {
                    echo '<div class="announcement-item">';
                    echo '<h4>' . htmlspecialchars($row['Announce_subject']) . '</h4>';
                    echo '<p>' . nl2br(htmlspecialchars($row['Announce_message'])) . '</p><br>';
                    echo '<em>Posted by: ' . htmlspecialchars($row['Admin_username']) . ' </em> | <em>Posted on: ' . htmlspecialchars($row['Announce_date']) . '</em></p>';
                    echo '</div>';
                }
            } else {
                echo '<p>No existing announcements.</p>';
            }
        ?>
        </div>

	    <!-- Quizzes -->
        <br><br><br><h2>Attempted Quizzes</h2>
        <div class="container">
        <?php
	    if (mysqli_num_rows($finished_result) > 0) {
		while ($row = mysqli_fetch_assoc($finished_result)) {
		    echo '<div class="quiz-container">';

		    echo '<div class="quiz-image">📘</div>';

		    echo '<div class="quiz-details">';
		    echo '<p><strong>' . htmlspecialchars($row['Quiz_title']) .'</strong></p>';
		    echo '<p>' . htmlspecialchars($row['Quiz_description']) . '</p>';
		    echo '<p><em>Posted by: ' . htmlspecialchars($row['Instructor_username']) . '</em> | <em>Posted on: ' . htmlspecialchars($row['created_date']) . '</em></p>';
		    echo '</div>';

		    echo '<div class="quiz-actions">';
            echo '<a href="quizResults.php?Quiz_ID=' . htmlspecialchars($row['Quiz_ID']) . '&Student_ID=' . htmlspecialchars($_SESSION['Student_ID']) . '"><button class="attempt">Review</button></a>';
		    echo '</div>';
            echo '</div>';
		}
	    } else {
		echo '<p>No previously attempted quizzes found.</p>';
	    }
	    ?>
        </div>

        <br><br><br><h2>Available Quizzes</h2>
        <div class="container">
        <?php
	    if (mysqli_num_rows($quiz_result) > 0) {
		while ($row = mysqli_fetch_assoc($quiz_result)) {
		    echo '<div class="quiz-container">';

		    echo '<div class="quiz-image">📘</div>';

		    echo '<div class="quiz-details">';
		    echo '<p><strong>' . htmlspecialchars($row['Quiz_title']) .'</strong></p>';
		    echo '<p>' . htmlspecialchars($row['Quiz_description']) . '</p>';
		    echo '<p><em>Posted by: ' . htmlspecialchars($row['Instructor_username']) . '</em> | <em>Posted on: ' . htmlspecialchars($row['created_date']) . '</em></p>';
		    echo '</div>';

		    echo '<div class="quiz-actions">';
		    echo '<a href="quizPreview.php?action=attempt&id=' . $row['Quiz_ID'] . '"><button class="attempt">Attempt</button></a>';
		    echo '</div>';
            echo '</div>';
		}
	    } else {
		echo '<p>No available quizzes found.</p>';
	    }
	    ?>
        </div>
	</div>

    <script>
        function joinWithCode() {
            const quizCode = document.getElementById('quizCode').value.trim();

            if (quizCode !== '') {
                window.location.href = `quizPreview.php?quiz_code=${encodeURIComponent(quizCode)}`;
            } else {
                alert('Please enter a valid quiz code.');
            }
        }
    </script>
</body>
</html>