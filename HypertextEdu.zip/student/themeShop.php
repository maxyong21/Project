<?php
include("../conn.php");
include("student.php");

$themes_sql = "SELECT item.*, administrator.Admin_username
FROM item
JOIN administrator ON item.Administrator_ID = administrator.Administrator_ID
WHERE item.Item_ID NOT IN (
SELECT inventory.Item_ID
FROM inventory
WHERE inventory.Student_ID = '{$_SESSION['Student_ID']}')";
$themes = mysqli_query($con, $themes_sql);

$purchased_sql = "SELECT inventory.*, item.*, administrator.Admin_username
FROM inventory
JOIN item on inventory.Item_ID = item.Item_ID
JOIN administrator on item.Administrator_ID = administrator.Administrator_ID
WHERE inventory.Student_ID = '{$_SESSION['Student_ID']}'";
$purchased_themes = mysqli_query($con, $purchased_sql);

$points_sql = "SELECT Student_point FROM student 
WHERE Student_ID = '{$_SESSION['Student_ID']}'";
$points_result = mysqli_query($con, $points_sql);
$points_row = mysqli_fetch_assoc($points_result);
$points = $points_row['Student_point'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theme Shop</title>
    <style>
        /* Main Content */
	    .main-content {
	        padding: 20px;
            display: flex;
            flex-direction: column;
	    }
        .points-container {
            width: 85vw;
            height: auto;
            flex: 1;
            display: flex;
            justify-content: space-between;
        }
        .points-container h3 {
            position: fixed;
            right: 25px;
            background-color: white;
            color: #1f2937;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.35);
            height: 35px;
            width: 175px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 0;
            border-radius: 5px;
        }
        /* Themes */
            .container {
            display: flex;
            width: 95vw;
            height: auto;
            flex-wrap: wrap;
            justify-content: left;
        }
        .theme-container {
            display: flex;
            align-content: center;
            justify-content: center;
            width: 500px;
            height: 490px;
            border: none;
            border-radius: 8px;
            background-color: white;
            margin: 15px;
            margin-right: 80px;
            padding: 15px 25px;
            flex-direction: column;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        }
        .theme-img {
            display: flex;
            flex: 1;
            justify-content: center;
            align-content: center;
        }
        .theme-img img {
            width: 432px;
            height: 307.2px;
            object-fit: cover;
            margin-top: 10px;
            margin-bottom: 10px;
        }
        .theme-desc {
            flex: 1;
            width: 80%;
            height: auto;
            margin-bottom: 10px;
        }
        .theme-button-container {
            height: auto;
            flex: 1;
            display: flex;
            flex-direction: row;
            width: 20%;
            margin-left: auto;
            margin-bottom: 10px;
        }
        .theme-button-container a {
            color: white;
            text-decoration: none;
        }
        .theme-button-container .theme-button {
            height: 35px;
            width: 50px;
            margin-bottom: 10px;
            margin-right: 15px;
            border: none;
            border-radius: 5px;
            color: white;
            background-color: #3b82f6;
            flex: 1;
        }
        .theme-button-container .theme-button:hover {
            background-color: #2f6bcc;
            cursor: pointer;
        }
        em {
            font-size: 12px;
        }

        @media (max-width: 768px) {
            .points-container h3 {
            position: fixed;
            right: 35px;
            background-color: white;
            color: #1f2937;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.35);
            height: 35px;
            width: 150px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 0;
            border-radius: 5px;
            font-size: 14px;
        }
    }
        @media (max-width: 480px) {
        .theme-container {
            display: flex;
            align-content: center;
            justify-content: center;
            width: 250;
            height: 315px;
            border: none;
            border-radius: 8px;
            background-color: white;
            margin: 15px;
            margin-right: 80px;
            padding: 15px 25px;
            flex-direction: column;
            }
            .theme-img img {
            width: 199.584px;
            height: 141.9264px;
            object-fit: cover;
            margin-top: 10px;
            margin-bottom: 10px;
            }
            .theme-desc {
                font-size: 14px;
            }
            .theme-button-container {
                width: 35%;
                margin-right: -20px;
            }
            .theme-button-container .theme-button {
                font-size: 10px;
                height: 30px;
                width: 100%;
                padding: 5px 5px;
            }
            .points-container {
            width: 85vw;
            height: auto;
            flex: 1;
            display: flex;
            justify-content: space-between;
            }
            .points-container h3 {
            position: fixed;
            right: 25px;
            background-color: white;
            color: #1f2937;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.35);
            height: 35px;
            width: 85px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 0;
            border-radius: 5px;
            font-size: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="points-container">
            <h2>Purchased Themes</h2>
            <h3>Total Points: <?php echo htmlspecialchars($points);?></h3>
        </div>
        <div class="container">
            <?php
            if (mysqli_num_rows($purchased_themes) > 0) {
                while ($row = mysqli_fetch_assoc($purchased_themes)) {
                    echo '<div class="theme-container">';
                    echo '<br><div class="theme-img"><img src="' . htmlspecialchars($row['Item_url']) . '" alt="' . htmlspecialchars($row['Item_name']) . '"></div>';
                    echo '<div class="theme-desc">';
                    echo '<p>Theme Name: ' . htmlspecialchars($row['Item_name']) . '</p>';
                    echo '<p><em>Uploaded by: ' . htmlspecialchars($row['Admin_username']) . '</em> | <em>Uploaded on: ' . htmlspecialchars($row['Item_date']) . '</em></p>';
                    echo '</div>';
                    echo '<div class="theme-button-container">';
                    if ($row['status'] == "not applied") {
                        echo '<button type="submit" class="theme-button"><a href="themeApply.php?action=apply&id=' . $row['Item_ID'] . '">Apply</a></button>';
                    } else {
                        echo '<button type="submit" class="theme-button"><a href="themeApply.php?action=remove&id=' . $row['Item_ID'] . '">Remove</a></button>';
                    }
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p style="margin-left: 25px;">You have not purchased any themes.</p>';
            }
            ?>
        </div>

        <br><br><br><h2>Unpurchased Themes</h2>
        <div class="container">
            <?php
            if (mysqli_num_rows($themes) > 0) {
                while ($row = mysqli_fetch_assoc($themes)) {
                    echo '<div class="theme-container">';
                    echo '<div class="theme-img"><img src="' . htmlspecialchars($row['Item_url']) . '" alt="' . htmlspecialchars($row['Item_name']) . '"></div>';
                    echo '<div class="theme-desc">';
                    echo '<p>Theme Name: ' . htmlspecialchars($row['Item_name']) . '</p>';
                    echo '<p>Points Required: ' . htmlspecialchars($row['Item_price']) . '</p>';
                    echo '<p><em>Uploaded by: ' . htmlspecialchars($row['Admin_username']) . '</em> | <em>Uploaded on: ' . htmlspecialchars($row['Item_date']) . '</em></p>';
                    echo '</div>';
                    echo '<div class="theme-button-container">';
                    // echo '<button type="button" class="theme-button" onclick="editTheme()">Edit</button>';
                    echo '<button type="submit" class="theme-button"><a href="themePurchase.php?action=purchase&id=' . $row['Item_ID'] . '">Purchase</a></button>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No existing themes.</p>';
            }
            ?>
        </div>
    </div>
</body>
</html>