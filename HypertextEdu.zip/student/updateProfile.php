<?php
// Include database connection
include("../conn.php");

// Start the session to get the student ID
session_start();
$student_id = $_SESSION['Student_ID'];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form input values and sanitize them
    $email = mysqli_real_escape_string($con, $_POST['editEmail']);
    $contact = mysqli_real_escape_string($con, $_POST['editContact']);

    // Check if new email already registered
    $email_check_sql = "SELECT COUNT(*) FROM student WHERE Student_email = ? AND Student_ID != ?";
    $stmt = $con->prepare($email_check_sql);
    $stmt->bind_param("ss", $email, $student_id);
    $stmt->execute();
    $stmt->bind_result($email_exists);
    $stmt->fetch();
    $stmt->close();

    // Check if new contact number already registered
    $contact_check_sql = "SELECT COUNT(*) FROM student WHERE Student_contact = ? AND Student_ID != ?";
    $stmt = $con->prepare($contact_check_sql);
    $stmt->bind_param("ss", $contact, $student_id);
    $stmt->execute();
    $stmt->bind_result($contact_exists);
    $stmt->fetch();
    $stmt->close();

    if ($email_exists > 0) {
        echo '<script>alert("Error: Email already registered.")</script>';
        echo '<script>window.history.back()</script>';
    } elseif ($contact_exists > 0) {
        echo '<script>alert("Error: Contact number already registered.")</script>';
        echo '<script>window.history.back()</script>';
    } else {
        // Update query to modify student details
        $update_sql = "UPDATE student SET Student_email = ?, Student_contact = ? WHERE Student_ID = ?";
        $stmt = $con->prepare($update_sql);
        $stmt->bind_param("sss", $email, $contact, $student_id);

        // Execute the update and provide feedback
        if ($stmt->execute()) {
            echo "Profile updated successfully.";
            // Optionally redirect to the profile or dashboard page
            echo '<script>window.history.back()</script>';
            exit();
        } else {
            echo "Error updating profile: " . $stmt->error;
        }
        // Close the statement
        $stmt->close();
    }
    $con->close();
}
?>
