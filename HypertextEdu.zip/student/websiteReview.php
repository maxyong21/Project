<?php
include("../conn.php");

include("student.php");
?>

<?php
include("../conn.php");
$Student_ID = $_SESSION['Student_ID'];

// Check if the student already has a review
$sql = "SELECT * FROM review WHERE Student_ID = ?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $Student_ID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$existingReview = mysqli_fetch_assoc($result);

$verification_check = "SELECT verificationStatus FROM student 
WHERE Student_ID = ? AND verificationStatus = 'approved'";
$stmt = mysqli_prepare($con, $verification_check);
mysqli_stmt_bind_param($stmt, "s", $Student_ID);
mysqli_stmt_execute($stmt);
$verification_status = mysqli_stmt_get_result($stmt);

$sql = "SELECT review.*, student.Student_username, student.verificationStatus
FROM review
JOIN student ON student.Student_ID = review.Student_ID";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Reviews</title>
    <style>
        /* Main Content */
	    .main-content {
	        padding: 20px;
            display: flex;
            flex-direction: column;
            width: 90vw;
	    }

        /* Review Form */
        .review-form {
            display: flex;
            align-content: center;
            justify-content: center;
            margin-top: 10px;
            padding: 20px;
            padding-top: 5px;
            border: none;
            border-radius: 5px;
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            flex-direction: column;
            width: 90vw;
        }
        .review-form-content {
            display: flex;
            flex-direction: column;
            width: 90vw;
        }
        .review-title {
            height: auto;  
            width: 80vw;       
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
        }
        .review-title label {
            text-align: left;
            width: 100px;
        }
        .review-title input {
            flex: 1;
            width: 500px;
            margin-right: auto;
        }
        .review-message {
            display: flex;
            justify-content: space-between;
            height: auto;
            width: 80vw;
            margin-bottom: 15px;
        }
        .review-message label {
            text-align: left;
            width: 100px;
        }
        .review-message textarea {
            flex: 1;
            width: 60vw;
            margin-right: auto;
        }
        .review-title input, .review-message textarea {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-left: auto;
        }
        .review-message textarea:focus {
            border: #3b82f6;
        }
        .review-rating {
            height: auto;
            width: 95vw;
        }
        .action-button {
            background-color: #3b82f6;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 25px;
            margin-bottom: 10px;
            margin-top: 10px;
        }
        .action-button a {
            color: white;
            text-decoration: none;
        }
        .action-button:hover {
            background-color: #2f6bcc;
            cursor: pointer;
        }
        .review-form-content {
            padding: 10px;
        }
        .rating-button {
            background-color: grey;
            color: black;
            height: 35px;
            width: 35px;
            border: none;
            border-radius: 5px;
            margin-right: 5px;
            margin-bottom: 3px;
        }
        .rating-button:hover {
            background-color: #c0c0c0;
            cursor: pointer;
        }

        /* Website Reviews */
        .reviews-container {
            width: 100%;
            height: auto;
            display: flex;
            flex-direction: column;
        }
        .reviews-content {
            padding: 20px;
            padding-top: 8px;
            margin-bottom: 20px;
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 85vw;
        }
        .reviews-container h3 {
            text-align: left;
        }
        em {
            font-size: 12px;
        }
        .review-title {
            margin-bottom: 15px;
            width: 90vw;
        }
        .review-content {
            margin-bottom: 15px;
            width: 90vw;
        }
        .review-rating {
            margin-bottom: 15px;
            width: 90vw;
        }

        @media (max-width: 768px) {
            .review-form {
                width: 85vw;
                height: auto;
                max-width: 700px;
            }
            .review-form-content {
            display: flex;
            flex-direction: column;
            width: 75%;
        }
        .review-title {
            height: auto;  
            width: 65vw;       
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
        }
        .review-title label {
            text-align: left;
            width: 100px;
        }
        .review-title input {
            flex: 1;
            width: 500px;
            margin-right: auto;
        }
        .review-message {
            display: flex;
            justify-content: space-between;
            height: auto;
            width: 65vw;
            margin-bottom: 15px;
        }
        .review-message label {
            text-align: left;
            width: 100px;
        }
        .review-message textarea {
            flex: 1;
            width: 50vw;
            margin-right: auto;
        }
        .review-title input, .review-message textarea {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-left: auto;
        }
    }
    </style>
</head>
<body>
    <div class="main-content">
        <h2>Website Reviews</h2>

        <?php if ($verification_status && mysqli_num_rows($verification_status) > 0) : ?>
        <!-- Create Review Form / Show Review -->
        <?php if ($existingReview) : ?>
            <!-- If a review exists for the current student, show it -->
            <div class="reviews-container">
                <br><br><br><h3>Your Review</h3>
                <div class="reviews-content">
                    <h3><?php echo htmlspecialchars($existingReview['Review_Title']); ?></h3>
                    <p><?php echo htmlspecialchars($existingReview['Review_message']); ?></p>
                    <p><em>Rating: <?php echo htmlspecialchars($existingReview['star_rating']); ?>/5</em> | <em>Posted on: <?php echo htmlspecialchars($existingReview['Review_date']); ?></em></p>
                    <button type="button" class="action-button"><a href="websiteReviewDelete.php?action=delete&id=<?php echo $existingReview['Review_ID'];?>">Delete Review</a></button>
                </div>
            </div>

        <?php else : ?>
            <div class="review-form">
                <h3>Create Review</h3>
                <form id="reviewForm" action="websiteReviewCreate.php" method="POST">
                    <div class="review-form-content">
                        <div class="review-title">
                            <label for="Review_Title">Title:</label>
                            <input type="text" id="Review_Title" name="Review_Title" required>
                        </div>
                        <div class="review-message">
                            <label for="Review_message">Content:</label>
                            <textarea id="Review_message" name="Review_message" rows=6 required></textarea><br><br>
                        </div>
                        <div class="review-rating">
                            <label for="star_rating">Rating:</label><br><br>
                            <button type="button" class="rating-button" data-rating=1>1</button>
                            <button type="button" class="rating-button" data-rating=2>2</button>
                            <button type="button" class="rating-button" data-rating=3>3</button>
                            <button type="button" class="rating-button" data-rating=4>4</button>
                            <button type="button" class="rating-button" data-rating=5>5</button><br><br>
                        </div>
                        <input type="hidden" id="star_rating" name="star_rating" value="0" required>
                    </div>
                    <button type="submit" class="action-button">Submit Review</button>
                    <button type="button" class="action-button" onclick="resetForm()">Cancel</button>
                </form>
            </div>
        <?php endif;?>
        <?php else : ?>
            <p>You must be verified by an admin to leave a review.</p>
        <?php endif;?>

        <div class="reviews-container">
            <br><br><br><h3>Reviews</h3>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="reviews-content">';
                    echo '<h3>' . htmlspecialchars($row['Student_username']) . '</h3>';
                    echo '<p><strong>' . htmlspecialchars($row['Review_Title']) . '</strong></p>';
                    echo '<p>' . htmlspecialchars($row['Review_message']) . '</p>';
                    echo '<p><em>Rating: ' . htmlspecialchars($row['star_rating']) . '/5</em> | <em>Posted on: ' . htmlspecialchars($row['Review_date']) . '</em></p>';
                    echo '</div>';
                }
            } else {
                echo '<p>No website reviews found.</p>';
            }
            ?>
        </div>
    </div>

    <script>
        function setRating(rating) {
            document.getElementById('star_rating').value = rating;
            const buttons = document.querySelectorAll('.rating-button');
            buttons.forEach(button => {
                button.style.backgroundColor = '';
                button.style.color = '';
            });
            const selectedButton = document.querySelector(`.rating-button[data-rating="${rating}"]`);
            selectedButton.style.backgroundColor = '#3b82f6';
            selectedButton.style.color = 'white';
        }
        document.querySelectorAll('.rating-button').forEach(button => {
            button.addEventListener('click', function() {
                const rating = Number(this.getAttribute('data-rating'));
                setRating(rating);
            });
        });

        document.getElementById('reviewForm').addEventListener('submit', function(event) {
        // Check if a rating has been selected before submitting the form
        if (document.getElementById('star_rating').value == 0) {
            alert('Please select a rating.');
            event.preventDefault();  // Prevent form submission
            }
        });

        function resetForm() {
            document.getElementById('reviewForm').reset();
            const buttons = document.querySelectorAll('.rating-button');
            buttons.forEach(button => {
                button.style.backgroundColor = '';  
                button.style.color = '';            
            });
            // Reset the hidden input to 0
            document.getElementById('star_rating').value = 0;
        }
    </script>
</body>
</html>