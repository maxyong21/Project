<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Homepage</title>
    <link rel="stylesheet" href="Assignment.css">
    <style>
        h1{
            margin-top: 40px;
        }

        .quiz-container{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            width: 80%;
            max-width: 1000px;
            line-height: 25px;
        }

        .quiz-item{
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .quiz-item:hover{
            background-color: #f0f0f0;
        }

        .quiz-item h2{
            font-size: 20px;
            margin: 0;
            color: #dd1c1c;
        }

        .quiz-item p{
            margin: 5px 0;
        }

        .quiz-content{
            flex-grow: 1;
        }

        .ViewQuiz{
            color:black;
            text-decoration: none;
            font-weight: bold;
        }

        .viewQuiz:hover{
            color:#dd1c1c;
        }

        .quiz-link{
            color:inherit;
            text-decoration: none;
            display: block;
            width:100%;
        }

        .edit-button{
            background-color: #dd1c1c;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            margin-left: 10px;
            transition: background-color 0.3s ease;
        }

        .edit-button:hover{
            background-color: #810808;
        }
        p {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <?php include 'NavigationBar.php'; 
    include("ins.php");
    $Instructor_ID = $_SESSION['Instructor_ID'];
    include("../conn.php");

    $sql = "SELECT Quiz_ID, Quiz_title, Quiz_description, created_date from quiz where Instructor_ID = ? order by created_date desc";
    $stmt = $con->prepare($sql);
    $stmt-> bind_param("s", $Instructor_ID);
    $stmt->execute();
    $result = $stmt->get_result();

    

    ?>
    <?php
        if (isset($_GET['query'])){
            $searchQuery = strtolower(trim($_GET['query']));

           $searchSQL = "SELECT Quiz_ID, Quiz_title, Quiz_description, created_date from quiz where Instructor_ID = ? and (lower(Quiz_title) like ? or lower(Quiz_description) like ?)";
           $stmtSearch = $con->prepare($searchSQL);
           $searchTerm = "%$searchQuery%";
           $stmtSearch->bind_param("sss", $Instructor_ID, $searchTerm, $searchTerm);
           $stmtSearch->execute();
           $searchResult = $stmtSearch->get_result();

           if ($searchResult->num_rows > 0){
            echo "<div class='quiz-container'>";
            while ($row = $searchResult->fetch_assoc()){
                echo "<a class='quiz-link' href='ShowQuiz.php?Quiz_ID=".htmlspecialchars($row['Quiz_ID'])."'>";
                echo "<div class='quiz-item'>";
                echo "<h2>".htmlspecialchars($row['Quiz_title'])."</h2>";
                echo "<p><strong>Description:</strong>".htmlspecialchars($row['Quiz_description'])."</p>";
                echo "<p><strong>Created Date:</strong>".htmlspecialchars($row['created_date'])."</p>";
                echo "</div>";
                echo "</a>";
            }
            echo "</div>";
           }
           else{
            echo "<p style='text-align: center'>No quizzes found.</p>";
           }
           $stmtSearch->close();
        }
    ?>
    <h1 style="text-align: center; margin-top: 40px;">Quizzes</h1><br><br>

    <div class="quiz-container">
        <?php
        if ($result->num_rows > 0){
            while ($row = $result->fetch_assoc()){
                
                echo "<div class='quiz-item' onclick=\"window.location.href='ShowQuiz.php?Quiz_ID=".htmlspecialchars($row['Quiz_ID'])."'\">";
                echo "<div class='quiz-content'>";
                echo "<h2>".htmlspecialchars($row['Quiz_title'])."</h2>";
                echo "<p><strong>Description:</strong>".htmlspecialchars($row['Quiz_description'])."</p>";
                echo "<p><strong>Created Date:</strong>".htmlspecialchars($row['created_date'])."</p>";
                echo "</div>";
                echo "<button class='edit-button' onclick=\"event.stopPropagation(); location.href='EditQuiz.php?Quiz_ID=".htmlspecialchars($row['Quiz_ID'])."'\">Edit</button>";
                echo "</div>";
            }
        }
         else{
            echo "<p style='text-align: center;'>No quizzes found. Please create a new quiz!</p>";
        }
        $stmt->close();
        $con->close();
        ?>
    </div>

    <div class="bottom-right">
        <div class="create-quiz" onclick="window.location.href='CreateQuiz.php'">
            <img src="createQuizIcon.jpg" alt="create quiz icon">
        </div>
    </div>

    
</body>
</html>