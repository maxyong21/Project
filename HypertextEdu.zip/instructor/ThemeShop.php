<?php
include 'NavigationBar.php'; 
include("../conn.php");
include("ins.php");

$themes_sql = "SELECT item.*, administrator.Admin_username, instructor.Applied_item
FROM item
JOIN administrator ON item.Administrator_ID = administrator.Administrator_ID
LEFT JOIN instructor ON item.Item_ID = instructor.Applied_item AND instructor.Instructor_ID = '{$_SESSION['Instructor_ID']}'";
$themes = mysqli_query($con, $themes_sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Theme Shop</title>
    <style>
        /* Main Content */
	    .main-content {
	        padding: 20px;
            display: flex;
            flex-direction: column;
	    }
        .points-container {
            width: 85vw;
            height: auto;
            flex: 1;
            display: flex;
            justify-content: space-between;
        }
        .points-container h3 {
            position: fixed;
            right: 25px;
            background-color: white;
            color: #1f2937;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.35);
            height: 35px;
            width: 175px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 0;
            border-radius: 5px;
        }
        /* Themes */
            .container {
            display: flex;
            width: 95vw;
            height: auto;
            flex-wrap: wrap;
            justify-content: left;
        }
        .theme-container {
            display: flex;
            align-content: center;
            justify-content: center;
            width: 500px;
            height: 490px;
            border: none;
            border-radius: 8px;
            background-color: white;
            margin: 15px;
            margin-right: 80px;
            padding: 15px 25px;
            flex-direction: column;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        }
        .theme-img {
            display: flex;
            flex: 1;
            justify-content: center;
            align-content: center;
        }
        .theme-img img {
            width: 432px;
            height: 307.2px;
            object-fit: cover;
            margin-top: 10px;
            margin-bottom: 10px;
        }
        .theme-desc {
            flex: 1;
            width: 80%;
            height: auto;
            margin-top: 10px;
            margin-bottom: 10px;
            line-height: 25px;
        }
        .theme-button-container {
            height: auto;
            flex: 1;
            display: flex;
            flex-direction: row;
            width: 20%;
            margin-left: auto;
            margin-bottom: 10px;
        }
        .theme-button-container a {
            color: white;
            text-decoration: none;
        }
        .theme-button-container .theme-button {
            height: 35px;
            width: 50px;
            margin-bottom: 10px;
            margin-right: 15px;
            border: none;
            border-radius: 5px;
            color: white;
            background-color: #3b82f6;
            flex: 1;
        }
        .theme-button-container .theme-button:hover {
            background-color: #2f6bcc;
            cursor: pointer;
        }
        em {
            font-size: 12px;
        }
        .container p {
            background-color: white;
        }

        @media (max-width: 480px) {
        .theme-container {
            display: flex;
            align-content: center;
            justify-content: center;
            width: 250;
            height: 315px;
            border: none;
            border-radius: 8px;
            background-color: white;
            margin: 15px;
            margin-right: 80px;
            padding: 15px 25px;
            flex-direction: column;
            }
            .theme-img img {
            width: 199.584px;
            height: 141.9264px;
            object-fit: cover;
            margin-top: 10px;
            margin-bottom: 10px;
            }
            .theme-desc {
                font-size: 14px;
            }
            .theme-button-container {
                width: 35%;
                margin-right: -20px;
            }
            .theme-button-container .theme-button {
                font-size: 10px;
                height: 30px;
                width: 100%;
                padding: 5px 5px;
            }
        }
    </style>
    <link rel="stylesheet" href="Assignment.css">
</head>
<body>
    <div class="main-content">
        <div class="points-container">
            <h2>Themes</h2>
        </div>
        <div class="container">
            <?php
            if (mysqli_num_rows($themes) > 0) {
                while ($row = mysqli_fetch_assoc($themes)) {
                    echo '<div class="theme-container">';
                    echo '<br><div class="theme-img"><img src="' . htmlspecialchars($row['Item_url']) . '" alt="' . htmlspecialchars($row['Item_name']) . '"></div>';
                    echo '<div class="theme-desc">';
                    echo '<p>Theme Name: ' . htmlspecialchars($row['Item_name']) . '</p>';
                    echo '<p><em>Uploaded by: ' . htmlspecialchars($row['Admin_username']) . '</em> | <em>Uploaded on: ' . htmlspecialchars($row['Item_date']) . '</em></p>';
                    echo '</div>';
                    echo '<div class="theme-button-container">';
                    if ($row['Item_ID'] == $row['Applied_item']) {
                        echo '<button type="submit" class="theme-button"><a href="themeApply.php?action=remove&id=' . $row['Item_ID'] . '">Remove</a></button>';
                    } else {
                        echo '<button type="submit" class="theme-button"><a href="themeApply.php?action=apply&id=' . $row['Item_ID'] . '">Apply</a></button>';
                    }
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p style="margin-left: 25px;">You have not purchased any themes.</p>';
            }
            ?>
        </div>
    </div>
</body>
</html>
?>