<?php include 'NavigationBar.php'; ?>

<?php
include("../conn.php");

if (session_status() == PHP_SESSION_NONE){
    session_start();
}

include("ins.php");

    if(!isset($_SESSION['Instructor_ID'])){
        header("location:login.php");
        exit();
    }

    $InstructorID = $_SESSION['Instructor_ID'];

    $InstructorName = '';
    $InstructorEmail = '';
    $InstructorContact = '';

    $query = "SELECT Instructor_username, Instructor_email, Instructor_contact from Instructor where Instructor_ID = ?";
    $stmt = $con->prepare($query);
    $stmt ->bind_param("s", $InstructorID);
    $stmt ->execute();
    $stmt ->bind_result($InstructorName, $InstructorEmail, $InstructorContact);
    $stmt ->fetch();
    $stmt ->close();

    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $UpdatedName = trim($_POST['Instructor_username']);
        $UpdatedEmail = trim($_POST['Instructor_email']);
        $UpdatedContact = trim($_POST['Instructor_contact']);

        $UpdateToSql = "UPDATE Instructor SET Instructor_username = ?, Instructor_email = ?, Instructor_contact = ? where Instructor_ID = ?";
        $stmt = $con ->prepare($UpdateToSql);
        $stmt ->bind_param("ssss", $UpdatedName, $UpdatedEmail, $UpdatedContact, $InstructorID);
        if ($stmt->execute()){

            $_SESSION['Instructor_username'] = $UpdatedName;
            $_SESSION['Instructor_email'] = $UpdatedEmail;
            $_SESSION['Instructor_contact'] = $UpdatedContact;
            echo'<script>alert("Profile Updated Successfully!");
                window.location.href = "profile.php";
            </script>';
        } else{
            echo'<script>alert("Error updating file!!");</script>';
        }
        $stmt->close();
    }
    mysqli_close($con);
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel='stylesheet' href="Assignment.css">
    <style>
        .content-container{
            max-width: 500px;
            margin: 40px auto;
            padding: 20px;
            border: 1px solid grey;
            border-radius: 10px;
            background-color: white;
        }

        h1{
            text-align: left;
        }

        label{
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .content-container input[type="text"], .content-container input[type="email"]{
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid grey;
            border-radius: 5px;
        }

        .content-container button{
            display:block;
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #dd1c1c;
            color:white;
            border:none;
            border-radius: 5px;
            cursor:pointer;
            font-size: 16px;
        }

        .content-container button:hover{
            background-color: #b51717;
        }
    </style>
</head>
<body>
    <div class="content-container">
        <h1>Edit Profile</h1>
        <form action="EditProfile.php" method="post">
            <label for="Instructor_username">Username:</label>
            <input type="text" id="Instructor_username" name="Instructor_username" value="<?php echo ($InstructorName); ?>" required>

            <label for="Instructor_email">Email:</label>
            <input type="email" id="Instructor_email" name="Instructor_email" value="<?php echo ($InstructorEmail) ?>" required>

            <label for="Instructor_contact">Contact Number:</label>
            <input type = "text" id="Instructor_contact" name="Instructor_contact" value="<?php echo ($InstructorContact) ?>" required>

            <button type="Submit"> Update</button>
        </form>
    </div>
</body>
</html>