<?php include 'NavigationBar.php';  /*use the same navigation bar between pages */
include("ins.php");
?>

<?php
include("../conn.php"); //connect with the database




if($_SERVER["REQUEST_METHOD"] == "POST"){
    $InstructorID = $_SESSION['Instructor_ID'];
    $QuizTitle = $_POST['Quiz_title'];
    $QuizDesc = $_POST['Quiz_description'];
    $QuizDate = date("Y-m-d H:i:s");
    $QuizTimer = isset($_POST['Quiz_timer']) ? $_POST['Quiz_timer'] : 0;

    $LatestQuizID = $con->query("SELECT Quiz_ID from quiz order by Quiz_ID desc limit 1");
    if($LatestQuizID->num_rows > 0){
        $row = $LatestQuizID->fetch_assoc();
        $LastQuizID = $row['Quiz_ID'];
        $num = intval(substr($LastQuizID, 1)) + 1;
        $code = str_pad($num, 3, '0', STR_PAD_LEFT);
        $NewQuizID = 'Q'.str_pad($num, 3, '0', STR_PAD_LEFT);
    }
    else{
        $code = '001';
        $NewQuizID = 'Q001';
    }
    $IntoSQL = "INSERT into quiz (Quiz_ID, Quiz_title, Quiz_description, created_date, Quiz_timer, quiz_code, Instructor_ID) 
    values (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($IntoSQL);
    $stmt->bind_param("ssssiss", $NewQuizID, $QuizTitle, $QuizDesc, $QuizDate, $QuizTimer, $code, $InstructorID);

    if ($stmt-> execute()){
        echo "Quiz created succefully with ID: ".$NewQuizID;
        $_SESSION['Quiz_ID'] = $NewQuizID;
        header("location: CreateQues.php?Quiz_ID=$NewQuizID");
        exit();
    }
    else{
        echo "ERROR:".$stmt->error;
    }
    $stmt->close();
    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz</title>
    <link rel='stylesheet' href="Assignment.css">
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body{
            height: 100%;
            font-family: Arial, sans-serif;
        }

        body{
            background-color: #f9f9f9;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        nav {
            width: 100%;
            background-color: #dd1c1c;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 3px solid black;
            z-index: 100; 
        }

        #CreateQuizForm{
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width:100%;
            max-width: 400px;
            margin-top: 50px;
        }

        #CreateQuizForm div{
            margin-bottom: 15px;
        }

        #CreateQuizForm label{
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        #CreateQuizForm input[type="text"], #CreateQuizForm textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            resize: vertical;
        }

        #CreateQuizForm textarea{
            min-height: 100px;
        }

        #ProceedToQues[type="submit"]{
            background-color: #dd1c1c;
            color:white;
            border: 3px solid black;
            padding:12px;
            font-size: 16px;
            border-radius: 4px;
            cursor:pointer;
            width: 100%;
        }

        #ProceedToQues[type="submit"]:hover{
            background-color:white ;
            color: black;
        }

        #ProceedToQues[type="submit"]:active{
            background-color: #1e7e34;
        }

        #ProceedToQues[type="submit"]:focus{
            outline: none;
        }

        @media(max-width:600px){
            #CreateQuizForm{
                padding: 15px;
            }

            #ProceedToQues[type="submit"]{
                font-size: 14px;
            }
        }

        #Quiz_timer{
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }  
        em {
            font-size: 12px;
        }

    </style>
</head>
<body>
    <form id="CreateQuizForm" method="post" action="CreateQuiz.php">
        <div>
            <label for="quiz_title">Quiz Title:</label>
            <input type="text" id="Quiz_title" name="Quiz_title" required>
        </div>
        <div>
            <label for="Quiz_description">Quiz Description:</label>
            <textarea id="Quiz_description" name="Quiz_description" required></textarea>
        </div>
        <div>
            <label for="Quiz_timer">Quiz Timer (in minutes):</label>
            <input type="number" id="Quiz_timer" name="Quiz_timer" min="0" value="0" required>
            <p><em>Default 0 = no timer set for quiz</em></p><br>
        </div>
        <button id="ProceedToQues" type="submit">Proceed</button>
    </form>
</body>
</html>

