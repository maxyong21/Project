<?php
include("../conn.php");

if (session_status() == PHP_SESSION_NONE){
    session_start();
}

$Instructor_ID = $_SESSION['Instructor_ID'];

$instructor_info = "SELECT * FROM instructor WHERE Instructor_ID = ?";
$stmt = $con->prepare($instructor_info);
$stmt->bind_param("s", $Instructor_ID);
$stmt->execute();
$instructor_info_result = $stmt->get_result();
$instructor = $instructor_info_result->fetch_assoc();
$stmt->close();

$background_sql = "SELECT item.Item_url, item.Item_ID, instructor.Instructor_ID, instructor.Applied_item FROM item 
JOIN instructor ON item.Item_ID = instructor.Applied_item
WHERE instructor.Applied_item != '' 
AND instructor.Instructor_ID = ?";
$stmt = $con->prepare($background_sql);
$stmt->bind_param("s", $Instructor_ID);
$stmt->execute();
$background_result = $stmt->get_result();
$background_image_url = '';
$is_applied = false;

if ($background_result && mysqli_num_rows($background_result) > 0) {
    $row = mysqli_fetch_assoc($background_result);
    $background_image_url = htmlspecialchars($row['Item_url']);
    $is_applied = true;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
         body {
            /* Set the background image dynamically if theme applied */
            <?php if ($is_applied): ?>
                background-image: url('<?php echo $background_image_url; ?>');
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-position: center;
            <?php else: ?>
                background-color: white;
            <?php endif; ?>
        }
    </style>
</head>
<body>
    
</body>
</html>