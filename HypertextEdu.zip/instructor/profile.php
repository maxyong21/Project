<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="Assignment.css">
    <style>
        html, body{
            height: 100%;
            margin:0;
        }

        .content-container {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            width: 100%;
            min-height: 100vh;
        }

        .profile {
            flex-grow: 1;
            width: 100%;
            background-color: rgb(162, 102, 102);
            margin-top: 5px;
            padding: 50px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            overflow: hidden;
            border: 3px solid black;
            justify-content: center;
        }

        .profile-text{
            display: flex;
            flex-direction: column;
            margin-bottom: 10px;
            position: relative; /* set this for edit icon */
        }

        .personal {
            flex-grow: 4;
            width: 100%;
            background-color: rgb(147, 135, 135);
            margin: 0 0;
            padding: 50px;
            box-sizing: border-box;
            border: 3px solid black;
        }

        .Choosen-avatar{
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-right: 20px;
        }

        .Choosen-avatar:hover{
            transform: scale(1.1);
        }

        p{
            font-size: 20px;
            font-weight: bold;
        }

        .edit-icon{
            position:absolute;
            top: -20px;
            right: 0;
            padding: 10px;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .edit-icon img{
            width: 40px;
            height: 40px;
        }

        .edit-icon:hover{
            transform:scale(1.1);
        }

        @media (max-width: 480px) {
            p{
            font-size: 12px;
            font-weight: bold;
        }
        .edit-icon img{
            width: 25px;
            height: 25px;
        }
        }

    </style>    
</head>
<body>
     <?php
        include("../conn.php");
        include("ins.php");

        if(!isset($_SESSION['Instructor_ID'])) {
            header("location:login.php");
            exit();
        }

        $InstructorID = $_SESSION['Instructor_ID'];
        $InstructorName = trim($_SESSION['Instructor_username']);
        $InstructorEmailQuery = "SELECT Instructor_email FROM instructor WHERE Instructor_ID = '$InstructorID'";
        $InstructorEmailResult = mysqli_query($con, $InstructorEmailQuery);
        $InstructorEmail = mysqli_fetch_assoc($InstructorEmailResult)['Instructor_email'];
        $InstructorContactQuery = "SELECT Instructor_contact FROM instructor WHERE Instructor_ID = '$InstructorID'";
        $InstructorContactResult = mysqli_query($con, $InstructorContactQuery);
        $InstructorContact = mysqli_fetch_assoc($InstructorContactResult)['Instructor_contact'];

        if(mysqli_connect_errno()){
            echo "Failed to connect to My SQL:".mysqli_connect_error();
        }

       
    ?>

    <?php include 'NavigationBar.php'; ?>
      
    <div class="content-container">
        <div class="profile">
            <div class="Choosen-avatar">
                <img src="instructorIcon.png" alt="avatar" class="Choosen-avatar">
            </div>            
        </div>

        <div class="personal">
            <h1>Personal Information</h1>
            <br>
            <br>
            <div class="profile-text">
                <a href="EditProfile.php" class="edit-icon">
                    <img src="editIcon.png" alt="edit icon" />
                </a>
                <p>Username: <?php echo htmlspecialchars($InstructorName); ?></p>
                <p>Instructor ID: <?php echo htmlspecialchars($InstructorID); ?></p>
                <p>Instructor email: <?php echo htmlspecialchars($InstructorEmail); ?></p>
                <p>Instructor contact: <?php echo htmlspecialchars($InstructorContact); ?></p>
                </div>
            </div>
        </div>
    </div>
    
   
    </body>
</html>