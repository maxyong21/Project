<?php
include("../conn.php");

session_start();
if (!isset($_SESSION['Instructor_ID'])) {
    header("Location: login.php");
    exit();
}
$Quiz_ID = isset($_POST['Quiz_ID']) ? mysqli_real_escape_string($con, $_POST['Quiz_ID']) : null;
$Student_ID = isset($_POST['Student_ID']) ? mysqli_real_escape_string($con, $_POST['Student_ID']) : null;

// Check if Feedback_ID is passed
if (isset($_POST['Feedback_ID'])) {
    $Feedback_ID = mysqli_real_escape_string($con, $_POST['Feedback_ID']);

    // Delete the feedback
    $delete_query = "DELETE FROM feedback WHERE Feedback_ID = '$Feedback_ID'";

    if (mysqli_query($con, $delete_query)) {
        echo '<script>alert("Feedback successfully deleted."); window.location.href = "studentAttempt.php?Quiz_ID=' . $Quiz_ID . '&Student_ID=' . $Student_ID . '";</script>';
    } else {
        echo "Error: " . mysqli_error($con);
    }
} else {
    echo "Invalid request!";
}

mysqli_close($con);
?>