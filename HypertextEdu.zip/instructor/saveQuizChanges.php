<?php
include("../conn.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $Quiz_ID = $_POST['Quiz_ID'];
    $quizName = mysqli_real_escape_string($con, $_POST['quizName']);
    $quizDesc = mysqli_real_escape_string($con, $_POST['quizDesc']);
    $quizTimer = mysqli_real_escape_string($con, $_POST['timer']);

    // Update quiz details in the database
    $updateQuizQuery = "UPDATE quiz SET Quiz_title = '$quizName', Quiz_description = '$quizDesc', Quiz_timer = '$quizTimer' WHERE Quiz_ID = '$Quiz_ID'";
    if (!mysqli_query($con, $updateQuizQuery)) {
        echo 'Error updating quiz: ' . mysqli_error($con);
        exit();
    }

    // Decode the JSON-encoded questions array
    $questions = json_decode($_POST['questions'], true);

    foreach ($questions as $question) {
        $questionText = mysqli_real_escape_string($con, $question['text']);
        $optionA = mysqli_real_escape_string($con, $question['options'][0]);
        $optionB = mysqli_real_escape_string($con, $question['options'][1]);
        $optionC = mysqli_real_escape_string($con, $question['options'][2]);
        $optionD = mysqli_real_escape_string($con, $question['options'][3]);

        if ($question['id'] === null) {
            // Insert new question
            $insertQuestionQuery = "INSERT INTO question (Quiz_ID, Question_text, Question_choice_a, Question_choice_b, Question_choice_c, Question_choice_d) VALUES ('$Quiz_ID', '$questionText', '$optionA', '$optionB', '$optionC', '$optionD')";
            if (!mysqli_query($con, $insertQuestionQuery)) {
                echo 'Error inserting question: ' . mysqli_error($con);
                exit();
            }
        } else {
            // Update existing question
            $questionID = $question['id'];
            $updateQuestionQuery = "UPDATE question SET Question_text = '$questionText', Question_choice_a = '$optionA', Question_choice_b = '$optionB', Question_choice_c = '$optionC', Question_choice_d = '$optionD' WHERE Question_ID = '$questionID'";
            if (!mysqli_query($con, $updateQuestionQuery)) {
                echo 'Error updating question: ' . mysqli_error($con);
                exit();
            }
        }
    }

    echo 'Quiz and questions updated successfully!';
}
?>