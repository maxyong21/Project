<?php
// Include database connection
include("../conn.php");

// Start the session to get the admin ID
session_start();
$ins_id = $_SESSION['Instructor_ID'];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form input values and sanitize them
    $feedback_text = mysqli_real_escape_string($con, $_POST['feedback_text']);
    $Question_ID = mysqli_real_escape_string($con, $_POST['Question_ID']);
    $Student_ID = mysqli_real_escape_string($con, $_POST['Student_ID']);
    $Quiz_ID = mysqli_real_escape_string($con, $_POST['Quiz_ID']);

    $result = mysqli_query($con, "SELECT MAX(Feedback_ID) AS max_id FROM feedback");
    $row = mysqli_fetch_assoc($result);
    $max_id = $row['max_id'];
    if ($max_id) {
        $num_part = intval(substr($max_id, 3));
        $next_id = "FDB" . str_pad((int)$max_id + 1, 3, '0', STR_PAD_LEFT);
    } else {
        $next_id = 'FDB001';
    }

    $feedback_sql = "INSERT INTO feedback (Feedback_ID, feedback_text, feedback_date, Question_ID, Student_ID) VALUES (?, ?, NOW(), ?, ?)";
    $stmt = mysqli_prepare($con, $feedback_sql);
    mysqli_stmt_bind_param($stmt, "ssss", $next_id, $feedback_text, $Question_ID, $Student_ID);

    if (mysqli_stmt_execute($stmt)) {
        echo '<script>alert("Feedback successfully submitted");
            window.location.href = "studentAttempt.php?Quiz_ID=' . $Quiz_ID . '&Student_ID=' . $Student_ID . '";
        </script>';
    } else {
        echo '<script>alert("Error: Unable to submit feedback.");</script>';
    }
    mysqli_stmt_close($stmt);
}
mysqli_close($con);
?>
