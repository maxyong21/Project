<?php
include("../conn.php");
include("ins.php");

$NewQuizID = isset($_GET['Quiz_ID']) ? $_GET['Quiz_ID'] : null;

if (!$NewQuizID) {
    echo '<script>alert("Quiz ID is missing. Please try again.");
    window.location.href="InstructorHomepage.php";
    </script>';
    exit;
}

function generateQuestionID($con) {

    $result = $con->query("SELECT Question_ID FROM question ORDER BY Question_ID DESC LIMIT 1");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastID = $row['Question_ID'];
        $num = intval(substr($lastID, 2)) + 1;
        return 'QS' . str_pad($num, 3, '0', STR_PAD_LEFT);
    } else {
        return 'QS001';
    }
}


if($_SERVER['REQUEST_METHOD'] == "POST"){
        $QuesText = $_POST['Question_text'];
        $AnsA = $_POST['AnsA'];
        $AnsB = $_POST['AnsB'];
        $AnsC = $_POST['AnsC'];
        $AnsD = $_POST['AnsD'];
        $CorrectAns = $_POST['CorrectAns'];

        for($i = 0; $i < count($QuesText); $i++){
            $text = trim($QuesText[$i]);
            $a = trim($AnsA[$i]);
            $b = trim($AnsB[$i]);
            $c = trim($AnsC[$i]);
            $d = trim($AnsD[$i]);
            $correct = trim($CorrectAns[$i]);

            if (empty($text) || empty($a) || empty($b) || empty($c) || empty($d) || empty($correct)) {
                continue;
            }

            $Question_ID = generateQuestionID($con);

            $stmt = $con->prepare("INSERT into question (Question_ID, Question_text, Question_choice_a, 
            Question_choice_b, Question_choice_c, Question_choice_d, correct_answer, Quiz_ID) values (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt-> bind_param("ssssssss", $Question_ID, $text, $a, $b, $c, $d, $correct, $NewQuizID);


            if(!$stmt->execute()){
                echo "Error: ".$stmt->error;
            }
            $stmt->close();
        }
        echo "<script>alert('Questions saved successfully!');
        window.location.href = 'InstructorHomepage.php';
        </script>";
        
        $con->close();
        exit();
    }
    else{
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Create Question</title>
        <link rel="stylesheet" href="Assignment.css">
        <style>
            body{
                font-family: Arial, sans-serif;
                background-color: #f9f9f9;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                
            }

            form.CreateQuesForm{
                width: 80%;
                max-width: 600px;
                margin: auto;
                padding: 20px;
                background-color: #ffffff;
                border: 1px solid #ddd;
                border-radius: 10px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    
            }

            form.CreateQuesForm .QuesBlock{
                margin-bottom: 20px;
                padding: 1opx;
                background-color: #f4f7fa;
                border: 1px solid #ddd;
                border-radius: 5px;
            }

            form.CreateQuesForm #QuestionContainer{
                margin:15px ;
            }

            form.CreateQuesForm .QuesBlock label{
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }

            form.CreateQuesForm .QuesBlock input[type="text"], form.CreateQuesForm .QuesBlock select{
                width: 100%;
                padding: 10px;
                margin-bottom: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                background-color: #fff;
            }

            form.CreateQuesForm .QuesBlock hr{
                margin-top: 20px;
                border: 0;
                height: 1px;
                background-color: #ddd;
            }

            form.CreateQuesForm .AddButton{
                background-color: #28a745;
                color: #fff;
                font-size: 16px;
                font-weight: bold;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s, transform 0.2s;
                margin-right: 10px;
            }

            form.CreateQuesForm .AddButton:hover{
                background-color: #218838;
                transform: scale(1.0);
            }

            form.CreateQuesForm .AddButton:active{
                transform: scale(0.95);
            }

            form.CreateQuesForm .SaveButton{
                background-color: #007bff;
                color: #fff;
                font-size: 16px;
                font-weight: bold;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s, transform 0.2s;
            }

            form.CreateQuesForm .SaveButton:hover{
                background-color: #0056b3;
                transform: scale(1.05);
            }

            form.CreateQuesForm .SaveButton:active{
                transform:scale(0.95);
            }

            .QuestionContainer{
                background-color: #f4f7fa;
                border: 1px solid #ddd;
                padding: 15px;
                margin-bottom: 15px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            .QuestionContainer h3{
                font-size: 18px;
                margin-bottom: 10px;
                color: #007bff;
            }

            .timer-input {
                width: 100%;
                padding: 10px;
                margin-bottom: 10px;
                border: 1px solid black;
                border-radius: 5px;
                font-size: 16px;
                background-color: #fff;
                margin-top: 10px;
            }
        </style>
        <script>
            function AddQues(){
                const container = document.getElementById("QuestionContainer");
                const QuesBlock = document.createElement("div");
                QuesBlock.className = "QuesBlock";

                QuesBlock.innerHTML = `
                    <div class="QuesContainer">
                        <label>Question Text:</label>
                        <input type= "text" name= "Question_text[]" required />
                        <label>Option A:</label>
                        <input type="text" name="AnsA[]" required />
                        <label>Option B:</label>
                        <input type="text" name="AnsB[]" required />
                        <label>Option C:</label>
                        <input type="text" name="AnsC[]" required />
                        <label>Option D:</label>
                        <input type="text" name="AnsD[]" required />

                        <label>Correct Answer:</label>
                        <select name="CorrectAns[]">
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                        </select>

                        <hr />
                    </div>
                    `;
                    container.appendChild(QuesBlock);       
                      
            }
        </script>    
    </head>
    <body>
        <?php echo '<form action="CreateQues.php?Quiz_ID=' . $NewQuizID . '" method="post" class="CreateQuesForm">'; ?>
            <h2>Create Questions</h2>
            <div id="QuestionContainer">
                <div class="QuesBlock">
                    <label style="font-size: 18px;">Question Text:</label>
                    <input type= "text" name= "Question_text[]" required />
                    <label>Option A:</label>
                    <input type="text" name="AnsA[]" required />
                    <label>Option B:</label>
                    <input type="text" name="AnsB[]" required />
                    <label>Option C:</label>
                    <input type="text" name="AnsC[]" required />
                    <label>Option D:</label>
                    <input type="text" name="AnsD[]" required />

                    <label>Correct Answer:</label>
                    <select name="CorrectAns[]">
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                    </select>
                    <hr>
                </div>

            </div>

            <button type="button" class="AddButton" onclick="AddQues()">Add Question</button>
            <button type="submit" class="SaveButton">Save</button>
        </form>
    </body>
    </html>
    <?php
}
?>


