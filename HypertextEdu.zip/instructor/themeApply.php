<?php
include("../conn.php");

session_start();

$id = $_GET['id'];
$action = $_GET['action'];
$ins_id = $_SESSION['Instructor_ID']; 

if ($action === 'apply') {
    $update_query = "UPDATE instructor SET `Applied_item` = '$id' WHERE Instructor_ID = '$ins_id'";
} else {
    $update_query = "UPDATE instructor SET `Applied_item`='' WHERE Instructor_ID = '$ins_id'";
}

if (mysqli_query($con, $update_query)) {
    $message = ($action === 'apply') ? "Theme successfully applied." : "Theme successfully removed.";
    echo '<script>alert("' . $message . '");
            window.location.href = "themeShop.php";  
          </script>';
} else {
    echo '<script>alert("Error applying theme: ' . mysqli_error($con) . '");
            window.location.href = "themeShop.php"; 
          </script>';
}
?>