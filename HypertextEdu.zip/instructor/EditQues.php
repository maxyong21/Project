<?php
include 'NavigationBar.php';
include("ins.php");

include("../conn.php");

if (isset($_GET['Quiz_ID'])) {
    $_SESSION['Quiz_ID'] = $_GET['Quiz_ID'];
}
if (!isset($_SESSION['Quiz_ID'])) {
    echo "<p>Error: Quiz ID is missing.</p>";
    exit();
}

$Quiz_ID = $_SESSION['Quiz_ID'];

$sql = "SELECT * FROM question WHERE Quiz_ID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $Quiz_ID);
$stmt->execute();
$result = $stmt->get_result();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quesID = $_POST['ques_id']; // Question ID
    $questionText = $_POST['question_text'];
    $optionA = $_POST['option_a'];
    $optionB = $_POST['option_b'];
    $optionC = $_POST['option_c'];
    $optionD = $_POST['option_d'];
    $correctAnswer = $_POST['correct_answer'];

    $updateSQL = "UPDATE question SET Question_text = ?, Question_choice_a = ?, Question_choice_b = ?, Question_choice_c = ?, Question_choice_d = ?, correct_answer = ? WHERE Question_ID = ? and Quiz_ID = ?";
    $updateStmt = $con->prepare($updateSQL);
    $updateStmt->bind_param("ssssssss", $questionText, $optionA, $optionB, $optionC, $optionD, $correctAnswer, $quesID, $Quiz_ID);
    
    if ($updateStmt->execute()) {
        echo "<p>Question updated successfully!</p>";
        header("Location: InstructorHomepage.php");
    } else {
        echo "<p>Error: " . $updateStmt->error."</p>";
    }
    $updateStmt->close();
}

$stmt->close();
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Question</title>
    <link rel="stylesheet" href="Assignment.css">
    <style>
        body{
                font-family: Arial, sans-serif;
                background-color: #f9f9f9;
                margin: 0;
                padding: 0;
                
            }

            form.CreateQuesForm{
                width: 80%;
                margin: auto;
                padding: 20px;
                background-color: #ffffff;
                border: 1px solid #ddd;
                border-radius: 10px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    
            }

            form.CreateQuesForm .QuesBlock{
                margin-bottom: 20px;
                padding: 1opx;
                background-color: #f4f7fa;
                border: 1px solid #ddd;
                border-radius: 5px;
            }

            form.CreateQuesForm #QuestionContainer{
                margin:15px ;
            }

            form.CreateQuesForm .QuesBlock label{
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }

            form.CreateQuesForm .QuesBlock input[type="text"], form.CreateQuesForm .QuesBlock select{
                width: 100%;
                padding: 10px;
                margin-bottom: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                background-color: #fff;
            }

            form.CreateQuesForm .QuesBlock hr{
                margin-top: 20px;
                border: 0;
                height: 1px;
                background-color: #ddd;
            }

            form.CreateQuesForm .AddButton{
                background-color: #28a745;
                color: #fff;
                font-size: 16px;
                font-weight: bold;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s, transform 0.2s;
                margin-right: 10px;
            }

            form.CreateQuesForm .AddButton:hover{
                background-color: #218838;
                transform: scale(1.0);
            }

            form.CreateQuesForm .AddButton:active{
                transform: scale(0.95);
            }

            form.CreateQuesForm .SaveButton{
                background-color: #007bff;
                color: #fff;
                font-size: 16px;
                font-weight: bold;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s, transform 0.2s;
            }

            form.CreateQuesForm .SaveButton:hover{
                background-color: #0056b3;
                transform: scale(1.05);
            }

            form.CreateQuesForm .SaveButton:active{
                transform:scale(0.95);
            }

            .QuestionContainer{
                background-color: #f4f7fa;
                border: 1px solid #ddd;
                padding: 15px;
                margin-bottom: 15px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            .QuestionContainer h3{
                font-size: 18px;
                margin-bottom: 10px;
                color: #007bff;
            }
            .question {
                height: auto;
                min-height: 100;
                width: 75vw;
                display: flex;
                justify-content: flex-start;
                align-content: flex-start;
                flex-direction: column;
            }
            .question-obj {
                height: auto;
                margin: 20px 15px;
                align-items: flex-start;
                display: flex;
                gap: 5px;
            }
            .question-obj textarea {
                width: 65vw;
                padding: 5px;
            }
            .content {
                margin: 20px;
                padding: 20px;
            }
            .content input {
                padding: 5px;
            }
            .content select {
                padding: 3px;
            }
            .content button {
                height: 35px;
                width: 150px;
            }
            hr {
                margin-top: 15px;
                margin-bottom: 15px;
            }
    </style>
</head>
<body>
    <div class="content">
    <h2>Edit Questions</h2><br>
    <?php
    while ($question = $result->fetch_assoc()) {
        ?>
        <div class="question">
        <form action="EditQues.php" method="post">
            <input type="hidden" name="ques_id" value="<?php echo $question['Question_ID']; ?>">

            <div class="question-obj">
            <label for="question_text">Question:</label>
            <textarea name="question_text" rows=3 required>"<?php echo htmlspecialchars($question['Question_text']); ?>"</textarea>
            </div>

            <div class="question-obj">
            <label for="option_a">Option A:</label>
            <input type="text" name="option_a" value="<?php echo htmlspecialchars($question['Question_choice_a']); ?>" required>
            </div>
            
            <div class="question-obj">
            <label for="option_b">Option B:</label>
            <input type="text" name="option_b" value="<?php echo htmlspecialchars($question['Question_choice_b']); ?>" required>
            </div>
            
            <div class="question-obj">
            <label for="option_c">Option C:</label>
            <input type="text" name="option_c" value="<?php echo htmlspecialchars($question['Question_choice_c']); ?>" required>
            </div>
            
            <div class="question-obj">
            <label for="option_d">Option D:</label>
            <input type="text" name="option_d" value="<?php echo htmlspecialchars($question['Question_choice_d']); ?>" required>
            </div>
            
            <div class="question-obj">
            <label for="correct_answer">Correct Answer:</label>
            <select name="correct_answer" required>
                <option value="A" <?php if ($question['correct_answer'] == 'A') echo 'selected'; ?>>A</option>
                <option value="B" <?php if ($question['correct_answer'] == 'B') echo 'selected'; ?>>B</option>
                <option value="C" <?php if ($question['correct_answer'] == 'C') echo 'selected'; ?>>C</option>
                <option value="D" <?php if ($question['correct_answer'] == 'D') echo 'selected'; ?>>D</option>
            </select>
            </div>
            
            <div class="question-obj">
            <button type="submit">Update Question</button>
            </div>
        </form>
        </div>
        <hr>
        <?php
    }
    ?>
    </div>
</body>
</html>