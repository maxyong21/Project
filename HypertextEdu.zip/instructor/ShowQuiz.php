<?php
include 'NavigationBar.php';
include("../conn.php");
?>

<?php
include("ins.php");
if(!isset($_SESSION['Instructor_ID'])){
    header("location:login.php");
    exit();
}

$Quiz_ID = isset($_GET['Quiz_ID']) ? $_GET['Quiz_ID'] : null;

if ($Quiz_ID === null){
    echo "<p>Invalid Quiz ID</p>";
    exit();
}

$sql= "SELECT Quiz_ID, Quiz_title, Quiz_description, created_date from quiz where Quiz_ID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $Quiz_ID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0){
    $quiz = $result->fetch_assoc();
}
else{
    echo "<p>QUiz not found.</p>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View QUiz - <?php echo htmlspecialchars($quiz['Quiz_title']); ?></title>
    <link rel="stylesheet" href="Assignment.css">
    <style>
        h1{
            margin-top: 40px;
            text-align: center;
        }

        .quiz-details, .quiz-questions{
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .quiz-details h2, .quiz-questions h2{
            font-size: 24px;
            color: #dd1c1c;
            text-align: center;
        }

        .quiz-details p, .quiz-questions p{
            font-size: 16px;
        }

        .question{
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
        }

        .question p{
            margin: 8px 0;
        }

        .correct-answer{
            color: #dd1c1c;
            font-weight: bold;
        }
        .quiz-details a {
            text-decoration: underline;
            color: black;
            line-height: 25px;
        }
        .quiz-details a:hover {
            font-weight: bold;
        }

        .attempts-container {
            display: flex;
            align-items: flex-start;
            justify-content: flex-start;
            width: 100%;
            flex-direction: column;
            margin-bottom: 50px;
        }
        .quiz-attempts {
            width: 80%;
            height: 100px;
            margin: 10px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }
        .quiz-attempts p{
            font-size: 16px;
            line-height: 30px;
        }
        .student-details {
            width: 75%;
        }
        .student-button {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .student-button button {
            padding: 5px;
            height: 30px;
            font-size: 12px;
            background-color: #dd1c1c;
            color: white;
            border-radius: 5px;
            border: none;
            width: 65px;
        }
        .student-button button:hover {
            background-color: #810808;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Quiz Details</h1>

    <div class="quiz-details">
        <h2><?php echo htmlspecialchars($quiz['Quiz_title']); ?></h2>
        <p><strong>Description:</strong><?php echo htmlspecialchars($quiz['Quiz_description']); ?></p>
        <p><strong>Created Date:</strong><?php echo htmlspecialchars($quiz['created_date']); ?></p>
        <a href="EditQuiz.php?Quiz_ID=<?php echo htmlspecialchars($quiz['Quiz_ID']); ?>">Edit Quiz</a>
    </div><br><br>

    <?php
    $sqlQues = "SELECT Question_ID, Question_text, Question_choice_a, Question_choice_b, Question_choice_c, Question_choice_d, correct_answer from question where Quiz_ID = ?";
    $stmtQues = $con->prepare($sqlQues);
    $stmtQues->bind_param("s", $Quiz_ID);
    $stmtQues->execute();
    $resultQues = $stmtQues->get_result();

    if($resultQues->num_rows > 0){
        echo "<h2 style='text-align: center;'>Questions</h2>";
        echo "<div class='quiz-questions'>";
        while ($question = $resultQues->fetch_assoc()) {
            echo "<div class='question'>";
            echo "<p><strong>Question:</strong>".htmlspecialchars($question['Question_text'])."</p>";
            echo "<p><strong>Option A:</strong>".htmlspecialchars($question['Question_choice_a'])."</p>";
            echo "<p><strong>Option B:</strong>".htmlspecialchars($question['Question_choice_b'])."</p>";
            echo "<p><strong>Option C:</strong>".htmlspecialchars($question['Question_choice_c'])."</p>";
            echo "<p><strong>Option D:</strong>".htmlspecialchars($question['Question_choice_d'])."</p>";
            echo "<p class='correct-answer'><strong>Correct Answer:</strong>".htmlspecialchars($question['correct_answer'])."</p>";
            echo "</div>";
        }
        echo "</div>";
    }else{
        echo "<p style='text-align: center;'>No questions found for this quiz!</p>";
    }
    echo '<br><br>';

    // student attempts
    $attempts_query = "SELECT DISTINCT e.Student_ID, s.Student_username, SUM(e.score) AS total_score 
    FROM enrollment e
    JOIN student s ON e.Student_ID = s.Student_ID
    WHERE e.Quiz_ID = ?
    GROUP BY e.Student_ID, s.Student_username
    ORDER BY total_score DESC";
    $stmtAttempts = $con->prepare($attempts_query);
    $stmtAttempts->bind_param("s", $Quiz_ID);
    $stmtAttempts->execute();
    $attempts_result = $stmtAttempts->get_result();

    $total_qs = "SELECT COUNT(Question_ID) AS total FROM question WHERE Quiz_ID = ?";
    $stmtQs = $con->prepare($total_qs);
    $stmtQs->bind_param("s", $Quiz_ID);
    $stmtQs->execute();
    $qs_result = $stmtQs->get_result();
    $qs = $qs_result->fetch_assoc();
    $total = $qs['total'] * 10;

    echo "<h2 style='text-align: center;'>Student Attempts</h2><br>";
    echo '<div class="attempts-container">';
    if ($attempts_result->num_rows > 0) {
        while ($attempt = $attempts_result->fetch_assoc()) {
            echo "<div class='quiz-attempts'>";
            echo "<div class='student-details'>";
            echo "<p><strong>Student Username:</strong> " . htmlspecialchars($attempt['Student_username']) . "</p>";
            echo "<p><strong>Total Score:</strong> " . htmlspecialchars($attempt['total_score']) . "/" . $total . "</p>";
            echo "</div>";
            echo "<div class='student-button'>";
            echo "<button type='button' onclick=\"window.location.href='studentAttempt.php?Quiz_ID=" . $Quiz_ID . "&Student_ID=" . htmlspecialchars($attempt['Student_ID']) . "'\">View</button>";
            echo "</div>";
            echo "</div>";
        }
        
    } else {
        echo "<p style='text-align: center;'>No attempts found for this quiz.</p>";
    }
    $stmtAttempts->close();

    $stmt->close();
    $stmtQues->close();
    $con->close();
    echo '</div>';
    ?>
</body>
</html>