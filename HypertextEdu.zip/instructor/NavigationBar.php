<nav>
    <!-- <div style="width:50%"> -->
        <a href="InstructorHomepage.php">
            <img src="../logo.jpg" alt="Home" class="logo">
        </a>
    <!-- </div> -->
    <!-- <div style="float: right;width:50%; border: 1px solid black;"> -->
        <div class="right-container">
            <div class="right-one">
            <a href="InstructorHomepage.php" class="nav-button">Home</a>
            <a href="ThemeShop.php" class="nav-button">Theme Shop</a>
        </div>
        <div class="right-one">
            <form action="InstructorHomepage.php" method="GET" class="search-container">
                <input type="text" class="search-input" placeholder="Search..." name="query" aria-label="Search" required>
                <button type="submit" class="search-button">
                    <img src="searchIcon.jpg" alt="Search">
                </button>
            </form>

            <div class="profile-container">
                <img src="ProfileIcon.jpg" alt="Profile" class="profile-icon" onclick="toggleMenu()">
                <div class="dropdown-menu" id="profileMenu">
                    <a href="profile.php">PROFILE</a>
                    <a href="../opening.php">LOG OUT</a>
                </div>
            </div>
        </div>
        </div>
    <!-- </div> -->
</nav>

<script>
    function toggleMenu(){
        const menu = document.getElementById('profileMenu');
        menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
    }

    window.onclick = function(event){
        const menu = document.getElementById('profileMenu');
        const profileIcon = document.querySelector('.profile-icon');
        if (event.target !== profileIcon && !profileIcon.contains(event.target)){
            menu.style.display = 'none';
        }

    };
</script>