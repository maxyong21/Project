<?php
// Include the database connection file
include("../conn.php");

// Initialize variables for error messages
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $Instructor_name = mysqli_real_escape_string($con, $_POST['Instructor_name']);
    $Instructor_email = mysqli_real_escape_string($con, $_POST['Instructor_email']);
    $Instructor_contact = mysqli_real_escape_string($con, $_POST['Instructor_contact']);
    $Instructor_username = mysqli_real_escape_string($con, $_POST['Instructor_username']);
    $Instructor_password = mysqli_real_escape_string($con, $_POST['Instructor_password']);
    $passwordConf = mysqli_real_escape_string($con, $_POST['passwordConf']);

    // Check that password == passwordConf (server-side)
    if ($Instructor_password !== $passwordConf) {
        echo '<script>alert("Passwords do not match. Please try again.");
            window.location.href="registration.php";
        </script>';
    } else {
        // Check if username already exists
        $check_username_query = "SELECT * FROM instructor WHERE Instructor_username = '$Instructor_username'";
        $username_result = mysqli_query($con, $check_username_query);

        if (mysqli_num_rows($username_result) > 0) {
            echo '<script>alert("This username is taken. Please enter a different username.");
                window.location.href="registration.php";
            </script>';
        } else {
            // Check if email is taken
            $check_email_query = "SELECT * FROM instructor WHERE Instructor_email = '$Instructor_email'";
            $email_result = mysqli_query($con, $check_email_query);

            if (mysqli_num_rows($email_result) > 0) {
                echo '<script>alert("This email is already registered. Please enter a different email.");
                    window.location.href="registration.php";
                </script>';
            } else {
                // Hash password
                $hashed_password = password_hash($Instructor_password, PASSWORD_DEFAULT);

                $result = mysqli_query($con, "SELECT MAX(Instructor_ID) AS max_id FROM instructor");
                $row = mysqli_fetch_assoc($result);
                $max_id = $row['max_id'];

                if ($max_id) {
                    $num_part = intval(substr($max_id, 3));
                    $next_id = "INS" . str_pad($num_part + 1, 3, '0', STR_PAD_LEFT);
                } else {
                    $next_id = 'INS001';
                }

                $check_id_query = "SELECT Instructor_ID from instructor where Instructor_ID = '$next_id'";
                $id_result = mysqli_query($con, $check_id_query);

                while (mysqli_num_rows($id_result) > 0){
                    $num_part++;
                    $next_id = "INS" . str_pad($num_part, 3, '0', STR_PAD_LEFT);
                    $id_result = mysqli_query($con, $check_id_query);
                }

                $insert_query = "INSERT INTO instructor (Instructor_ID, Instructor_email, Instructor_contact, Instructor_username, Instructor_password) values (?, ?, ?, ?, ?)";
                $stmt = $con->prepare($insert_query);
                $stmt->bind_param("sssss", $next_id, $Instructor_email, $Instructor_contact, $Instructor_username, $hashed_password);

                if ($stmt->execute()) {
                    echo '<script>alert("Registration successful");
                        window.location.href="login.php";
                    </script>';
                } else {
                    echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
                }

                $stmt->close();
            }
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        .logo {
            width: 300px;
            margin-bottom: 20px;
            margin-left: 8px;
        }
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url(../background3.jpg) no-repeat;
            background-size: cover;
            background-position: center;
        }
        .wrapper{
            width: 420px;
            background: transparent;
            color: white;
            border-radius: 15px;
            padding: 30px 40px;
            border: 2px solid white;
            backdrop-filter: blur(20px);
            align-items: center;
            justify-content: center;
            display: flex;
        }
        .wrapper h1{
            font-size: 40px;
            text-align: center;
        }
        .input-box{
            width: 100%;
            height: 475px;
            margin: 40px 0;
            position: relative;
        }
        .input-box input{
            width: 100%;
            height: 35px;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 50px;
            background: transparent;
            font-size: 20px;
            color: white;
            padding: 20px 45px 20px 15px;
            margin-bottom: 10px;
        }
        .input-box input::placeholder{
            color: white;
        }
        .btn{
            width: 100%;
            height: 45px;
            background: #fff;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            cursor: pointer;
            font-size: 20px;
            color: black;
            font-weight: 600;
        }
        .cancel-btn{
            width: 100%;
            height: 45px;
            background: white;
            border: none;
            border-radius: 45px;
            outline: none;
            cursor: pointer;
            font-size: 20px;
            color: black;
            font-weight: 600;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
        }
        .login-link{
            font-size: 15px;
            text-align: center;
            margin: 20px 0 10px;
        }
        .login-link p, .login-link a{
            color: #fff;
            text-decoration: none;
        }
        .login-link a:hover{
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <form id="registrationForm" action="registration.php" method="POST" onsubmit="return validatePassword()">
            <img src="../logo.jpg" alt="Logo" class="logo">
            <h1>Registration</h1>
            <div class="user-details">
                <div class="input-box">
                    <input type="text" id="Instructor_name" name="Instructor_name" placeholder="Full Name" required><br>
                    <input type="text" id="Instructor_username" name="Instructor_username" placeholder="Username" required><br>
                    <input type="email" id="Instructor_email" name="Instructor_email" placeholder="Email Address" required><br>
                    <input type="contact" id="Instructor_contact" name="Instructor_contact" placeholder="Contact Number" required><br>
                    <input type="password" id="Instructor_password" name="Instructor_password" placeholder="Password" required><br>
                    <input type="password" id="passwordConf" name="passwordConf" placeholder="Confirm Password" required><br><br><br>

                    <button type="Submit" class="btn">Register</button>
                    <button type="button" class="cancel-btn" onclick="clearForm()">Cancel</button><br>
                    <div class="login-link">
                        <p>Already have an account?</p>
                        <a href="login.php">Login</a>
                    </div>
                </div> 
            </div>
        </form>
    </div>
    <script>
        //Function to cancel the whole form
        function clearForm() {
            document.getElementById("registrationForm").reset();
        }
        /* Check password */
        function validatePassword() {
            var password = document.getElementById("Instructor_password").value;
            var passwordConf = document.getElementById('passwordConf').value;
            if (password != passwordConf) {
                alert("Passwords do not match. Please try again.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>