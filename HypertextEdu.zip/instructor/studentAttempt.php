<?php
include("../conn.php");
include 'NavigationBar.php';
include("ins.php");

$Quiz_ID = isset($_GET['Quiz_ID']) ? $_GET['Quiz_ID'] : 0;
$Student_ID = isset($_GET['Student_ID']) ? $_GET['Student_ID'] : 0;

$quiz_query = "SELECT * FROM quiz WHERE Quiz_ID = '$Quiz_ID' AND verificationStatus = 'approved'";
$quiz_result = mysqli_query($con, $quiz_query);
if (mysqli_num_rows($quiz_result) == 0) {
    echo '<script>alert("Quiz not found."); window.location.href="InstructorHomepage.php";</script>';
    exit;
}

$quiz = mysqli_fetch_assoc($quiz_result);
$quiz_title = $quiz['Quiz_title'];

$answers_query = "SELECT question.Question_ID, question.Question_text, enrollment.Student_ans, enrollment.score, question.correct_answer,question.Question_choice_a, question.Question_choice_b, question.Question_choice_c, question.Question_choice_d
FROM enrollment
JOIN question ON enrollment.Question_ID = question.Question_ID
WHERE enrollment.Student_ID = '$Student_ID' AND enrollment.Quiz_ID = '$Quiz_ID'";
$answers_result = mysqli_query($con, $answers_query);

$feedback_query = "SELECT feedback.*, question.Question_text
FROM feedback
JOIN question ON feedback.Question_ID = question.Question_ID
WHERE feedback.Student_ID = '$Student_ID'
AND feedback.Question_ID = question.Question_ID";
$feedback_results = mysqli_query($con, $feedback_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Review</title>
    <link rel="stylesheet" href="Assignment.css">
    <style>
        /* Style for displaying results */
        .quiz-results {
            width: 80vw;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
        }
        .quiz-question {
            margin-bottom: 25px;
            padding: 15px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            width: 75vw;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }
        .quiz-details {
            display: flex;
            flex-direction: column;
            width: 85%;
        }
        .quiz-question p {
            margin: 15px 0;
            font-size: 18px;
        }
        .quiz-question .correct-answer {
            color: green;
            margin-left: 15px;
            font-size: 16px;
        }
        .quiz-question .student-answer {
            color: red;
            margin-left: 15px;
            font-size: 16px;
        }
        .quiz-question .score {
            margin-top: 20px;
            font-size: 14px;
            color: black;
            margin-left: 15px;
        }
        .done-button {
            background-color: #dd1c1c;
            color: white;
            padding: 10px 15px;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
            width: 80px;
            margin-top: 20px;
        }
        .feedback-button {
            width: 80px;
        }
        .feedback-button button {
            padding: 5px;
            height: 50px;
            font-size: 12px;
            background-color: #dd1c1c;
            color: white;
            border-radius: 5px;
            border: none;
            width: 70px;
        }
        .feedback-button button:hover {
            background-color: #810808;
            cursor: pointer;
        }
        em {
            font-size: 14px;
        }

        .feedback-form {
            display: grid;
            place-items: center;
            position: fixed;
            top: 50%;
            left: 50%;
            width: 350px;
            min-height: 250px;
            transform: translate(-50%, -50%); /* centers form */
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: auto;
            z-index: 1000;
        }
        .feedback-form textarea {
            width: 240px;
            padding: 10px;
            margin: 10px 0px 10px 0px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            min-height: 150px;
        }
        .feedback-form button {
            width: 100px;
            height: 45px;
            padding: 10px;
            margin-top: 5px;
            background-color: #dd1c1c;
            border: none;
            color: #fff;
            font-size: 12px;
            cursor: pointer;
            border-radius: 5px;
        }
        .feedback-form button:hover {
            color: #810808;
            border: none;
        }
        .form-buttons {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
        }

        .feedback {
            margin-bottom: 25px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            width: 75vw;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            line-height: 25px;
        }
        .existing-feedback-button button {
            height: 35px;
            width: 70px;
            padding: 10px;
            margin-top: 5px;
            background-color: #dd1c1c;
            border: none;
            color: #fff;
            font-size: 12px;
            cursor: pointer;
            border-radius: 5px;
        }
        .existing-feedback-button button:hover {
            color: #810808;
            border: none;
        }
    </style>
</head>
<body>
    <script>
        function openFeedbackForm(questionId) {
        // Set the Question_ID dynamically in the hidden field
        document.getElementById('Question_ID').value = questionId;
        document.getElementById('feedbackForm').style.display = 'block';
    }

        // close edit form
        function cancelEdit() {
            document.getElementById('feedbackForm').style.display = 'none';
            document.getElementById('feedbackFormFields').reset();
        }
    </script>
    
    <div class="quiz-results">
        <h2><?php echo htmlspecialchars($quiz_title); ?> Overview</h2><br>

        <?php
        while ($row = mysqli_fetch_assoc($answers_result)) {
            $correct_answer = $row['correct_answer'];
            $student_answer = $row['Student_ans'];
            $score = $row['score'];

            $choices = [
                'A' => $row['Question_choice_a'],
                'B' => $row['Question_choice_b'],
                'C' => $row['Question_choice_c'],
                'D' => $row['Question_choice_d']
            ];

            echo '<div class="quiz-question">';
            echo '<div class="quiz-details">';
            echo '<p><strong>Question:</strong> ' . htmlspecialchars($row['Question_text']) . '</p>';
            echo '<p><span class="correct-answer">Correct Answer: ' . $correct_answer . ') ' . htmlspecialchars($choices[$correct_answer]) . '</span></p>';
            if ($student_answer != '') {
                echo '<p><span class="student-answer">Student Answer: ' . $student_answer . ') ' . htmlspecialchars($choices[$student_answer]) . '</span></p>';
            } else {
                echo '<p class="student-answer">Student Answer: -</p>';
            }
            echo '<p class="score"><em>Points Earned: ' . ($score == 10 ? '10' : '0') . '</em></p>';
            echo '</div>';
            echo '<div class="feedback-button">';
            echo '<button type="button" onclick="openFeedbackForm(\'' . htmlspecialchars($row["Question_ID"]) . '\')">Add Feedback</button>';
            echo '</div>';
            echo '</div>';
            }
            ?>

            <div class="feedback-form" id="feedbackForm" style="display: none;">
                <form id="feedbackFormFields" action="feedback.php" method="POST">
                    <input type="hidden" id="Quiz_ID" name="Quiz_ID" value="<?php echo htmlspecialchars($Quiz_ID); ?>">
                    <input type="hidden" id="Student_ID" name="Student_ID" value="<?php echo htmlspecialchars($Student_ID); ?>">
                    <input type="hidden" id="Question_ID" name="Question_ID" value="">
                    <textarea id="feedback_text" name="feedback_text" placeholder="Enter feedback"></textarea><br><br>
                    <div class="form-buttons">
                        <button type="submit">Submit Feedback</button>
                        <button type="button" id="cancelButton" onclick="cancelEdit()">Cancel</button>
                    </div>
                </form>
            </div>

            <?php
            if (mysqli_num_rows($feedback_results) > 0) {
            echo '<br><br><h2>Existing Feedback</h2><br>';
            echo '<div class="feedback">';
            while ($row = mysqli_fetch_assoc($feedback_results)) {
                echo '<div class="feedback-item">';
                echo '<p><strong>Question: </strong>' . htmlspecialchars($row['Question_text']) . '</strong></p>';
                echo '<p>' . nl2br(htmlspecialchars($row['feedback_text'])) . '</p><br>';
                echo '<em>Posted on: ' . htmlspecialchars($row['feedback_date']) . '</em></p>';
                echo '</div>';
                echo '<div class="existing-feedback-button">';
                echo '<form action="feedbackDelete.php" method="POST" onsubmit="return confirm(\'Are you sure you want to delete this feedback?\')">';
                echo '<input type="hidden" name="Feedback_ID" id="Feedback_ID" value="' . htmlspecialchars($row['Feedback_ID']) . '">';
                echo '<input type="hidden" name="Quiz_ID" id="Quiz_ID" value="' . htmlspecialchars($Quiz_ID) . '">';
                echo '<input type="hidden" name="Student_ID" id="Student_ID" value="' . htmlspecialchars($row['Student_ID']) . '">';
                echo '<button type="submit">Delete</button>';
                echo '</form>';                
                echo '</div>';
            }
            echo '</div>';
            }
            ?>

        <br><br><button type="button" class="done-button" onclick="window.location.href='InstructorHomepage.php'">Done</button>
    </div>

</body>
</html>