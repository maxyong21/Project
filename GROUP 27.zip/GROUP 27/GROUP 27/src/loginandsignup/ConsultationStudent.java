/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package loginandsignup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Max
 */
public class ConsultationStudent extends javax.swing.JFrame {
    private final String StudentId;

    /**
     * Creates new form ConsultationStudent
     */
    public ConsultationStudent(String StudentId) {
        initComponents();
        this.StudentId = StudentId;
        DefaultTableModel model = (DefaultTableModel) availableslotstable.getModel();
        DefaultTableModel aptModel = (DefaultTableModel) viewaptstable.getModel();

        // check that all required files exist
        File consultationFile = new File("consultationlec.txt");
        try {
            if (!consultationFile.exists()) {
                consultationFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Consultations file not found.");
        }
        
        File userDetailsFile = new File("userDetails.txt");
        try {
            if (!userDetailsFile.exists()) {
                userDetailsFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "User details file not found.");
        }
        
        File aptFile = new File("appointment.txt");
        try {
            if (!aptFile.exists()) {
                aptFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Appointments file not found.");
        }
        
        // Debugging: Print file path
        System.out.println("Consultation File: " + consultationFile.getAbsolutePath());
        System.out.println("User Details File: " + userDetailsFile.getAbsolutePath());
        System.out.println("Appointment File: " + aptFile.getAbsolutePath());

        // Clear existing data in the table
        model.setRowCount(0);
        aptModel.setRowCount(0);
        
        Map<String, String> userIdToNameMap = new HashMap<>();

        // Read data from userDetails.txt to get the lecturer name from the given ID
        try (BufferedReader userReader = new BufferedReader(new FileReader(userDetailsFile))) {
            String userLine;

            while ((userLine = userReader.readLine()) != null) {
                userLine = userLine.trim(); // Trim whitespace
                if (userLine.isEmpty()) {
                    continue; // Skip empty lines
                }

                String[] userParts = userLine.split(",");
                if (userParts.length == 6) {
                    userIdToNameMap.put(userParts[0].trim(), userParts[3].trim());
                } else {
                    System.err.println("Invalid line: " + userLine); // Log invalid lines
                }
            }
            }   catch (FileNotFoundException ex) {
                    Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        // get the slot details from consultationlec.txt to populate the available slots table
        try (BufferedReader consultationReader = new BufferedReader(new FileReader(consultationFile))) {
            String consultationLine;
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            while ((consultationLine = consultationReader.readLine()) != null) {
                String[] consultationParts = consultationLine.split(",");
                if (consultationParts.length == 6) {
                    String SlotId = consultationParts[0].trim();
                    String LecturerId = consultationParts[1].trim();
                    String Date = consultationParts[2].trim();
                    String StartTime = consultationParts[3].trim();
                    String EndTime = consultationParts[4].trim();
                    String Status = consultationParts[5].trim();
                    
                    // ensure that slots shown are future slots
                    try {
                        LocalDate slotDate = LocalDate.parse(Date, formatter);
                        if (!slotDate.isBefore(today) && "Available".equalsIgnoreCase(Status)) {
                            String UserName = userIdToNameMap.getOrDefault(LecturerId, "Unknown Lecturer");
                            model.addRow(new Object[]{SlotId, UserName, Date, StartTime, EndTime});
                        }
                    } catch (DateTimeParseException e) {
                        System.err.println("Invalid date format for slot: " + Date);
                    }
                } else {
                    System.err.println("Invalid line: " + consultationLine);
                }
            } 
        }   catch (FileNotFoundException ex) {
                Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        // read appointment.txt to get the scheduled apts under the given student ID
        try (BufferedReader aptReader = new BufferedReader(new FileReader(aptFile))) {
            String aptLine;
            
            while ((aptLine = aptReader.readLine()) != null) {
                aptLine = aptLine.trim();
                if (aptLine.isEmpty()) {
                    continue;
                }
                
                String[] aptParts = aptLine.split(",");
                if (aptParts.length == 7) {
                    String aptId = aptParts[0].trim();
                    String aptStudentId = aptParts[1].trim();
                    String lecturerId = aptParts[2].trim();
                    String date = aptParts[3].trim();
                    String startTime = aptParts[4].trim();
                    String endTime = aptParts[5].trim();
                    
                    if (aptStudentId.equals(StudentId)) {
                        String lecturerName = userIdToNameMap.getOrDefault(lecturerId, "Unknown");
                        aptModel.addRow(new Object[]{aptId, lecturerName, date, startTime, endTime});
                    }
                } else {
                    System.err.println("Invalid line: " + aptLine);
                }
            }
            
        } catch (IOException ex) {
            Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        consultationLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        availableslotstable = new javax.swing.JTable();
        bookConsultationLbl = new javax.swing.JLabel();
        bookConsultationBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        viewaptstable = new javax.swing.JTable();
        cancelAptBtn = new javax.swing.JButton();
        viewAptLbl = new javax.swing.JLabel();
        rescheduleAptBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        consultationLbl.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        consultationLbl.setText("Consultation");
        getContentPane().add(consultationLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        closeBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        closeBtn.setText("Close");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 30, -1, -1));

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        availableslotstable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Slot ID", "Lecturer Name", "Date", "Start TIme", "End Time"
            }
        ));
        jScrollPane1.setViewportView(availableslotstable);

        bookConsultationLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        bookConsultationLbl.setText("Book Consultation");

        bookConsultationBtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        bookConsultationBtn.setText("Book");
        bookConsultationBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookConsultationBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 663, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(bookConsultationLbl)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(bookConsultationBtn)
                .addGap(286, 286, 286))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(bookConsultationLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bookConsultationBtn)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 100, -1, -1));

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        viewaptstable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Appointment ID", "Lecturer Name", "Date", "Start Time ", "End TIme"
            }
        ));
        jScrollPane2.setViewportView(viewaptstable);

        cancelAptBtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cancelAptBtn.setText("Cancel");
        cancelAptBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelAptBtnActionPerformed(evt);
            }
        });

        viewAptLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        viewAptLbl.setText("View Appointment");

        rescheduleAptBtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        rescheduleAptBtn.setText("Reschedule");
        rescheduleAptBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rescheduleAptBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 650, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(viewAptLbl)
                                .addGap(214, 214, 214))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(cancelAptBtn)
                                .addGap(62, 62, 62)
                                .addComponent(rescheduleAptBtn)
                                .addGap(186, 186, 186))))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(viewAptLbl)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelAptBtn)
                    .addComponent(rescheduleAptBtn))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(705, 100, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/blue.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1380, 780));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_closeBtnActionPerformed

    private void bookConsultationBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookConsultationBtnActionPerformed
        // Get the selected row from the available slots table
        int selectedRow = availableslotstable.getSelectedRow();

        if (selectedRow == -1) {
            // No row selected
            JOptionPane.showMessageDialog(null, "Please select a slot to book.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the DefaultTableModel for both tables
        DefaultTableModel availableModel = (DefaultTableModel) availableslotstable.getModel();
        DefaultTableModel appointmentModel = (DefaultTableModel) viewaptstable.getModel();

        // Extract data from the selected row
        Vector<Object> rowData = new Vector<>();
        for (int column = 0; column < availableModel.getColumnCount(); column++) {
            rowData.add(availableModel.getValueAt(selectedRow, column));
        }

        String aptId = generateNewAptId();
        String slotId = (String) rowData.get(0);
        String lecturerName = (String) rowData.get(1);
        String date = (String) rowData.get(2);
        String startTime = (String) rowData.get(3);
        String endTime = (String) rowData.get(4);

        String lecturerId = getLecturerIdFromName(lecturerName);
        if (lecturerId == null) {
            JOptionPane.showMessageDialog(null, "Error: Lecturer ID not found.");
            return;
        }

        String aptLine = String.join(",", aptId, StudentId, lecturerId, date, startTime, endTime, slotId);

        // add the new apt to appointment.txt
        try (BufferedWriter aptWriter = new BufferedWriter( new FileWriter("appointment.txt", true))) {
            aptWriter.write(aptLine);
            aptWriter.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error saving appointment: " + ex.getMessage());
            return;
        }

        // update consultationlec.txt status = Booked
        try (BufferedReader reader = new BufferedReader(new FileReader("consultationlec.txt"));
            BufferedWriter writer = new BufferedWriter(new FileWriter("temp.txt"))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6 && parts[0].trim().equals(slotId)) {
                    writer.write(String.join(",", parts[0], parts[1], parts[2], parts[3], parts[4], "Booked"));
                } else {
                    writer.write(line);
                }
                writer.newLine();
            }
        }       catch (FileNotFoundException ex) {
                    Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
                }

        // replace file
        File originalFile = new File("consultationlec.txt");
        File tempFile = new File("temp.txt");
        if (originalFile.delete() && tempFile.renameTo(originalFile)) {
            System.out.println("Consultation file updated successfully.");
        } else {
            System.err.println("Error updating consultation file.");
        }

        appointmentModel.addRow(new Object[]{aptId, lecturerName, date, startTime, endTime});
        availableModel.removeRow(selectedRow); // remove the available slot after booking

        // Show success message
        JOptionPane.showMessageDialog(null, "Appointment booked successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_bookConsultationBtnActionPerformed

    private void cancelAptBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelAptBtnActionPerformed
        int selectedRow = viewaptstable.getSelectedRow();
        
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select an appointment to cancel.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get the DefaultTableModel for both tables
        DefaultTableModel availableModel = (DefaultTableModel) availableslotstable.getModel();
        DefaultTableModel aptModel = (DefaultTableModel) viewaptstable.getModel();

        String aptId = (String) aptModel.getValueAt(selectedRow, 0);
        String slotId = null;
        String lecturerId = null;
        String date = null;
        String startTime = null;
        String endTime = null;
        File aptFile = new File("appointment.txt");
        StringBuilder updatedApts = new StringBuilder();

        // read appointment.txt to get the cancelled apt's details
        try (BufferedReader reader = new BufferedReader(new FileReader(aptFile))) {
            String line;
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 7 && parts[0].equals(aptId)) {
                    slotId = parts[6];
                    lecturerId = parts[2];
                    date = parts[3];
                    startTime = parts[4];
                    endTime = parts[5];
                    
                    try {
                        LocalDate slotDate = LocalDate.parse(date, formatter);
                        if (slotDate.isBefore(today)) {
                            JOptionPane.showMessageDialog(null, "Cancellation unavailable for past appointments.");
                            return;
                        }

                    } catch (DateTimeParseException e) {
                        System.err.println("Invalid date format for slot: " + date);
                    }

                    continue;
                }
                updatedApts.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
            return;
        }

        // rewrite the file without the cancelled apt
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(aptFile))) {
            writer.write(updatedApts.toString());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating appointment file: " + e.getMessage());
            return;
        }

        // update consultationlec.txt (Booked -> Available)
        if (slotId != null) {
            File consFile = new File("consultationlec.txt");
            StringBuilder updatedSlots = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader(consFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 6 && parts[0].equals(slotId)) {
                        updatedSlots.append(String.join(",", parts[0], parts[1], parts[2], parts[3], parts[4], "Available")).append(System.lineSeparator());
                    } else {
                        updatedSlots.append(line).append(System.lineSeparator());
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error reading consultation file: " + e.getMessage());
                return;
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(consFile))) {
                writer.write(updatedSlots.toString());
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating consultation file: " + e.getMessage());
                return;
            }
        }
        
        // update reschedule.txt status (Pending -> Cancelled) if cancelled apt a pending reschedule request
        File rescheduleFile = new File("reschedule.txt");
        File tempFile = new File("reschedule_temp.txt");
        try {
            if (!rescheduleFile.exists()) {
                rescheduleFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, " file not found.");
        }
        
        StringBuilder updatedReschedule = new StringBuilder();
        
        try (BufferedReader rescheduleReader = new BufferedReader(new FileReader(rescheduleFile));
            BufferedWriter rescheduleWriter = new BufferedWriter(new FileWriter(tempFile))) {
            
            String rescheduleLine;
            while ((rescheduleLine = rescheduleReader.readLine()) != null) {
                String[] rescheduleParts = rescheduleLine.split(",");
                if (rescheduleParts.length >= 5) {
                    String fileAptId = rescheduleParts[1].trim();
                    
                    if (aptId.equals(fileAptId)) {
                        rescheduleParts[5] = "Cancelled";
                        updatedReschedule.append(String.join(",", rescheduleParts)).append(System.lineSeparator());
                    } else {
                        updatedReschedule.append(rescheduleLine).append(System.lineSeparator());
                    }
                }
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading user details file: " + e.getMessage());
            return;
        }
        
        // rewrite updated data to reschedule.txt
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rescheduleFile))) {
            writer.write(updatedReschedule.toString());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating reschedule file: " + e.getMessage());
            return;
        }

        // map the lecturer name based on the ID
        Map<String, String> userIdToNameMap = new HashMap<>();
        File userDetailsFile = new File("userDetails.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(userDetailsFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    userIdToNameMap.put(parts[0].trim(), parts[3].trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error reading user details file: " + e.getMessage());
            return;
        }

        // place slot back in available slots table
        if (slotId != null && lecturerId != null && date != null && startTime != null && endTime != null) {
            String lecturerName = userIdToNameMap.getOrDefault(lecturerId, "Unknown Lecturer");
            availableModel.addRow(new Object[]{slotId, lecturerName, date, startTime, endTime});
        }

        // remove row from booked apts table
        aptModel.removeRow(selectedRow);

        JOptionPane.showMessageDialog(null, "Appointment cancelled successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);     
    }//GEN-LAST:event_cancelAptBtnActionPerformed

    private void rescheduleAptBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rescheduleAptBtnActionPerformed
        int selectedRow = viewaptstable.getSelectedRow();
        
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select an appointment to reschedule.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        DefaultTableModel aptModel = (DefaultTableModel) viewaptstable.getModel();
        String aptId = (String) aptModel.getValueAt(selectedRow, 0);
        String selectedSlotId = "";
        String slotStatus = "";
        
        // get the selected consultation slot ID from appointment.txt based on the apt ID
        File aptFile = new File("appointment.txt");
        try (BufferedReader aptReader = new BufferedReader(new FileReader(aptFile))) {
            String aptLine;
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            boolean foundAppointment = false;
            
            while ((aptLine = aptReader.readLine()) != null) {
                String[] parts = aptLine.split(",");
                if (parts.length == 7) {
                    String fileAptId = parts[0].trim();
                    String date = parts[3].trim();
                    
                    try {
                        LocalDate slotDate = LocalDate.parse(date, formatter);
                        System.out.println(today + " " + slotDate);
                        if (fileAptId.equals(aptId)) { // Check if appointment ID matches
                            foundAppointment = true;

                            if (!slotDate.isBefore(today)) { // Check if date is in the past
                                selectedSlotId = parts[6].trim();
                            } else {
                                JOptionPane.showMessageDialog(null, "Reschedule unavailable for past appointments.");
                                return;
                            }
                        }   

                    } catch (DateTimeParseException e) {
                        System.err.println("Invalid date format for slot: " + date);
                    }

                }
            }
            if (selectedSlotId.equals("")) {
                JOptionPane.showMessageDialog(null, "Appointment ID not found.");
                return;
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
        }
        
        // check whether a reschedule request has already been submitted using the status in consultationlec.txt 
        File consFile = new File("consultationlec.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(consFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    String fileSlotId = parts[0].trim();
                    
                    if (fileSlotId.equals(selectedSlotId)) {
                        slotStatus = parts[5].trim();
                        if (slotStatus.equals("Reschedule Requested")) {
                            JOptionPane.showMessageDialog(null, "A request has already been submitted for this appointment.");
                            return;
                        }
                        break;
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading consultation file: " + e.getMessage());
            return;
        }
        
        new ReschedulePage(aptId).setVisible(true);
        
    }//GEN-LAST:event_rescheduleAptBtnActionPerformed

private String generateNewAptId() {
    String highestAptId = "A000";
    
    File aptFile = new File("appointment.txt");
    if (!aptFile.exists()) {
        return highestAptId;
    }
    
    // read the highest ID in appointment.txt
    try (BufferedReader reader = new BufferedReader(new FileReader(aptFile))) {
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            
            String[] parts = line.split(",");
            if (parts.length >= 1) {
                String currentAptId = parts[0].trim();
                if (currentAptId.compareTo(highestAptId) > 0) {
                    highestAptId = currentAptId;
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
    }
    
    int nextId = Integer.parseInt(highestAptId.substring(1)) + 1;
    return String.format("A%03d", nextId);
}

private String getLecturerIdFromName(String lecturerName) {
    File userDetailsFile = new File("userDetails.txt");
    
    Map<String, String> nameToIdMap = new HashMap<>();
    
    // get the lecturer name based on the ID
    try (BufferedReader reader = new BufferedReader(new FileReader(userDetailsFile))) {
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                String userId = parts[0].trim();
                String name = parts[3].trim();
                nameToIdMap.put(name, userId);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error reading file.");
        return null;
    }
    
    return nameToIdMap.getOrDefault(lecturerName, null);
}

private String generateNewSlotId() {
    String highestSlotId = "S000";
    
    // read the highest ID in consultationlec.txt
    try (BufferedReader slotReader = new BufferedReader(new FileReader("consultationlec.txt"))) {
        String line;
        while ((line = slotReader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            
            String[] parts = line.split(",");
            if (parts.length >= 1) {
                String currentSlotId = parts[0].trim();
                if (currentSlotId.compareTo(highestSlotId) > 0) {
                    highestSlotId = currentSlotId;
                }
            }
        }
    } catch (IOException e) {
         e.printStackTrace();
         JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage());
         return null;
    }
    
    int nextId = Integer.parseInt(highestSlotId.substring(1)) + 1;
    return String.format("S%03d", nextId);
}

    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable availableslotstable;
    private javax.swing.JButton bookConsultationBtn;
    private javax.swing.JLabel bookConsultationLbl;
    private javax.swing.JButton cancelAptBtn;
    private javax.swing.JButton closeBtn;
    private javax.swing.JLabel consultationLbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton rescheduleAptBtn;
    private javax.swing.JLabel viewAptLbl;
    private javax.swing.JTable viewaptstable;
    // End of variables declaration//GEN-END:variables
}
