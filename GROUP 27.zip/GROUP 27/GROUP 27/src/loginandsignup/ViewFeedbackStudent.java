/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package loginandsignup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Max
 */
public class ViewFeedbackStudent extends javax.swing.JFrame {
    private final String studentId;
    /**
     * Creates new form ViewFeedbackStudent
     * @param studentId
     */
    public ViewFeedbackStudent(String studentId) {
        initComponents();
        this.studentId = studentId;
        
        DefaultTableModel aptsModel = (DefaultTableModel) pastaptstable.getModel();
        DefaultTableModel lecFeedbackModel = (DefaultTableModel) lecfeedbacktable.getModel();
        DefaultTableModel ownFeedbackModel = (DefaultTableModel) ownfeedbacktable.getModel();
        aptsModel.setRowCount(0);
        lecFeedbackModel.setRowCount(0);
        ownFeedbackModel.setRowCount(0);
        
        Map<String, String> lecIdToNameMap = new HashMap<>();
        
        // link lecturer IDs to lecturer names
        try {
            File userFile = new File("userDetails.txt");
            
            // check if file exists, create one if not
            if (!userFile.exists()) {
                userFile.createNewFile();
            }
            
            // map lecturer name based on ID
            BufferedReader userReader = new BufferedReader(new FileReader(userFile));
            String userLine;
            
            while ((userLine = userReader.readLine()) != null) {
                userLine = userLine.trim();
                if (userLine.isEmpty()) {
                    continue;
                }
                
                String[] userParts = userLine.split(",");
                if (userParts.length == 6) {
                    lecIdToNameMap.put(userParts[0].trim(), userParts[3].trim());
                } else {
                    System.err.println("Invalid line: " + userLine); // Log invalid lines
                }
            }
        } catch (FileNotFoundException ex) {
                Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // populate past apts table
        try  {
            File aptFile = new File("appointment.txt");
        
            // Check if file exists, if not, create a new one
            if (!aptFile.exists()) {
                aptFile.createNewFile(); // Create a new file
            }
            
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            // get details to populate past apts table
            BufferedReader aptReader = new BufferedReader(new FileReader(aptFile));
            String aptLine;
            
            while ((aptLine = aptReader.readLine()) != null) {
                String[] aptParts = aptLine.split(",");
                if (aptParts.length == 7) {
                    String aptId = aptParts[0].trim();
                    String fileStudentId = aptParts[1].trim();
                    String lecturerId = aptParts[2].trim();
                    String date = aptParts[3].trim();
                    String time = aptParts[4].trim() + " - " + aptParts[5].trim();
                    
                    if (fileStudentId.equals(studentId)) {
                        try {
                            LocalDate aptDate = LocalDate.parse(date, formatter);
                            if (aptDate.isBefore(today)) {
                                String lecturerName = lecIdToNameMap.getOrDefault(lecturerId, "Unknown Lecturer");
                                aptsModel.addRow(new Object[]{aptId, lecturerName, date, time});
                            }
                        } catch (DateTimeParseException e) {
                            System.err.println("Invalid date format for appointment: " + date);
                        }
                    }
                }
            }
            
        
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
        }
        
        // populate lec feedback table
        try {
            File feedbackFile = new File("feedback.txt");
            
            if (!feedbackFile.exists()) {
                feedbackFile.createNewFile();
            }
            
            try(BufferedReader feedbackReader = new BufferedReader(new FileReader(feedbackFile))) {
                String feedbackLine;
            
                while ((feedbackLine = feedbackReader.readLine()) != null) {
                    String[] feedbackParts = feedbackLine.split(",");
                    if (feedbackParts.length >= 4) {
                        String feedbackId = feedbackParts[0].trim();
                        String aptId = feedbackParts[1].trim();
                        String datePosted = feedbackParts[2].trim();
                        String feedbackContent = feedbackParts[3].trim();

                        // read appointment.txt to find feedback for the student based on id
                        File aptFile = new File("appointment.txt");
                        BufferedReader aptReader = new BufferedReader(new FileReader(aptFile));
                        String aptLine;

                        while ((aptLine = aptReader.readLine()) != null) {
                            String[] aptParts = aptLine.split(",");
                            if (aptParts.length == 7) {
                                String fileAptId = aptParts[0].trim();
                                String fileStudentId = aptParts[1].trim();

                                if (fileAptId.equals(aptId) && feedbackId.startsWith("LF") && fileStudentId.equals(studentId)) {
                                    lecFeedbackModel.addRow(new Object[]{aptId, feedbackContent, datePosted});
                                }
                            }
                        }
                    }
                } 
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Appointment file not found: " + e.getMessage());
        }
        
        // populate student's own feedback table
        try {
            File feedbackFile = new File("feedback.txt");
            
            if (!feedbackFile.exists()) {
                feedbackFile.createNewFile();
            }
            
            try (BufferedReader feedbackReader = new BufferedReader(new FileReader(feedbackFile))) {
                String feedbackLine;

                while ((feedbackLine = feedbackReader.readLine()) != null) {
                    String[] feedbackParts = feedbackLine.split(",");
                    if (feedbackParts.length >= 4) {
                        String feedbackId = feedbackParts[0].trim();
                        String aptId = feedbackParts[1].trim();
                        String datePosted = feedbackParts[2].trim();
                        String feedbackContent = feedbackParts[3].trim();

                        if (feedbackId.startsWith("SF")) {
                            String rating = feedbackParts[4].trim();

                            String lecResponse;
                            if (feedbackParts.length == 6) {
                                lecResponse = feedbackParts[5].trim();
                            } else {
                                lecResponse = "N/A";
                            }

                            // read appointment.txt to find feedback for the student based on id
                            File aptFile = new File("appointment.txt");
                            BufferedReader aptReader = new BufferedReader(new FileReader(aptFile));
                            String aptLine;

                            while ((aptLine = aptReader.readLine()) != null) {
                                String[] aptParts = aptLine.split(",");
                                if (aptParts.length == 7) {
                                    String fileAptId = aptParts[0].trim();
                                    String fileStudentId = aptParts[1].trim();

                                    if (fileAptId.equals(aptId) && fileStudentId.equals(studentId)) {
                                        ownFeedbackModel.addRow(new Object[]{aptId, feedbackContent, rating, datePosted, lecResponse});
                                    }
                                }
                            }
                        }
                    }
                } 
            } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
        }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        closeBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pastaptstable = new javax.swing.JTable();
        pastAptsLbl = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        lecfeedbacktable = new javax.swing.JTable();
        lecFeedbackLbl = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        ownfeedbacktable = new javax.swing.JTable();
        deleteBtn = new javax.swing.JButton();
        lecFeedbackLbl1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setText("View Feedback");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        closeBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        closeBtn.setText("Close");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1272, 53, -1, -1));

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        pastaptstable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Apt. ID", "Lecturer Name", "Date", "Time"
            }
        ));
        jScrollPane1.setViewportView(pastaptstable);

        pastAptsLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        pastAptsLbl.setText("Past Appointments");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pastAptsLbl)
                .addGap(233, 233, 233))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(pastAptsLbl)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 631));

        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lecfeedbacktable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Apt. ID", "Feedback", "Date Posted"
            }
        ));
        jScrollPane2.setViewportView(lecfeedbacktable);
        if (lecfeedbacktable.getColumnModel().getColumnCount() > 0) {
            lecfeedbacktable.getColumnModel().getColumn(0).setMinWidth(60);
            lecfeedbacktable.getColumnModel().getColumn(0).setMaxWidth(60);
            lecfeedbacktable.getColumnModel().getColumn(2).setMinWidth(120);
            lecfeedbacktable.getColumnModel().getColumn(2).setMaxWidth(120);
        }

        lecFeedbackLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        lecFeedbackLbl.setText("Lecturer Feedback");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(lecFeedbackLbl)
                        .addGap(230, 230, 230))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(lecFeedbackLbl)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 110, -1, -1));

        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        ownfeedbacktable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Apt. ID", "Feedback", "Rating", "Date Posted", "Lecturer Response"
            }
        ));
        jScrollPane3.setViewportView(ownfeedbacktable);
        if (ownfeedbacktable.getColumnModel().getColumnCount() > 0) {
            ownfeedbacktable.getColumnModel().getColumn(0).setMinWidth(60);
            ownfeedbacktable.getColumnModel().getColumn(0).setMaxWidth(60);
            ownfeedbacktable.getColumnModel().getColumn(2).setMinWidth(50);
            ownfeedbacktable.getColumnModel().getColumn(2).setMaxWidth(50);
            ownfeedbacktable.getColumnModel().getColumn(3).setMinWidth(120);
            ownfeedbacktable.getColumnModel().getColumn(3).setMaxWidth(120);
        }

        deleteBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        lecFeedbackLbl1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        lecFeedbackLbl1.setText("Own Feedback");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lecFeedbackLbl1)
                .addGap(246, 246, 246))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(lecFeedbackLbl1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 400, 667, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/blue.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1390, 790));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_closeBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
         int selectedRow = ownfeedbacktable.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a feedback to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    DefaultTableModel ownFeedbackModel = (DefaultTableModel) ownfeedbacktable.getModel();

    String aptID = (String) ownfeedbacktable.getValueAt(selectedRow, 0);

    ownFeedbackModel.removeRow(selectedRow);
    
    File inputFile = new File("feedback.txt");
    File tempFile = new File(inputFile.getAbsolutePath() + ".tmp");
    
    boolean feedbackDeleted = false;
    
    // Process feedback IDs from feedback.txt to delete feedback
    try (BufferedReader feedbackReader = new BufferedReader(new FileReader(inputFile));
         BufferedWriter feedbackWriter = new BufferedWriter(new FileWriter(tempFile))) {
        
        String feedbackLine;
        while ((feedbackLine = feedbackReader.readLine()) != null) {
            String[] parts = feedbackLine.split(",");
            if (parts.length == 5) {
                String fileFeedbackId = parts[0].trim();
                String fileAptId = parts[1].trim();
                
                if (fileAptId.equals(aptID) && fileFeedbackId.startsWith("SF")) {
                    feedbackDeleted = true; 
                    continue;
                }
            }
            feedbackWriter.write(feedbackLine);
            feedbackWriter.newLine();
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error while processing the feedback file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    // Delete the original file and rename temp file
    try {
        // Ensure the input file is deleted
        java.nio.file.Files.deleteIfExists(inputFile.toPath());

        // Rename the temp file to the original file
        java.nio.file.Files.move(tempFile.toPath(), inputFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        JOptionPane.showMessageDialog(this, "Feedback deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, 
            "Failed to delete or rename files. Error: " + e.getMessage(), 
            "File Error", JOptionPane.ERROR_MESSAGE);

        // Attempt force delete if still not resolved
        try {
            tempFile.delete();
            inputFile.delete();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Force delete failed. Please check file permissions.", 
                "Critical Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    }//GEN-LAST:event_deleteBtnActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton closeBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lecFeedbackLbl;
    private javax.swing.JLabel lecFeedbackLbl1;
    private javax.swing.JTable lecfeedbacktable;
    private javax.swing.JTable ownfeedbacktable;
    private javax.swing.JLabel pastAptsLbl;
    private javax.swing.JTable pastaptstable;
    // End of variables declaration//GEN-END:variables
}
