
package loginandsignup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;



public class Login extends javax.swing.JFrame {

  
    public Login() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Left = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        loginLbl = new javax.swing.JLabel();
        roleCMB = new javax.swing.JComboBox<>();
        roleLbl = new javax.swing.JLabel();
        usernameLbl = new javax.swing.JLabel();
        usernameTxtField = new javax.swing.JTextField();
        passwordLbl = new javax.swing.JLabel();
        passwordTxtField = new javax.swing.JPasswordField();
        showPassBtn = new javax.swing.JButton();
        loginBtn = new javax.swing.JButton();
        signupBtn = new javax.swing.JButton();
        haveAccLbl = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        jLabel6.setText("jLabel6");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        Left.setBackground(new java.awt.Color(255, 255, 255));
        Left.setMinimumSize(new java.awt.Dimension(400, 500));

        javax.swing.GroupLayout LeftLayout = new javax.swing.GroupLayout(Left);
        Left.setLayout(LeftLayout);
        LeftLayout.setHorizontalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        LeftLayout.setVerticalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LOGIN");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loginLbl.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        loginLbl.setText("LOGIN");
        getContentPane().add(loginLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(429, 55, -1, -1));

        roleCMB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Please Select", "Student", "Lecturer" }));
        roleCMB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roleCMBActionPerformed(evt);
            }
        });
        getContentPane().add(roleCMB, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 162, 477, 46));

        roleLbl.setBackground(new java.awt.Color(102, 102, 102));
        roleLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roleLbl.setText("Role");
        getContentPane().add(roleLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, -1, -1));

        usernameLbl.setBackground(new java.awt.Color(102, 102, 102));
        usernameLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        usernameLbl.setText("Username");
        getContentPane().add(usernameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 234, -1, -1));

        usernameTxtField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        usernameTxtField.setForeground(new java.awt.Color(102, 102, 102));
        getContentPane().add(usernameTxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 266, 477, 40));

        passwordLbl.setBackground(new java.awt.Color(102, 102, 102));
        passwordLbl.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordLbl.setText("Password");
        getContentPane().add(passwordLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 348, -1, -1));
        getContentPane().add(passwordTxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 386, 477, 42));

        showPassBtn.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        showPassBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/showpass.png"))); // NOI18N
        showPassBtn.setLabel("ShowPassword");
        showPassBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPassBtnActionPerformed(evt);
            }
        });
        getContentPane().add(showPassBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 446, -1, -1));

        loginBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        loginBtn.setText("Login");
        loginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBtnActionPerformed(evt);
            }
        });
        getContentPane().add(loginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 448, 93, 36));

        signupBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        signupBtn.setForeground(new java.awt.Color(255, 51, 51));
        signupBtn.setText("Sign Up");
        signupBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupBtnActionPerformed(evt);
            }
        });
        getContentPane().add(signupBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(387, 527, -1, -1));

        haveAccLbl.setText("I don't have an account");
        getContentPane().add(haveAccLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 533, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/softblue.png"))); // NOI18N
        jLabel4.setText("jLabel2");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 680));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void showPassBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPassBtnActionPerformed
        if (passwordTxtField.getEchoChar() == '\u0000') { // If password is visible
            passwordTxtField.setEchoChar('*'); // Hide the password
            showPassBtn.setText("Show Password");
        } else {
            passwordTxtField.setEchoChar((char) 0); // Show the password
            showPassBtn.setText("Hide Password");
        }
    }//GEN-LAST:event_showPassBtnActionPerformed

    private void roleCMBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roleCMBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_roleCMBActionPerformed

    private void signupBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupBtnActionPerformed
        new SignUp().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_signupBtnActionPerformed

    private void loginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginBtnActionPerformed
        String Username = usernameTxtField.getText();
        String Password = new String(passwordTxtField.getPassword());
        String Role = (String) roleCMB.getSelectedItem();

        File dataFile = new File("userDetails.txt");

        // Check if the file exists
        if (!dataFile.exists()) {
            JOptionPane.showMessageDialog(null, "Error: User details file not found. Please contact admin.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(dataFile))) {
            boolean loginSuccessful = false;
            String sessionId = null;
            String sessionName = null;
            String sessionEmail = null;

            // Read the file line by line
            String line;
            while ((line = reader.readLine()) != null) {
                // Skip the header line
                if (line.startsWith("Id,")) {
                    continue;
                }

                // Split each line into fields
                String[] credentials = line.split(",");

                // Ensure the line contains all the required fields
                if (credentials.length == 6) {
                    String fileId = credentials[0].trim();
                    String fileUsername = credentials[1].trim();
                    String filePassword = credentials[2].trim();
                    String fileName = credentials[3].trim(); // Full name
                    String fileEmail = credentials[4].trim();
                    String fileRole = credentials[5].trim();

                    // Match username, password, and role
                    if (Username.equals(fileUsername) && Password.equals(filePassword) && Role.equals(fileRole)) {
                        sessionId = fileId;
                        sessionName = fileName; // Capture the full name
                        sessionEmail = fileEmail;
                        loginSuccessful = true;
                        break;
                    }
                }
            }

            if (loginSuccessful) {
                // Display success message
                JOptionPane.showMessageDialog(null, "Login successful!\nWelcome, " + sessionName + "\nID: " + sessionId);

                // Redirect user based on role
                if ("Lecturer".equals(Role)) {
                    new LecturerHomePage(sessionId, sessionName, sessionEmail).setVisible(true);
                } else if ("Student".equals(Role)) {
                    new StudentHomePage(sessionId, sessionName, sessionEmail).setVisible(true);
                }
                // Close the current login window
                ((JFrame) SwingUtilities.getWindowAncestor(usernameTxtField)).dispose();
            } else {
                // Display error message for incorrect credentials
                JOptionPane.showMessageDialog(null, "Invalid username, password, or role. Please try again.");
                usernameTxtField.setText("");
                passwordTxtField.setText("");
                roleCMB.setSelectedIndex(0);
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error occurred while reading the file.");
            e.printStackTrace();
        }
    }//GEN-LAST:event_loginBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Login().setVisible(true));
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Left;
    private javax.swing.JLabel haveAccLbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JButton loginBtn;
    private javax.swing.JLabel loginLbl;
    private javax.swing.JLabel passwordLbl;
    private javax.swing.JPasswordField passwordTxtField;
    private javax.swing.JComboBox<String> roleCMB;
    private javax.swing.JLabel roleLbl;
    private javax.swing.JButton showPassBtn;
    private javax.swing.JButton signupBtn;
    private javax.swing.JLabel usernameLbl;
    private javax.swing.JTextField usernameTxtField;
    // End of variables declaration//GEN-END:variables
}
