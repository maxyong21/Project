/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package loginandsignup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jasmine
 */
public class ReschedulePage extends javax.swing.JFrame {
    public final String aptId;

    /**
     * Creates new form ReschedulePage
     * @param aptId
     */
    public ReschedulePage(String aptId) {
        this.aptId = aptId;
        initComponents();
        
        DefaultTableModel aptModel = (DefaultTableModel) originalapttable.getModel();
        DefaultTableModel availableModel = (DefaultTableModel) availableslotstable.getModel();
        
        
        // check that all required files exist
        File aptFile = new File("appointment.txt");
        try {
            if (!aptFile.exists()) {
                aptFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Appointments file not found.");
        }
        
        File userFile = new File("userDetails.txt");
        try {
            if (!userFile.exists()) {
                userFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "User details file not found.");
        }
        
        File slotFile = new File("consultationlec.txt");
        try {
            if (!slotFile.exists()) {
                slotFile.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Consultations file not found.");
        }
        
        aptModel.setRowCount(0);
        availableModel.setRowCount(0);
        
        Map<String, String> userIdToNameMap = new HashMap<>();
        String targetLecId = null;
        
        // read userDetails.txt to get the lecturer names based on lecturer IDs
        try (BufferedReader reader = new BufferedReader(new FileReader(userFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    String userId = parts[0].trim();
                    String userName = parts[3].trim();
                    userIdToNameMap.put(userId, userName);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // get the details from appointment.txt and link the lecturer name to the ID in the txt file based on the apt ID
        try (BufferedReader reader = new BufferedReader(new FileReader(aptFile))) {
            String line;
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    String fileAptId = parts[0].trim();
                    String studentId = parts[1].trim();
                    String lecturerId = parts[2].trim();
                    String date = parts[3].trim();
                    String startTime = parts[4].trim();
                    String endTime = parts[5].trim();
                    String time = startTime + " - " + endTime;
                        
                    if (fileAptId.equals(aptId)) {
                        targetLecId = lecturerId;
                        String lecturerName = userIdToNameMap.getOrDefault(lecturerId, "Unknown Lecturer");
                        aptModel.addRow(new Object[]{fileAptId, lecturerName, date, time});
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        LocalDate today = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        // get available slot details under the given lecturer ID to populate the available slots table
        try (BufferedReader reader = new BufferedReader(new FileReader(slotFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    String slotId = parts[0].trim();
                    String slotLecId = parts[1].trim();
                    String slotDate = parts[2].trim();
                    String slotStartTime = parts[3].trim();
                    String slotEndTime = parts[4].trim();
                    String slotStatus = parts[5].trim();
                    
                    if (("Available").equals(slotStatus) && slotLecId.equals(targetLecId)) {
                        availableModel.addRow(new Object[]{slotId, slotDate, slotStartTime, slotEndTime});
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rescheduleLbl = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        oriAptLbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        originalapttable = new javax.swing.JTable();
        rescheduleReasonLbl = new javax.swing.JLabel();
        reasontext = new javax.swing.JTextField();
        submitBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        availableSlotsLbl = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        availableslotstable = new javax.swing.JTable();
        closeBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rescheduleLbl.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        rescheduleLbl.setText("Reschedule ");
        getContentPane().add(rescheduleLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oriAptLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        oriAptLbl.setText("Original Appointment");

        originalapttable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Appointment ID", "Lecturer Name", "Date", "Time"
            }
        ));
        jScrollPane1.setViewportView(originalapttable);

        rescheduleReasonLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        rescheduleReasonLbl.setText("Reschedule Reason");

        submitBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(194, 194, 194)
                .addComponent(oriAptLbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 642, Short.MAX_VALUE)
                            .addComponent(reasontext, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(rescheduleReasonLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(264, 264, 264)
                                .addComponent(submitBtn)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(oriAptLbl)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(rescheduleReasonLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reasontext, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(submitBtn)
                .addContainerGap(91, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 660, 660));

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        availableSlotsLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        availableSlotsLbl.setText("Available Slots");

        availableslotstable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Slot ID", "Date", "Start Time", "End Time"
            }
        ));
        jScrollPane2.setViewportView(availableslotstable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(203, 203, 203)
                        .addComponent(availableSlotsLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(availableSlotsLbl)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 80, 600, 660));

        closeBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        closeBtn.setText("Close");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 30, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/blue.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1330, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_closeBtnActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        int selectedRow = availableslotstable.getSelectedRow();
        
        if (selectedRow == -1) {
            // No row selected
            JOptionPane.showMessageDialog(null, "Please select a slot to reschedule to.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String rescheduleReason = reasontext.getText();
        
        DefaultTableModel availableModel = (DefaultTableModel) availableslotstable.getModel();
        
        Vector<Object> rowData = new Vector<>();
        for (int column = 0; column < availableModel.getColumnCount(); column++) {
            rowData.add(availableModel.getValueAt(selectedRow, column));
        }
        
        String rescheduleId = generateNewRescheduleId();
        String requestedSlotId = (String) rowData.get(0);
        String originalSlotId = "";
        
        // get the original slot ID from appointment.txt based on the given apt ID
        File aptFile = new File("appointment.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(aptFile))) {
            String line;
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 7) {
                    String fileAptId = parts[0].trim();
                    String fileSlotId = parts[6].trim();
                    
                    if (fileAptId.equals(aptId)) {
                        originalSlotId = fileSlotId;
                        break;
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
        }
        
        
        // insert the rescheduling reason based on the reschedule.txt details
        String line = "";
        if (!rescheduleReason.equals("")) {
            line = String.join(",", rescheduleId, aptId, originalSlotId, requestedSlotId, rescheduleReason, "Pending");
        } else {
            line = String.join(",", rescheduleId, aptId, originalSlotId, requestedSlotId, "N/A", "Pending");

        }
            
        // update reschedule.txt
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("reschedule.txt", true))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error updating reschedule file: " + e.getMessage());
        }

        
        File slotFile = new File("consultationlec.txt");
        File tempFile = new File("consultationlec_temp.txt");
        
        // update the slot status in consultationlec.txt (Booked -> Reschedule Requested)
        try (BufferedReader reader = new BufferedReader(new FileReader(slotFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            
            String lineContent;
            while ((lineContent = reader.readLine()) != null) {
                String[] parts = lineContent.split(",");
                if (parts.length == 6 && parts[0].trim().equals(originalSlotId)) {
                    parts[5] = "Reschedule Requested";
                    writer.write(String.join(",", parts));
                } else {
                    writer.write(lineContent);
                }
                writer.newLine();
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error updating consultaion slots file: " + e.getMessage());
            return;
        }
        
        // replace consultationlec.txt with the updated file
        if (slotFile.delete() && tempFile.renameTo(slotFile)) {
            JOptionPane.showMessageDialog(null, "Reschedule request submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Error updating consultation slots file.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_submitBtnActionPerformed

private String getLecturerIdFromName(String lecturerName) {
    File userDetailsFile = new File("userDetails.txt");
    
    Map<String, String> nameToIdMap = new HashMap<>();
    
    // read userDetails.txt to get the lecturer name at the given ID
    try (BufferedReader reader = new BufferedReader(new FileReader(userDetailsFile))) {
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                String userId = parts[0].trim();
                String name = parts[3].trim();
                nameToIdMap.put(name, userId);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error reading file.");
        return null;
    }
    
    return nameToIdMap.getOrDefault(lecturerName, null);
}

private String generateNewRescheduleId() {
    String highestRescheduleId = "R000";
    
    File file = new File("reschedule.txt");
    if (!file.exists()) {
        return highestRescheduleId;
    }
    
    // read reschedule.txt to get the highest ID
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            
            String[] parts = line.split(",");
            if (parts.length >= 1) {
                String currentAptId = parts[0].trim();
                if (currentAptId.compareTo(highestRescheduleId) > 0) {
                    highestRescheduleId = currentAptId;
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error reading reschedule file: " + e.getMessage());
    }
    
    int nextId = Integer.parseInt(highestRescheduleId.substring(1)) + 1;
    return String.format("R%03d", nextId);
}

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel availableSlotsLbl;
    private javax.swing.JTable availableslotstable;
    private javax.swing.JButton closeBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel oriAptLbl;
    private javax.swing.JTable originalapttable;
    private javax.swing.JTextField reasontext;
    private javax.swing.JLabel rescheduleLbl;
    private javax.swing.JLabel rescheduleReasonLbl;
    private javax.swing.JButton submitBtn;
    // End of variables declaration//GEN-END:variables
}
