
package loginandsignup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashSet;
import javax.swing.JOptionPane;


public class SignUp extends javax.swing.JFrame {

 
    public SignUp() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        signupLbl = new javax.swing.JLabel();
        roleCMB = new javax.swing.JComboBox<>();
        roleLbl = new javax.swing.JLabel();
        nameLbl = new javax.swing.JLabel();
        nameTxtField = new javax.swing.JTextField();
        usernameLbl = new javax.swing.JLabel();
        usernameTxtField = new javax.swing.JTextField();
        emailLbl = new javax.swing.JLabel();
        emailTxtField = new javax.swing.JTextField();
        passwordLbl = new javax.swing.JLabel();
        signupBtn = new javax.swing.JButton();
        haveAccLbl = new javax.swing.JLabel();
        loginBtn = new javax.swing.JButton();
        showPassBtn = new javax.swing.JButton();
        passwordTxtField = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sign Up");
        setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        signupLbl.setBackground(new java.awt.Color(0, 102, 102));
        signupLbl.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        signupLbl.setText("SIGN UP");
        getContentPane().add(signupLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(482, 30, -1, -1));

        roleCMB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Please Select", "Student", "Lecturer" }));
        getContentPane().add(roleCMB, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 95, 351, 46));

        roleLbl.setBackground(new java.awt.Color(102, 102, 102));
        roleLbl.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        roleLbl.setText("Role");
        getContentPane().add(roleLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 74, -1, -1));

        nameLbl.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        nameLbl.setText("Name");
        getContentPane().add(nameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 171, -1, -1));
        getContentPane().add(nameTxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 192, 351, 42));

        usernameLbl.setBackground(new java.awt.Color(102, 102, 102));
        usernameLbl.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        usernameLbl.setText("Username");
        getContentPane().add(usernameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 264, -1, -1));

        usernameTxtField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        usernameTxtField.setForeground(new java.awt.Color(102, 102, 102));
        usernameTxtField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameTxtFieldActionPerformed(evt);
            }
        });
        getContentPane().add(usernameTxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 289, 351, 40));

        emailLbl.setBackground(new java.awt.Color(102, 102, 102));
        emailLbl.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        emailLbl.setText("Email");
        getContentPane().add(emailLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 359, -1, -1));

        emailTxtField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        emailTxtField.setForeground(new java.awt.Color(102, 102, 102));
        emailTxtField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailTxtFieldActionPerformed(evt);
            }
        });
        getContentPane().add(emailTxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 384, 351, 40));

        passwordLbl.setBackground(new java.awt.Color(102, 102, 102));
        passwordLbl.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        passwordLbl.setText("Password");
        getContentPane().add(passwordLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 454, -1, -1));

        signupBtn.setBackground(new java.awt.Color(0, 102, 102));
        signupBtn.setForeground(new java.awt.Color(255, 255, 255));
        signupBtn.setText("Sign Up");
        signupBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupBtnActionPerformed(evt);
            }
        });
        getContentPane().add(signupBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 556, 91, 37));

        haveAccLbl.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 14)); // NOI18N
        haveAccLbl.setText("I've an account");
        getContentPane().add(haveAccLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 630, -1, -1));

        loginBtn.setForeground(new java.awt.Color(255, 51, 51));
        loginBtn.setText("Login");
        loginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginBtnActionPerformed(evt);
            }
        });
        getContentPane().add(loginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 630, 84, 31));

        showPassBtn.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        showPassBtn.setText("Show Password");
        showPassBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPassBtnActionPerformed(evt);
            }
        });
        getContentPane().add(showPassBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(574, 556, -1, -1));
        getContentPane().add(passwordTxtField, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 479, 351, 37));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/softblue.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void signupBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupBtnActionPerformed
        // User input fields
        String Username = usernameTxtField.getText();
        String Password = new String(passwordTxtField.getPassword());
        String Name = nameTxtField.getText();
        String Email = emailTxtField.getText();
        String Role = (String) roleCMB.getSelectedItem();

        // Variables for ID generation
        String ID = "";
        int studentCounter = 1;
        int lecturerCounter = 1;

        try {
            File dataFile = new File("userDetails.txt");
            HashSet<String> existingUsernames = new HashSet<>();
            HashSet<String> existingEmails = new HashSet<>();

            // Check if the file exists and load existing data
            if (dataFile.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(dataFile));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 6) {
                        String existingUsername = parts[1];
                        String existingEmail = parts[4];
                        existingUsernames.add(existingUsername); // Add names to the set
                        existingEmails.add(existingEmail); // Add emails to the set
                        if (parts[5].equals("Student")) {
                            studentCounter++;
                        } else if (parts[5].equals("Lecturer")) {
                            lecturerCounter++;
                        }
                    }
                }
                reader.close();
            }


            // Check if the Name or Email already exists
            if (existingUsernames.contains(Username)) {
                JOptionPane.showMessageDialog(null, "Username already registered. Registration unsuccessful.");
                return;
            }

            if (existingEmails.contains(Email)) {
                JOptionPane.showMessageDialog(null, "Email already registered. Registration unsuccessful.");
                return;
            }

            // Check if Role is selected
            if (Role == null || Role.equals("Please Select")) {
                JOptionPane.showMessageDialog(null, "Please select a valid role before registering.");
                return; // Stop further execution
            }

            // Generate ID based on role
            if (Role.equals("Student")) {
                ID = String.format("STU%03d", studentCounter);
                studentCounter++;
            } else if (Role.equals("Lecturer")) {
                ID = String.format("LEC%03d", lecturerCounter);
                lecturerCounter++;
            } else {
                JOptionPane.showMessageDialog(null, "Select a role.");
                return;
            }

            // Append user details to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(dataFile, true));
            writer.write(ID + "," + Username + "," + Password + "," + Name + "," + Email + "," + Role);
            writer.newLine(); // Add a new line after each entry
            writer.close();

            // Show success message
            JOptionPane.showMessageDialog(null, "Registration Successful\nGenerated ID: " + ID);

            // Reset form fields
            usernameTxtField.setText("");
            nameTxtField.setText("");
            emailTxtField.setText("");
            passwordTxtField.setText("");
            roleCMB.setSelectedIndex(0);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_signupBtnActionPerformed

    private void loginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginBtnActionPerformed
        // TODO add your handling code here:
        Login LoginFrame = new Login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_loginBtnActionPerformed

    private void emailTxtFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailTxtFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailTxtFieldActionPerformed

    private void showPassBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPassBtnActionPerformed
        if (passwordTxtField.getEchoChar() == '\u0000') { // If password is visible
        passwordTxtField.setEchoChar('*'); // Hide the password
        showPassBtn.setText("Show Password");
    } else {
        passwordTxtField.setEchoChar((char) 0); // Show the password
        showPassBtn.setText("Hide Password");
    }
    }//GEN-LAST:event_showPassBtnActionPerformed

    private void usernameTxtFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameTxtFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameTxtFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    
        public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUp().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel emailLbl;
    private javax.swing.JTextField emailTxtField;
    private javax.swing.JLabel haveAccLbl;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton loginBtn;
    private javax.swing.JLabel nameLbl;
    private javax.swing.JTextField nameTxtField;
    private javax.swing.JLabel passwordLbl;
    private javax.swing.JPasswordField passwordTxtField;
    private javax.swing.JComboBox<String> roleCMB;
    private javax.swing.JLabel roleLbl;
    private javax.swing.JButton showPassBtn;
    private javax.swing.JButton signupBtn;
    private javax.swing.JLabel signupLbl;
    private javax.swing.JLabel usernameLbl;
    private javax.swing.JTextField usernameTxtField;
    // End of variables declaration//GEN-END:variables
}
