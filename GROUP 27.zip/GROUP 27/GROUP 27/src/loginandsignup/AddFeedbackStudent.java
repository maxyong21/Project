/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package loginandsignup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Max
 */
public class AddFeedbackStudent extends javax.swing.JFrame {
    private final String studentId;

    /**
     * Creates new form FeedbackStudent
     */
    public AddFeedbackStudent(String studentId) {
        this.studentId = studentId;
        initComponents();
        
        DefaultTableModel model = (DefaultTableModel) pastaptstable.getModel();
        model.setRowCount(0);
        
        Map<String, String> lecIdToNameMap = new HashMap<>();
        
        try {
            File userFile = new File("userDetails.txt");
            
            // create file if it doesn't exist
            if (!userFile.exists()) {
                userFile.createNewFile();
            }
            
            // map lecturer name based on ID
            BufferedReader userReader = new BufferedReader(new FileReader(userFile));
            String userLine;
            
            while ((userLine = userReader.readLine()) != null) {
                userLine = userLine.trim();
                if (userLine.isEmpty()) {
                    continue;
                }
                
                String[] userParts = userLine.split(",");
                if (userParts.length == 6) {
                    lecIdToNameMap.put(userParts[0].trim(), userParts[3].trim());
                } else {
                    System.err.println("Invalid line: " + userLine); // Log invalid lines
                }
            }
        } catch (FileNotFoundException ex) {
                Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ConsultationStudent.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        File feedbackFile = new File("feedback.txt");
    try {
        if (!feedbackFile.exists()) {
            feedbackFile.createNewFile();
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Feedback file not found.");
    }

        
        try  {
            File aptFile = new File("appointment.txt");
        
            // Check if file exists, if not, create a new one
            if (!aptFile.exists()) {
                aptFile.createNewFile(); // Create a new file
            }
            
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            // get details from appointment.txt to populate the past apts table
            BufferedReader aptReader = new BufferedReader(new FileReader(aptFile));
            String aptLine;
            
            while ((aptLine = aptReader.readLine()) != null) {
                String[] aptParts = aptLine.split(",");
                if (aptParts.length == 7) {
                    String aptId = aptParts[0].trim();
                    String fileStudentId = aptParts[1].trim();
                    String lecturerId = aptParts[2].trim();
                    String date = aptParts[3].trim();
                    String time = aptParts[4].trim() + " - " + aptParts[5].trim();
                    
                    if (fileStudentId.equals(studentId)) {
                        try {
                            LocalDate aptDate = LocalDate.parse(date, formatter);
                            // ensure only past apts added
                            if (aptDate.isBefore(today)) {
                                String lecturerName = lecIdToNameMap.getOrDefault(lecturerId, "Unknown Lecturer");
                                model.addRow(new Object[]{aptId, lecturerName, date, time});
                            }
                        } catch (DateTimeParseException e) {
                            System.err.println("Invalid date format for appointment: " + date);
                        }
                    }
                }
            }
            
        
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading appointment file: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        addFeedbackLbl = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        feedbackLbl = new javax.swing.JLabel();
        addBtn = new javax.swing.JButton();
        ratingCMB = new javax.swing.JComboBox<>();
        feedbackLbl1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        stuFeedbackTxtarea = new javax.swing.JTextArea();
        closeBtn = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pastaptstable = new javax.swing.JTable();
        pastAptsLbl = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        addFeedbackLbl.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        addFeedbackLbl.setText("Add Feedback");
        getContentPane().add(addFeedbackLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 35, -1, -1));

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        feedbackLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        feedbackLbl.setText("Feedback");

        addBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        addBtn.setText("Add");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        ratingCMB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "1", "2", "3", "4", "5" }));

        feedbackLbl1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        feedbackLbl1.setText("Rating");

        stuFeedbackTxtarea.setColumns(20);
        stuFeedbackTxtarea.setRows(5);
        jScrollPane2.setViewportView(stuFeedbackTxtarea);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(191, Short.MAX_VALUE)
                .addComponent(addBtn)
                .addGap(185, 185, 185))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(feedbackLbl1)
                    .addComponent(ratingCMB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(feedbackLbl)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(feedbackLbl)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(feedbackLbl1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ratingCMB, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                .addComponent(addBtn)
                .addGap(55, 55, 55))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 111, -1, 575));

        closeBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        closeBtn.setText("Close");
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1083, 35, -1, -1));

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        pastaptstable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Apt. ID", "Lecturer Name", "Date", "Time"
            }
        ));
        jScrollPane1.setViewportView(pastaptstable);
        if (pastaptstable.getColumnModel().getColumnCount() > 0) {
            pastaptstable.getColumnModel().getColumn(0).setMinWidth(60);
            pastaptstable.getColumnModel().getColumn(0).setMaxWidth(60);
        }

        pastAptsLbl.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        pastAptsLbl.setText("Past Appointments");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(233, Short.MAX_VALUE)
                .addComponent(pastAptsLbl)
                .addGap(233, 233, 233))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(pastAptsLbl)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(503, 111, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/loginandsignup/blue.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 730));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        String studentFeedback = stuFeedbackTxtarea.getText();
        String ratingStr = (String) ratingCMB.getSelectedItem();
        
        // ensure feedback and rating provided upon submission
        if (studentFeedback.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Feedback field cannot be empty.");
            return;
        } else if (ratingStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Rating field cannot be empty.");
            return;
        }
        
        int selectedRow = pastaptstable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select an appointment to upload feedback to.");
        }
        
        DefaultTableModel tableModel = (DefaultTableModel) pastaptstable.getModel();
        
        Vector<Object> rowData = new Vector<>();
        for (int column = 0; column < tableModel.getColumnCount(); column++) {
            rowData.add(tableModel.getValueAt(selectedRow, column));
        }
        
        String feedbackId = generateNewFeedbackId();
        String aptId = (String) rowData.get(0);
        String datePosted = LocalDate.now().toString();
        
        try {
            File feedbackFile = new File("feedback.txt");
            boolean feedbackExists = false;
            
            // check if file exists and create if not
            if (!feedbackFile.exists()) {
                feedbackFile.createNewFile();
            }
            
            // check if student feedback has already been submitted for the chosen apt
            try (BufferedReader feedbackReader = new BufferedReader(new FileReader(feedbackFile))) {
                String feedbackLine;
                while ((feedbackLine = feedbackReader.readLine()) != null) {
                    String feedbackParts[] = feedbackLine.split(",");
                    if (feedbackParts.length >= 2 && feedbackParts[0].trim().startsWith("SF") && feedbackParts[1].trim().equals(aptId)) {
                        feedbackExists = true;
                        break;
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error reading feedback file: " + e.getMessage());
                return;
            }
            
            if (!feedbackExists) {
                String newFeedback = String.join(",", feedbackId, aptId, datePosted, studentFeedback, ratingStr);
                
                // write feedback to feedback.txt if no feedback already exists for given apt
                try (BufferedWriter feedbackWriter = new BufferedWriter(new FileWriter(feedbackFile, true))) {
                    feedbackWriter.write(newFeedback);
                    feedbackWriter.newLine();
                    JOptionPane.showMessageDialog(null, "Feedback submitted successfully.");
                    stuFeedbackTxtarea.setText("");
                    ratingCMB.setSelectedIndex(0);
                    
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error updating feedback file: " + e.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(null, "Feedback for this appointment already exists.");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_closeBtnActionPerformed

    private String generateNewFeedbackId() {
        int maxId = 0;

        // read the highest ID in feedback.txt
        try (BufferedReader reader = new BufferedReader(new FileReader("feedback.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].startsWith("SF")) {
                    try {
                        int id = Integer.parseInt(parts[0].substring(2));
                        maxId = Math.max(maxId, id);
                    } catch (NumberFormatException ex) {

                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading feedback file: " + e.getMessage());
        }

        return "SF" + String.format("%03d", maxId + 1);
    }
    
    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JLabel addFeedbackLbl;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JButton closeBtn;
    private javax.swing.JLabel feedbackLbl;
    private javax.swing.JLabel feedbackLbl1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel pastAptsLbl;
    private javax.swing.JTable pastaptstable;
    private javax.swing.JComboBox<String> ratingCMB;
    private javax.swing.JTextArea stuFeedbackTxtarea;
    // End of variables declaration//GEN-END:variables
}
